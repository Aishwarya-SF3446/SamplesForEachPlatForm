export const defaultGridOptions = {
    allowFiltering: false,
    allowSorting: true,
    allowGrouping: false,
    allowReordering: false,
    allowPdfExport: true,
    allowExcelExport: true,
    enableHover: true,
    enableStickyHeader: false,
    allowSelection: true,
    selectionSettings: {
      checkboxOnly: true,
      persistSelection: true,
    },
    allowPaging: true, // makes the grid crash if the cache of the grid isn't present at on load and we have Freeze inject with freeze columns
    enableVirtualization: false,
    enablePersistence: false,
    allowResizing: true,
    allowScrolling: true,
    showColumnChooser: true,
    allowSearching: true,
    editSettings: {
      allowAdding: true,
      allowEditing: true,
      allowDeleting: true,
    },
    resizeSettings: {
      mode: 'Auto',
    },
    filterSettings: {
      type: 'Menu',
    },
    searchSettings: {
      ignoreCase: true,
    },
    pageSettings: {
      pageSizes: 10,
      pageCount: 10,
      pageSize: 100,
    },
    toolbar: [],
    height: 'auto',
    width: '100%',
  };
  