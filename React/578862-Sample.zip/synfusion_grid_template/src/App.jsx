
import React, { useState, useEffect } from "react";
import { GridComponent, Filter, Inject, Sort, Reorder, Page, ColumnDirective, ColumnsDirective, Resize, ColumnChooser } from "@syncfusion/ej2-react-grids";
import nameTemplate from './templates/nameTemplate';
import timeTemplate from './templates/TimeTemplate';
import svgTemplate from './templates/svgTemplate';
import statusTemplate from './templates/statusTemplate';
import { t1Template, t2Template } from "./templates/tTemplate";
import { renderToStaticMarkup } from 'react-dom/server';
import './styles.css';
import { data } from "./data";
import { ButtonComponent } from '@syncfusion/ej2-react-buttons';
import { CheckBoxComponent } from '@syncfusion/ej2-react-buttons';

function AppComponent() {

    const aliasesArray = [

        {
            headerText: 'Files',
            field: 'ShipCountry',
            allowSorting: false,
            type: 'file'
        },


    ];
    const defaultColumns = [
        {
            headerText: 'Name (A-Z)',
            field: 'CustomerID',
        },
        {
            headerText: 'Status',
            field: 'ShipRegion',
        },
        {
            headerText: 'Current Stage',
            field: 'ShipCountry',
            allowSorting: false,
        },
        {
            headerText: 'Created',
            field: 'createdAt',
            allowSorting: true,
            template: () =>
                new Date('02/04/2023').toLocaleString(),
        },
        {
            headerText: 'Updated',
            field: 'updatedAt',
            allowSorting: true,
            template: () =>
                new Date('02/04/2023').toLocaleString(),
        },
    ];

    const getTableColumns = (
        aliases,
        selectedFiles
    ) => {

        return [
            ...defaultColumns,
            ...aliases.map(
                (e) => ({
                    headerText: e.headerText,
                    field: e.field,
                    allowSorting: true,
                    template: () => {
                        switch (e.type) {
                            case 'date':
                                return new Date('03/09/2019').toLocaleString();

                            case 'file':
                                return (
                                    <div>
                                        <CheckBoxComponent label="" />
                                        <ButtonComponent cssClass='e-icons e-file-document'>File</ButtonComponent>
                                    </div>
                                );
                        }
                    },
                })
            ),
        ];
    };
    const columns = getTableColumns(aliasesArray, defaultColumns);
    return (<div className='control-pane' style={{ marginTop: '50px' }}>
        <div className='control-section'>

            <GridComponent dataSource={data} allowPaging={true} pageSettings={{ pageSize: 10 }}>
                <ColumnsDirective>
                    {columns.map(col => (
                        <ColumnDirective
                            key={col.field}
                            field={col.field}
                            headerText={col.headerText}
                            visible={col.visible ?? true}
                            width={col.width ?? '100px'}
                            allowSorting={col.allowSorting ?? false}
                            template={col.template}
                        />
                    ))}
                </ColumnsDirective>
            </GridComponent>
        </div>
    </div>);
}

export default AppComponent;

