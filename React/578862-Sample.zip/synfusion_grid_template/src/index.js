import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App'
import { registerLicense } from '@syncfusion/ej2-base';

registerLicense('')
createRoot(document.getElementById('App')).render(<App/>);