export default function template(props) {
    if (!props.Time) return null;
    return props.Time + ' x';
}