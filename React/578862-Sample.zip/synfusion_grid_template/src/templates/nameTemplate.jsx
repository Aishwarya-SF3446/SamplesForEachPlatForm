import React from "react"

export default function template(props) {
    return (
        <div id='identifierTemplate'>
            <img src={'/images/' + (props.Name.startsWith('A') ? 'G.jpg' : props.Name.startsWith('UNI') ? 'H.jpg' : 'I.jpg')} />
            <p>{props.Name}</p>
        </div>);
}