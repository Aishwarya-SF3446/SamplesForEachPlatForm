import React from "react"

export function t2Template(props) {
    if (!props.T2) return null;
    return <span style={{color: 'purple'}}>{props.T2} A</span>
}

export function t1Template(props) {
    if (!props.T1) return null;
    return <span style={{color: 'green'}}>{props.T1} B</span>
}