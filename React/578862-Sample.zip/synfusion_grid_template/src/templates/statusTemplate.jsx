export default function template(props) {
    let value = '';
    switch (props.Status) {
        case 0: value = 'status_A';
        break;
        case 1: value = 'status_1';
        break;
        case 2: value = '2_status';
        break;
        case 3: value = 'status_B';
        break;
        case 4: value = 'Status';
        break;
        case 5: value = 'status_Z';
        break;
        default: value = 'status_default';
        break;
    }
    return value;
}