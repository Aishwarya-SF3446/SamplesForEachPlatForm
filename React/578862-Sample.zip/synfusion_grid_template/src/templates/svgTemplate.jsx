import React from "react"

export default function template(props) {
    return <img src={"/images/" + (props.Name.startsWith('A') ? 'svg_1.svg' : props.Name.startsWith('B') ? 'svg_2.svg' : 'svg_3.svg')}/>
}