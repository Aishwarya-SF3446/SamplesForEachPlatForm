<template>
  <div id="app">
  <ejs-grid :dataSource="data" >
  <e-columns>
  <e-column field='OrderID' headerText='Order ID'></e-column>
  <e-column field='CustomerID' headerText='Customer ID'></e-column>
  <e-column field='ShipCountry' headerText='Ship Country'></e-column>
  </e-columns>
  </ejs-grid>
  </div>
  </template>
  <script>
  import Vue from "vue";
  import { GridPlugin } from "@syncfusion/ej2-vue-grids";



  Vue.use(GridPlugin);



  export default {
    data() {
      return {
        data: [
            {'OrderID': 10248,'CustomerID': 'VINET', 'ShipCountry': 'France'},
            {'OrderID': 10249,'CustomerID': 'TOMSP', 'ShipCountry': 'Germany'},
            {'OrderID': 10250,'CustomerID': 'HANAR', 'ShipCountry': 'Brazil' },
            {'OrderID': 10251,'CustomerID': 'VICTE', 'ShipCountry': 'France'}
        ],
      };
    },
  }
  </script>
  <style>
  @import '../node_modules/@syncfusion/ej2-base/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-buttons/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-calendars/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-dropdowns/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-inputs/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-navigations/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-popups/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-splitbuttons/styles/material.css';
  @import '../node_modules/@syncfusion/ej2-notifications/styles/material.css';
  @import "../node_modules/@syncfusion/ej2-vue-grids/styles/material.css";
  </style>
