
<template>
  <ejs-grid :dataSource="data" :toolbar="toolbarOptions">
<e-columns>
  <e-column field="OrderID" headerText="Order ID" textAlign="Right" width="100"></e-column>
  <e-column field="CustomerID" headerText="Customer ID"  width="80"></e-column>
  <e-column field="ShipCountry" headerText="Ship Country" width="90"></e-column>
</e-columns>
  </ejs-grid>
</template>
<script>
import { GridComponent, ColumnsDirective, ColumnDirective, Page, Toolbar} from "@syncfusion/ej2-vue-grids";

export default {
  name: "App",
  // Declaring component and its directives
components: {
  "ejs-grid": GridComponent,
  "e-columns": ColumnsDirective,
  "e-column": ColumnDirective,
},
provide: {
grid: [Page, Toolbar]
  },
  // Bound properties declarations
  data() {
return {
  data: [
    {
      OrderID: 10248,
      CustomerID: "VINET",
      ShipCountry: "France",
    },
    {
      OrderID: 10249,
      CustomerID: "TOMSP",
      ShipCountry: "Germany",
    },
    {
      OrderID: 10250,
      CustomerID: "HANAR",
      ShipCountry: "France",
    },
    {
      OrderID: 10251,
      CustomerID: "SUPRD",
      ShipCountry: "Germany",
    },
    {
      OrderID: 10252,
      CustomerID: "VICTE",
      ShipCountry: "France",
    },
    {
      OrderID: 10253,
      CustomerID: "MUDPR",
      ShipCountry: "Germany",
    }
  ],
  toolbarOptions: ["Print"]
};
  },
};
</script>

<style>
@import "../node_modules/@syncfusion/ej2-vue-grids/styles/material.css";
</style>