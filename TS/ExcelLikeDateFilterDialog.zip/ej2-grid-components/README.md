# Provided contains operator support for date column in excel filter search action at sample level.

Due to the complexity of replicating the filter dialog found in Microsoft Excel for date columns, there may be a delay in rendering this feature which could impact the performance of the component. As a solution, we have incorporated this functionality at the sample level by utilizing the EJ2 TreeView component to display the date column filter dialog similar to that in Microsoft Excel. 


  
## Microsoft Excel Filter Dialog:

![Description](./Excel.png)


## Syncfusion Grid Excel Filter dialog:


![Description](./Syncfusion.png)