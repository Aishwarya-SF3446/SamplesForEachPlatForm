import { formatUnit, Browser, isNullOrUndefined, EventHandler, KeyboardEventArgs } from '@syncfusion/ej2-base';
import { VirtualInfo, InterSection, Column } from './interfaces';
import { InterSectionObserver } from './intersection-observer';
import { isGroupAdaptive, getScrollBarWidth, parentsUntil } from './util';
import { SfGrid } from './sf-grid-fn';

/**
 * VirtualContentRenderer
 * @hidden
 */
export class VirtualContentRenderer {
    private parent: SfGrid;
    private count: number;
    private maxPage: number;
    private maxBlock: number;
    private prevHeight: number = 0;
    public observer: InterSectionObserver;
    private preStartIndex: number = 0;
    private preEndIndex: number;  
    private preventEvent: boolean = false;
    private actions: string[] = ['filtering', 'clearfiltering', 'searching', 'grouping', 'ungrouping','Filtering', 'ClearFiltering', 'Searching', 'Grouping', 'Ungrouping', 'UnGrouping'];
    private content: HTMLElement;
    private offsets: { [x: number]: number } = {};
    private tmpOffsets: { [x: number]: number } = {};
    private offsetKeys: string[] = [];
    private prevInfo: VirtualInfo;
    private currentInfo: VirtualInfo = {};
    private contentPanel: Element;
    private isScrollByNavigation: boolean;
    private nextRowToNavigate: number = 0;
    private isScrollFromFocus: boolean;
    private  translateMaskY : number;
    private  translateMaskX : number;
    private movableTranslateX: number;
    private movableTranslateY: number;
    private isScrollByFocus: boolean;
    private isHeaderNavigated: boolean;
    private scrollTimer: number;

    /** @hidden */
    public virtualEle: VirtualElementHandler;
    /** @hidden */
    public activeKey: string;
    /** @hidden */
    public rowIndex: number;
    /** @hidden */
    public requestType: string;
    /** @hidden */
    public startColIndex: number;
    /** @hidden */
    public endColIndex: number;  
    /** @hidden */
    public vHelper: VirtualHelper;
    /** @hidden */
    public header: VirtualHeaderRenderer;
    /** @hidden */
    public startIndex: number = 0;
    /** @hidden */
    public movableColumnIndex: number;
    /** @hidden */
    public selectedCellNavigation: number = -1;
    /** @hidden */
    public selectedRowNavigation  : number = -1;
    /** @hidden */
    public selectedRowIndex  : number = -1;
    /** @hidden */
    public focusColumnIndex : number = -1;
    /** @hidden */
    public isScrollIntoview : boolean = false;
    /** @hidden */
    public scrollInfo : VirtualInfo = {};


    constructor(parent: SfGrid) {
        this.parent = parent;
        this.contentPanel = this.parent.element.querySelector(".e-gridcontent");
        this.vHelper = new VirtualHelper(parent);
        this.virtualEle = new VirtualElementHandler(parent); 
        this.addEventListener();
    }

    /**
     * Get the header content div element of grid 
     * @return {Element} 
     */
    public getPanel(): Element {
        return this.contentPanel;
    }

    /**
     * Get the header table element of grid
     * @return {Element} 
     */
    public getTable(): Element {
        return this.contentPanel.querySelector('.e-table');
    }
    
    public renderTable(): void {
        this.header = this.parent.virtualHeaderModule;
        this.virtualEle.table = <HTMLElement>this.getTable();
        this.virtualEle.content = this.content = <HTMLElement>this.getPanel().querySelector('.e-content');
        this.virtualEle.renderWrapper(Number(this.parent.options.height));
        this.virtualEle.renderPlaceHolder();
        let content: HTMLElement = this.content;
        let opt: InterSection = {
            container: content, pageHeight: this.getBlockHeight() * 2, debounceEvent: true,
            axes: this.parent.options.enableColumnVirtualization ? ['X', 'Y'] : ['Y'],
            totalItems: this.parent.options.totalItemCount,
            overscanCount : this.parent.options.overscanCount,
        };
        this.observer = new InterSectionObserver(this.virtualEle.wrapper, opt);
        this.parent.dotNetRef.invokeMethodAsync("SetRowHeight", this.parent.getRowHeight());
    }

	private addEventListener(): void {
		EventHandler.add(this.parent.element, 'keydown', this.keyDownHandler, this);
    }
    
	public removeEventListener(): void {
        if (!isNullOrUndefined(this.observer)) {
            this.observer.disconnect();
        }
        this.getPanel().firstElementChild.scrollTop = 0;
        this.getPanel().firstElementChild.scrollLeft = 0;
		EventHandler.remove(this.parent.element, 'keydown', this.keyDownHandler);
	}

	private handleScrollEnd(virtualRefreshArgs: object, translatey: number, isWheelScroll: boolean, isScrollByNavigation: boolean): void {
		if (!isWheelScroll && !isScrollByNavigation) {
            this.parent.dotNetRef.invokeMethodAsync("VirtualRefresh", virtualRefreshArgs, translatey, this.selectedRowIndex, this.isScrollIntoview, this.focusColumnIndex);
		}
        if (isScrollByNavigation) {
            this.isScrollByNavigation = false;
        }
    }

    public ensurePageSize(): void {
        let rowHeight: number = this.parent.getRowHeight();
        let vHeight: string | number = this.parent.options.height.toString().indexOf('%') < 0 ? this.content.getBoundingClientRect().height :
        this.parent.element.getBoundingClientRect().height;
        let blockSize: number = ~~(<number>vHeight / rowHeight);
        let height: number =  blockSize * 2;
        let size: number = this.parent.options.pageSize;
        let actualPageSize : number= size < height && this.parent.options.overscanCount == 0 ? height : size;
        this.parent.dotNetRef.invokeMethodAsync("SetPageSizeAndCIndex", {
            pageSize: actualPageSize,
            startColumnIndex: this.startColIndex,
            endColumnIndex: this.endColIndex,
            VTableWidth: this.getColumnOffset(this.endColIndex) - this.getColumnOffset(this.startColIndex - 1) + ''
        });
        this.parent.options.pageSize = actualPageSize;
        this.observer.options.pageHeight = this.getBlockHeight() * 2
    }

    private scrollListener(scrollArgs: ScrollArg): void {
        const _this: VirtualContentRenderer = this;
        if (this.parent.options.enablePersistence) {
            this.parent.scrollPosition = scrollArgs.offset;
        }
        if (this.preventEvent) { this.preventEvent = false; return; }
        // if (this.preventEvent || this.parent.isDestroyed) { this.preventEvent = false; return; }
        let info: SentinelType = scrollArgs.sentinel;
        let pStartIndex: number = this.preStartIndex;
        let previousColIndexes: number[] = this.parent.getColumnIndexesInView();
        let viewInfo: VirtualInfo = this.currentInfo = this.getInfoFromView(scrollArgs.direction, info, scrollArgs.offset);
        let translateXValue: number = this.parent.options.enableColumnVirtualization && this.parent.options.enableRtl ? -1 * this.getColumnOffset(viewInfo.columnIndexes[0] - 1, true) : this.getColumnOffset(viewInfo.columnIndexes[0] - 1, true);
        
        if (this.parent.options.enableColumnVirtualization &&
        (JSON.stringify(previousColIndexes) !== JSON.stringify(viewInfo.columnIndexes))) {
            let viewColumnsList: Column[] = this.parent.options.virtualizedColumns;
            for(let i = 0; i < viewColumnsList.length; i++){
                if(viewColumnsList[i].autoFit){
                    this.parent.resizeModule.autoFitColumns(viewColumnsList[i].field);
                }
            }
            
            let translateX: number = this.parent.options.enableColumnVirtualization && this.parent.options.enableRtl ? -1 * this.getColumnOffset(this.startColIndex - 1, true) : this.getColumnOffset(this.startColIndex - 1, true);
            let width: string = this.parent.options.enableColumnVirtualization && this.parent.options.enableRtl ? -1 * this.getColumnOffset(this.endColIndex, true) + translateX + '' : this.getColumnOffset(this.endColIndex, true) - translateX + '';
            let translatey = !isNullOrUndefined(viewInfo.endIndex) ? (viewInfo.endIndex - this.parent.options.pageSize) * (this.parent.options.rowHeight ? this.parent.options.rowHeight : this.parent.getRowHeight()) : 0;
            this.movableTranslateY = !isNullOrUndefined(this.movableTranslateY) ? this.movableTranslateY : 0;
            let virtualRefreshArgs = {
                requestType: 'virtualscroll',
                isHeaderNavigated: _this.isHeaderNavigated,
                selectedRowNavigation  : _this.selectedRowNavigation  ,
                selectedCellNavigation: _this.selectedCellNavigation,
                isScrollByFocus: _this.isScrollByFocus,
                startColumnIndex: viewInfo.columnIndexes[0],
                endColumnIndex: viewInfo.columnIndexes[viewInfo.columnIndexes.length - 1],
                axis: 'X',
                VTablewidth: width,
                translateX: translateXValue,
                translateY: (_this.parent.options.enableVirtualMaskRow && _this.parent.options.enableVirtualization) ? _this.parent.options.frozenColumns ? _this.movableTranslateY : _this.translateMaskY + _this.movableTranslateY : 0
            };
            clearTimeout(this.scrollTimer);
            this.scrollTimer = setTimeout(function() {
                _this.handleScrollEnd(virtualRefreshArgs, translatey, scrollArgs.isWheelScroll, false);
            }, 100);
            setTimeout(() => {
                _this.parent.dotNetRef.invokeMethodAsync("RemoveValidationPopup");
                if(scrollArgs.isWheelScroll) {
                    _this.parent.dotNetRef.invokeMethodAsync("VirtualRefresh", virtualRefreshArgs, translatey, _this.selectedRowIndex, _this.isScrollIntoview, _this.focusColumnIndex);
                }
		_this.isScrollByFocus = false;
            }, 0);
        }
        else { 
            if ((this.currentInfo.direction === "left" || this.currentInfo.direction === "right") && this.parent.options.enableVirtualMaskRow) {            
                this.virtualEle.adjustTable(translateXValue, this.translateMaskY);
            }      
        }
        this.parent.setColumnIndexesInView(this.parent.options.enableColumnVirtualization ? viewInfo.columnIndexes : []);
        if (this.isScrollByNavigation) {
            clearTimeout(this.scrollTimer);
            this.scrollTimer = setTimeout(function() {
                _this.handleScrollEnd(null, 0, null, true);
            }, 100);
        } else {
            this.nextRowToNavigate = 0;
        }
        if (this.preStartIndex !== pStartIndex && this.parent.options.enableVirtualization) {
            this.parent.options.currentPage = viewInfo.currentPage;
            var isCalledFromScrollIntoView = _this.isScrollIntoview;
            var nextRowToFocus = this.nextRowToNavigate;
            setTimeout(() => {
                _this.parent.dotNetRef.invokeMethodAsync("VirtualRefresh", {
                    requestType: 'virtualscroll',
                    nextRowToNavigate: nextRowToFocus,
                    virtualStartIndex: (viewInfo.endIndex - _this.parent.options.pageSize),
                    virtualEndIndex: viewInfo.endIndex,
                    axis: 'Y',
                    RHeight: _this.parent.getRowHeight()
                }, (viewInfo.endIndex - _this.parent.options.pageSize) * (_this.parent.options.rowHeight ? _this.parent.options.rowHeight : _this.parent.getRowHeight()), _this.selectedRowIndex, isCalledFromScrollIntoView, _this.focusColumnIndex);
            }, 0);
            _this.isScrollIntoview = false;
        }
        else if (_this.selectedRowIndex >= 0 && this.preStartIndex === pStartIndex && _this.isScrollIntoview && (this.currentInfo.direction === "up" || this.currentInfo.direction === "down")) {

            _this.parent.dotNetRef.invokeMethodAsync("SelectRow", _this.selectedRowIndex, _this.isScrollIntoview, _this.focusColumnIndex);
            _this.selectedRowIndex = -1;
            _this.isScrollIntoview = false;
        }
        this.prevInfo = viewInfo;
    }

    public setColVTableWidthAndTranslate(args?: {refresh: boolean, axis: string}): void {
        if (this.parent.options.enableColumnVirtualization && this.prevInfo &&
            (JSON.stringify(this.currentInfo.columnIndexes) !==
            JSON.stringify(this.prevInfo.columnIndexes)) || ((args && args.refresh))) {
            let translateX: number = this.getColumnOffset(this.startColIndex - 1);
            let width: string =  this.getColumnOffset(this.endColIndex) - translateX + '';
            if (this.parent.options.frozenColumns === 0)
            {
                this.header.virtualEle.setWrapperWidth(width);
                this.virtualEle.setWrapperWidth(width);
                this.parent.getContentTable().parentElement.style.width = width + 'px';
            }
            this.header.virtualEle.adjustTable(this.movableTranslateX, 0);
            if (this.parent.options.enableColumnVirtualization && args.axis === 'X') {
                if (!this.parent.options.enableVirtualization) {
                    this.virtualEle.adjustTable(this.movableTranslateX, 0);
                } else {
                    let existingTranslateY: string = this.virtualEle.extractTranslateY(this.virtualEle.wrapper.style.transform);
                    this.virtualEle.adjustTable(this.movableTranslateX, parseInt(existingTranslateY.replace('px', '')));
                }
            }
        }
    }

	public refreshOnDataChange(): void {
        this.getPanel().firstElementChild.scrollTop = 0;
        this.getPanel().firstElementChild.scrollLeft = 0;
        if (this.parent.options.enableColumnVirtualization) {
            this.header.virtualEle.adjustTable(0, 0);
        }
        this.virtualEle.adjustTable(0,0);
        this.refreshOffsets();
        this.refreshVirtualElement();
   }

    // private block(blk: number): boolean {
    //     return this.vHelper.isBlockAvailable(blk);
    // }

    private keyDownHandler(e: KeyboardEventArgs): void {
        if (!isNullOrUndefined(this.observer)) {
            this.observer.blazorActiveKey = (e.key === 'ArrowDown' || e.key === 'ArrowUp') ? e.key : '';
        }
    }
    
    public focusCell(cell: HTMLElement, action: string, keyCombination?: string): void {
        let rowHeight: number = this.parent.getRowHeight();
        let content: HTMLElement = this.parent.getContent();
        let cellDOMRect: ClientRect = cell.getBoundingClientRect();
        let contentDOMRect : ClientRect = content.getBoundingClientRect();

        if (action == "MoveRightCell") {
            if (this.selectedCellNavigation == -1) {
                this.selectedCellNavigation =  Number(cell.getAttribute('data-colindex'));
            } else if (this.selectedCellNavigation + 1 == Number(cell.getAttribute('data-colindex'))) {
                this.selectedCellNavigation++;
            }
        } else if (action == "MoveLeftCell") {
            if (this.selectedCellNavigation == -1) {
                this.selectedCellNavigation = Number(cell.getAttribute('data-colindex'));
            } else if (this.selectedCellNavigation - 1 == Number(cell.getAttribute('data-colindex'))) {
                this.selectedCellNavigation--;
            }
        }
        if (action == "MoveDownCell" || action == "MoveUpCell") {
            cell.focus({ preventScroll: true });
        } else if (action == "MoveRightCell" || action == "MoveLeftCell") {
            if (!isNullOrUndefined(parentsUntil(cell, 'e-row'))) {
                this.isHeaderNavigated = false;
                this.selectedRowNavigation   = Number(parentsUntil(cell, 'e-row').getAttribute('data-rowindex'));
            } else {
                this.isHeaderNavigated = true;
            }
            this.isScrollByFocus = true;
            cell.focus();
        }
        if (action == "MoveDownCell" && cellDOMRect.bottom > contentDOMRect.top +
            contentDOMRect.height - getScrollBarWidth()) {
            this.isScrollByNavigation = true;
            content.scrollTop = content.scrollTop + rowHeight;
        } else if (action == "MoveUpCell" && cellDOMRect.bottom < contentDOMRect.top + rowHeight) {
            this.isScrollFromFocus = true;
            this.isScrollByNavigation = true;
            content.scrollTop = content.scrollTop - rowHeight;
        }

        if(keyCombination == "AltW" || keyCombination == "CtrlHome" || keyCombination == "CtrlEnd" || keyCombination == "Home" || keyCombination == "End" || (keyCombination == null && action == null))
        {
	    //keyCombination == null && action == null -> We get this when clicking Cancel in Add form
            cell.focus();
        }
    }

    private getInfoFromView(direction: string, info: SentinelType, e: Offsets): VirtualInfo {
        let isBlockAdded: boolean = false;
        // let tempBlocks: number[] = [];
        let infoType: VirtualInfo = { direction: direction, sentinelInfo: info, offsets: e,
            startIndex: this.preStartIndex, endIndex: this.preEndIndex };
        let vHeight: string | number = this.parent.options.height.toString().indexOf('%') < 0 ? this.content.getBoundingClientRect().height :
            this.parent.element.getBoundingClientRect().height;
        infoType.page = this.getPageFromTop(e.top + vHeight, infoType);
        infoType.blockIndexes = this.vHelper.getBlockIndexes(infoType.page);
        // infoType.blockIndexes = tempBlocks = this.vHelper.getBlockIndexes(infoType.page);
        // infoType.loadSelf = !this.vHelper.isBlockAvailable(tempBlocks[infoType.block]);
        // let blocks: number[] = this.ensureBlocks(infoType);
        // if (this.activeKey === 'upArrow' && infoType.blockIndexes.toString() !== blocks.toString()) {
        //     // To avoid dupilcate row index problem in key focus support
        //     let newBlock: number = blocks[blocks.length - 1];
        //     if (infoType.blockIndexes.indexOf(newBlock) === -1) {
        //         isBlockAdded = true;
        //     }
        // }
        // infoType.blockIndexes = blocks;
        // infoType.loadNext = !blocks.filter((val: number) => tempBlocks.indexOf(val) === -1)
        //     .every(this.block.bind(this));
        // infoType.event = (infoType.loadNext || infoType.loadSelf) ? 'modelChanged' : 'refreshVirtualBlock';
        // if (isBlockAdded) {
        //     infoType.blockIndexes = [infoType.blockIndexes[0] - 1, infoType.blockIndexes[0], infoType.blockIndexes[0] + 1];
        // }
        infoType.columnIndexes = info.axis === 'X' ? this.vHelper.getColumnIndexes() : this.parent.getColumnIndexesInView();

        //Row Start and End Index calculation
        let rowHeight: number = this.parent.getRowHeight();
        let exactTopIndex: number = e.top / rowHeight;
        let noOfInViewIndexes: number = vHeight / rowHeight;
        let exactEndIndex: number = exactTopIndex + noOfInViewIndexes;
        let pageSizeBy4: number = this.parent.options.pageSize / 4;
        let totalCount: number = this.parent.options.groupCount ? this.getVisibleGroupedRowCount() : this.count;
        if (infoType.direction === 'down' && !this.isScrollFromFocus) {
            let sIndex: number = Math.round(exactEndIndex) - Math.round((pageSizeBy4));
            if (this.parent.options.enableVirtualMaskRow) {
                noOfInViewIndexes = Math.ceil(noOfInViewIndexes) - 1;
                let differenceOfRowIndex: number = Math.ceil(exactTopIndex) - this.preStartIndex;
                if (differenceOfRowIndex >= noOfInViewIndexes) {
                    infoType.startIndex = Math.ceil(exactTopIndex) >= 0 ? Math.ceil(exactTopIndex) : 0;
                    let eIndex: number = infoType.startIndex + this.parent.options.pageSize;
                    infoType.endIndex = eIndex < totalCount ? eIndex : totalCount;
                    infoType.startIndex = eIndex >= totalCount ? (infoType.endIndex - this.parent.options.pageSize < 0 ? 0 : infoType.endIndex - this.parent.options.pageSize) : infoType.startIndex;
                    infoType.currentPage = Math.ceil(infoType.endIndex / this.parent.options.pageSize);
                    this.isScrollFromFocus = false;
                    this.preStartIndex = this.startIndex = infoType.startIndex;
                    this.preEndIndex = infoType.endIndex;
                } else {
                    this.isScrollFromFocus = false;
                    this.preStartIndex = this.preStartIndex;
                    this.preEndIndex = this.preEndIndex;
                }
            }

            if (!this.parent.options.enableVirtualMaskRow && isNullOrUndefined(infoType.startIndex) || (exactEndIndex >
            (infoType.startIndex + Math.round((this.parent.options.pageSize / 2 + pageSizeBy4)))
            && infoType.endIndex !== totalCount)) {
                infoType.startIndex = sIndex >= 0 ? Math.round(sIndex) : 0;
                infoType.startIndex = infoType.startIndex > exactTopIndex ? Math.floor(exactTopIndex) : infoType.startIndex;
                let eIndex: number = infoType.startIndex + this.parent.options.pageSize;
                infoType.startIndex = eIndex < exactEndIndex ? (Math.ceil(exactEndIndex) - this.parent.options.pageSize)
                : infoType.startIndex;
                infoType.endIndex =  eIndex < totalCount ? eIndex : totalCount;
                infoType.startIndex = eIndex >= totalCount ? (infoType.endIndex - this.parent.options.pageSize > 0 ? infoType.endIndex - this.parent.options.pageSize : 0) : infoType.startIndex;
                infoType.currentPage = Math.ceil(infoType.endIndex / this.parent.options.pageSize);
            }
            let selectedIndexes: number[] = this.parent.getSelectedRowIndexes(true);
            this.nextRowToNavigate = selectedIndexes.length > 0 ? selectedIndexes[selectedIndexes.length - 1] - 1 : -1;
        } else if (infoType.direction === 'up') {
            if (infoType.startIndex && infoType.endIndex || this.parent.options.enableVirtualMaskRow) {
                let loadAtIndex: number = Math.round(((infoType.startIndex * rowHeight) + (pageSizeBy4 * rowHeight)) / rowHeight);
                if (this.parent.options.enableVirtualMaskRow) {
                    noOfInViewIndexes = Math.ceil(noOfInViewIndexes);
                    if (exactTopIndex < loadAtIndex || Math.ceil(exactTopIndex) > this.preStartIndex) {
                        let startIndex: number = Math.ceil(exactTopIndex) > 0 ? Math.ceil(exactTopIndex) : 0;
                        let customStartIndex: number = totalCount - this.parent.options.pageSize - (this.parent.options.pageSize / 2);
                        let endValue : number = totalCount - this.parent.options.pageSize;
                        if (exactTopIndex < totalCount && customStartIndex <= exactTopIndex && !(endValue <= exactEndIndex && exactEndIndex <= totalCount)) {
                            infoType.startIndex = startIndex > 0 ? startIndex - (this.parent.options.pageSize / 2) : 0;
                        } else {
                            infoType.startIndex = startIndex > 0 ? startIndex + this.parent.options.pageSize > totalCount ? totalCount - this.parent.options.pageSize : startIndex : 0;
                        }
                        infoType.startIndex = infoType.startIndex > 0 ? infoType.startIndex - 1 : infoType.startIndex;
                        let eIndex: number = infoType.startIndex + this.parent.options.pageSize;
                        infoType.endIndex = infoType.startIndex <= 0 ? this.parent.options.pageSize : eIndex < totalCount ? eIndex : totalCount;
                        infoType.startIndex = infoType.startIndex < 0 || this.parent.options.totalItemCount <= this.parent.options.pageSize ? 0 : infoType.startIndex;
                        infoType.currentPage = Math.ceil(infoType.startIndex / this.parent.options.pageSize);
                        this.isScrollFromFocus = false;
                        this.preStartIndex = this.startIndex = infoType.startIndex;
                        this.preEndIndex = infoType.endIndex;
                    } else {
                        this.isScrollFromFocus = false;
                        this.preStartIndex = this.preStartIndex;
                        this.preEndIndex = this.preEndIndex;
                    }
                }
                if (exactTopIndex < loadAtIndex && !this.parent.options.enableVirtualMaskRow) {
                    let idxAddedToExactTop: number = (pageSizeBy4) > noOfInViewIndexes ? pageSizeBy4 :
                    (noOfInViewIndexes + noOfInViewIndexes / 4);
                    let eIndex: number = Math.round(exactTopIndex + idxAddedToExactTop);
                    infoType.endIndex = eIndex < totalCount ? eIndex : totalCount;
                    let sIndex: number = infoType.endIndex - this.parent.options.pageSize;
                    infoType.startIndex = sIndex > 0 ? sIndex : 0;
                    infoType.endIndex = sIndex < 0 ? this.parent.options.pageSize : infoType.endIndex;
                    infoType.currentPage = Math.ceil(infoType.startIndex / this.parent.options.pageSize);
                }
                let selectedIndexes: number[] = this.parent.getSelectedRowIndexes(true);
                this.nextRowToNavigate = selectedIndexes.length > 0 ? selectedIndexes[0] + 1 : -1;
            }
        }
        if (!this.parent.options.enableVirtualMaskRow) {
            this.isScrollFromFocus = false;
            this.preStartIndex = this.startIndex = infoType.startIndex;
            this.preEndIndex = infoType.endIndex;
        }
        return infoType;
    }

    public onDataReady(): void {
        let _this: VirtualContentRenderer = this;
        this.observer.options.totalItems = this.parent.options.totalItemCount;
        this.bindScrollEvent();
        this.count = this.parent.options.totalItemCount;
        this.maxPage = Math.ceil(this.count / this.parent.options.pageSize);
        // this.vHelper.checkAndResetCache(this.parent.options.requestType);
        if (['Refresh', 'Filtering', 'ClearFiltering','Searching', 'Grouping', 'UnGrouping', 'Reorder', 'RowDragAndDrop',
            'refresh', 'filtering', 'clearfiltering','searching', 'grouping', 'ungrouping', 'reorder', "GroupExpandCollapse", "InfiniteScrolling", null]
            .some((value: string) => { return this.parent.options.requestType === value; })) {
            this.refreshOffsets();
        }
        this.setVirtualHeight();
		this.parent.scrollModule.refresh();
        this.resetScrollPosition(this.parent.options.requestType);
        this.setColVTableWidthAndTranslate();
        
            if(((this.parent.options.enableVirtualMaskRow && this.parent.options.enableVirtualization) || this.parent.options.enableLazyLoading) && this.parent.options.requestType != "GroupExpandCollapse")
            {
                let rowHeight: number =  this.parent.options.rowHeight;
                let yValue: number = (this.currentInfo.endIndex - this.parent.options.pageSize) * (rowHeight? rowHeight : this.parent.getRowHeight());
                yValue = yValue.toString() == "NaN" ? 0 : yValue;
                
                if (this.parent.options.overscanCount > 0 && this.currentInfo.startIndex > this.parent.options.overscanCount && this.currentInfo.endIndex != this.parent.options.totalItemCount) {
                    yValue = yValue - ((this.parent.options.pageSize + this.parent.options.overscanCount) * (rowHeight ? rowHeight : this.parent.getRowHeight()));
                }
                else {
                    yValue = yValue - (this.parent.options.pageSize * (rowHeight ? rowHeight : this.parent.getRowHeight()));
                }

                if (this.count == 0) {
                    yValue = 0;
                }
                if (!isNullOrUndefined(this.currentInfo.startIndex) && this.currentInfo.startIndex != 0 && !isNullOrUndefined(this.currentInfo.endIndex) && this.currentInfo.endIndex !== this.parent.options.totalItemCount) {
                    yValue -= 20;
                }

                if((this.parent.options.overscanCount > 0 && (this.parent.options.totalItemCount !== this.currentInfo.endIndex || this.currentInfo.direction == 'up')) || this.parent.options.overscanCount == 0){
                    setTimeout(() => {
                        _this.translateMaskY = yValue;
                        _this.translateMaskX = isNullOrUndefined(_this.translateMaskX) ? 0 : _this.translateMaskX;
        
                        if (_this.parent.options.frozenColumns == 0)
                            _this.virtualEle.wrapper.style.transform = "translate(" + _this.translateMaskX + "px," + yValue + "px)";
                        else
                            _this.virtualEle.wrapper.style.transform = "translate(0px," + yValue + "px)";
                    }, 0);
                }
                
            }
        this.prevInfo = this.prevInfo ? this.prevInfo : this.vHelper.getData();
    }

    /** @hidden */
    public setVirtualHeight(): void {
        let columnsCount: Column[] = this.parent.options.columns.filter((e) => e.visible);
        let width: string = this.parent.options.enableColumnVirtualization ?
        this.getColumnOffset(columnsCount.length - 1) + 'px' : '100%';
        let virtualHeight: number = 0;
        let totalItemRowHeight: number = this.parent.options.totalItemCount * this.parent.getRowHeight();
        let pageSizeRowHeight: number = this.parent.options.pageSize * this.parent.getRowHeight();
        if (this.parent.options.enableVirtualMaskRow) {
            if (this.parent.options.frozenColumns && this.parent.options.enableColumnVirtualization) {
                virtualHeight = totalItemRowHeight - (2 * pageSizeRowHeight);
            }
            else {
                virtualHeight = totalItemRowHeight;
            }
        }
        else if (this.parent.options.groupCount) {
            virtualHeight = this.parent.options.visibleGroupedRowsCount * this.parent.getRowHeight()
        }
        else if (this.parent.options.enableVirtualization) {
            virtualHeight = this.parent.options.frozenColumns && this.parent.options.enableColumnVirtualization ? totalItemRowHeight - pageSizeRowHeight : totalItemRowHeight;
        }
        this.virtualEle.setVirtualHeight(virtualHeight, width);
        if (this.parent.options.enableColumnVirtualization) {
            this.header.virtualEle.setVirtualHeight(1, width);
        }
    }

    private getPageFromTop(sTop: number, info: VirtualInfo): number {
        let total: number = (isGroupAdaptive(this.parent)) ? this.getGroupedTotalBlocks() : this.getTotalBlocks();
        let page: number = 0; let extra: number = this.offsets[total] - this.prevHeight;
        this.offsetKeys.some((offset: string) => {
            let iOffset: number = Number(offset);
            let border: boolean = sTop <= this.offsets[offset] || (iOffset === total && sTop > this.offsets[offset]);
            if (border) {
                info.block = iOffset % 2 === 0 ? 1 : 0;
                page = Math.max(1, Math.min(this.vHelper.getPage(iOffset), this.maxPage));
            }
            return border;
        });
        return page;
    }

    protected getTranslateY(sTop: number, cHeight: number, info?: VirtualInfo, isOnenter?: boolean): number {
        if (info === undefined) {
            info = { page: this.getPageFromTop(sTop + cHeight, {}) };
            info.blockIndexes = this.vHelper.getBlockIndexes(info.page);
        }
        let block: number = (info.blockIndexes[0] || 1) - 1;
        let translate: number = this.getOffset(block);
        let endTranslate: number = this.getOffset(info.blockIndexes[info.blockIndexes.length - 1]);
        if (isOnenter) {
            info = this.prevInfo;
        }
        let result: number = translate > sTop ?
            this.getOffset(block - 1) : endTranslate < (sTop + cHeight) ? this.getOffset(block + 1) : translate;
        let blockHeight: number = this.offsets[info.blockIndexes[info.blockIndexes.length - 1]] -
            this.tmpOffsets[info.blockIndexes[0]];
        if (result + blockHeight > this.offsets[isGroupAdaptive(this.parent) ? this.getGroupedTotalBlocks() : this.getTotalBlocks()] && this.parent.options.groupCount == 0) {
            result -= (result + blockHeight) - this.offsets[this.getTotalBlocks()];
        }
        return result;
    }

    public getOffset(block: number): number {
        return Math.min(this.offsets[block] | 0, this.offsets[this.maxBlock] | 0);
    }

    private onEntered(): Function {
        return (element: HTMLElement, current: SentinelType, isLightScroll:boolean, direction: string, e: Offsets, isWheel: boolean, check: boolean) => {
            const _this: VirtualContentRenderer = this;
            this.observer.options.isWheelScroll = isWheel;
            if (Browser.isIE && !isWheel && check && !this.preventEvent) {
                //ToDo
                //this.parent.showSpinner();
            }
            let xAxis: boolean = current.axis === 'X'; let top: number = this.prevInfo.offsets ? this.prevInfo.offsets.top : null;
            let height: number = this.content.getBoundingClientRect().height;
            let x: number = xAxis ? this.getColumnOffset(this.vHelper.getColumnIndexes()[0] - 1, true) : this.getColumnOffset(this.prevInfo.columnIndexes[0] - 1);
            x = this.parent.options.enableColumnVirtualization && this.parent.options.enableRtl ? -1 * x : x;
            let y: number = this.getTranslateY(e.top, height, xAxis && top === e.top ? this.prevInfo : undefined, true);
            if (this.currentInfo && this.currentInfo.startIndex && xAxis) {
                let endIndex: number = isNullOrUndefined(this.currentInfo.endIndex) ? 0 : this.currentInfo.endIndex;
                y = (endIndex - this.parent.options.pageSize) * this.parent.getRowHeight();
            }
            this.movableTranslateX = this.vHelper.cOffsets[this.startColIndex - 1] ? this.vHelper.cOffsets[this.startColIndex - 1] : x;
            this.movableTranslateX= this.parent.options.enableColumnVirtualization && this.parent.options.enableRtl ? -1 * this.movableTranslateX :  this.movableTranslateX;
            this.movableTranslateX = this.parent.options.enableColumnVirtualization && this.parent.options.frozenColumns && this.vHelper.mOffsets[this.startColIndex - 1] ? this.vHelper.mOffsets[this.startColIndex - 1] : this.movableTranslateX;
            this.movableTranslateY = this.parent.options.pageSize * (this.parent.options.rowHeight > 0 ? this.parent.options.rowHeight : this.parent.getRowHeight());
            if (!this.parent.options.enableVirtualMaskRow) {
                if(this.parent.options.overscanCount == 0) {
                    if (this.currentInfo.endIndex == this.parent.options.totalItemCount && direction == 'down') {
                        y = this.parent.options.rowHeight != 0 ? this.parent.options.rowHeight * this.currentInfo.startIndex : this.parent.getRowHeight() * this.currentInfo.startIndex;
                        this.virtualEle.adjustTable(this.movableTranslateX, Math.min(y, this.offsets[this.maxBlock]));
                    } else if ((!xAxis || direction == 'up') && this.observer.PreventAdjustTable != 'horizontal') {
                        this.virtualEle.adjustTable(this.movableTranslateX, Math.min(y, this.offsets[this.maxBlock]));
                    }
                }   
            } else if (this.offsets[this.maxBlock] >= y && this.currentInfo.endIndex != this.parent.options.totalItemCount) {
                if (direction == "right" || direction == "left") {
                    let preColIndexesInView: number[] = this.parent.getColumnIndexesInView();
                    let viewInfoCurrent: VirtualInfo = this.getInfoFromView(direction, current, e);
                    if ((JSON.stringify(preColIndexesInView) !== JSON.stringify(viewInfoCurrent.columnIndexes))) {
                        this.virtualEle.adjustTable(this.movableTranslateX, this.translateMaskY + this.movableTranslateY);
                    }
                }
                else {
                    let differenceBlocks = this.parent.options.enableColumnVirtualization ? (this.parent.options.enableVirtualMaskRow ? 4 : 2) : 0;
                    setTimeout(function () {
                        let y1: number = y; 
                        if (_this.parent.options.enableVirtualMaskRow && direction == "down") {
                            y1 = _this.content.scrollTop - (2 * _this.parent.options.pageSize *
                                (_this.parent.options.rowHeight != 0 ? _this.parent.options.rowHeight : _this.parent.getRowHeight()) );
                        }
                        else if (_this.parent.options.overscanCount > 0 && direction == "up" && !isNullOrUndefined(_this.currentInfo.endIndex)) {
                            var scrollTop = (_this.currentInfo.endIndex - _this.parent.options.pageSize) * (_this.parent.options.rowHeight != 0 ? _this.parent.options.rowHeight : _this.parent.getRowHeight());
                            _this.translateMaskY = y = scrollTop - ((_this.parent.options.overscanCount + _this.parent.options.pageSize) * (_this.parent.options.rowHeight != 0 ? _this.parent.options.rowHeight : _this.parent.getRowHeight()));
                        }
                        _this.virtualEle.adjustTable(x, Math.min( isLightScroll ? _this.translateMaskY :(direction == 'down' ? y1  : y), _this.offsets[_this.maxBlock - differenceBlocks]));
                    },0)
                }
            }
            if (xAxis) {
                this.setColVTableWidthAndTranslate({refresh: true, axis: 'X'});
            }
        };
    }


    public bindScrollEvent: Function = () => {
        this.observer.observe((scrollArgs: ScrollArg) => {
            if (this.parent.options.enableVirtualization || this.parent.options.enableColumnVirtualization)
                this.scrollListener(scrollArgs)
        }, this.onEntered());
        let gObj: SfGrid = this.parent;
        if (gObj.options.enablePersistence && gObj.scrollPosition) {
            this.content.scrollTop = gObj.scrollPosition.top;
            let scrollValues: ScrollArg = { direction: 'down', sentinel: this.observer.sentinelInfo.down,
                offset: gObj.scrollPosition, focusElement: gObj.element, isWheelScroll: this.observer.options.isWheelScroll };
            this.scrollListener(scrollValues);
            if (gObj.options.enableColumnVirtualization) {
                this.content.scrollLeft = gObj.scrollPosition.left;
            }
        }
    };


    public getBlockSize(): number {
        return this.parent.options.pageSize >> 1;
    }

    public getBlockHeight(): number {
        return this.getBlockSize() * this.parent.getRowHeight();
    }

    public getGroupedTotalBlocks(): number {
        if (this.parent.options.enableLazyLoading && this.parent.options.enableVirtualization) {
            return this.getTotalBlocks();
        }
        else{
        let visibleRowCount = this.getVisibleGroupedRowCount();
        return Math.floor((visibleRowCount / this.getBlockSize()) < 1 ? 1 : visibleRowCount / this.getBlockSize());
        }
    }

    public getVisibleGroupedRowCount(): number {
        let visibleRowCount: number = Number(this.virtualEle.placeholder.style.height.substring(0,
            this.virtualEle.placeholder.style.height.indexOf('p')))/this.parent.getRowHeight();
            return visibleRowCount;
    }

    public getTotalBlocks(): number {
        return Math.ceil(!isNullOrUndefined(this.count) ? this.count / this.getBlockSize() : 0);
    }

    public getColumnOffset(block: number, isMovable?: boolean): number {
        return this.vHelper.cOffsets[block] | 0;
    }

    private resetScrollPosition(action: string): void {
        var lAction = !isNullOrUndefined(action) ? action.toLowerCase() : action;
        if (this.actions.some((value: string) => value === action) || this.parent.options.filterCount > 0 && !isNullOrUndefined(lAction) && (lAction == 'save' || lAction == 'delete') || (!isNullOrUndefined(this.parent.options.initGroupingField) && this.parent.options.initGroupingField.length > 0 && !isNullOrUndefined(lAction) && (lAction == 'sorting' || lAction == 'save' || lAction == 'delete'))) {
            let content: Element = this.content;
            this.preventEvent = content.scrollTop !== 0;
            content.scrollTop = 0;
        }
    }

    /** @hidden */
    public refreshOffsets(): void {
        let gObj: SfGrid = this.parent;
        let row: number = 0; let bSize: number = this.getBlockSize();
        let total: number = isGroupAdaptive(this.parent) ? this.getGroupedTotalBlocks() : this.getTotalBlocks();
        this.prevHeight = this.offsets[total]; this.maxBlock = total % 2 === 0 ? total - 2 : total - 1; this.offsets = {};
        let vcRows : any = [];
        let cache: any = {};
        //Row offset update
        let blocks: number[] = Array.apply(null, Array(total)).map(() => ++row);
        for (let i: number = 0; i < blocks.length; i++) {
            let tmp: number = (cache[blocks[i]] || []).length;
            let rem: number = !isGroupAdaptive(this.parent) ? this.count % bSize : (vcRows.length % bSize);
            let size: number = !isGroupAdaptive(this.parent) && blocks[i] in cache ?
                tmp * this.parent.getRowHeight() : rem && blocks[i] === total ? rem * this.parent.getRowHeight() :
                this.getBlockHeight();
                // let size: number = this.parent.groupSettings.columns.length && block in this.vHelper.cache ?
                // tmp * getRowHeight() : this.getBlockHeight();
            this.offsets[blocks[i]] = (this.offsets[blocks[i] - 1] | 0) + size;
            this.tmpOffsets[blocks[i]] = this.offsets[blocks[i] - 1] | 0;
        }
        this.offsetKeys = Object.keys(this.offsets);
        //Column offset update
        if (this.parent.options.enableColumnVirtualization) {
            this.vHelper.refreshColOffsets();
        }
    }

    public updateTransform(x: number, y: number, isOverscan : boolean): void {
        let _this: VirtualContentRenderer = this;
        setTimeout(() => {
            _this.translateMaskX = x;
            if(isOverscan){ _this.translateMaskY = y;};
            _this.virtualEle.adjustTable(x, _this.translateMaskY);
        }, 500);
    }

    public refreshColumnIndexes(): void {
        this.vHelper.refreshColOffsets();
        let colIndexes: number[] = this.vHelper.getColumnIndexes();
        this.parent.setColumnIndexesInView(colIndexes);
        this.parent.dotNetRef.invokeMethodAsync("SetColumnIndexes", colIndexes[0], colIndexes[colIndexes.length - 1]);
    }

    public refreshVirtualElement(): void {
        this.vHelper.refreshColOffsets();
        this.setVirtualHeight();
    }

}
/**
 * @hidden
 */
export class VirtualHeaderRenderer {
    public virtualEle: VirtualElementHandler;
    private vHelper: VirtualHelper;
    private parent: SfGrid;
    private headerPanel: Element;

    constructor(parent: SfGrid) {
        this.parent = parent;
        this.vHelper = new VirtualHelper(this.parent);
        this.virtualEle = new VirtualElementHandler(this.parent);
        this.headerPanel = this.parent.element.querySelector(".e-gridheader");
    }

    /**
     * Get the header content div element of grid 
     * @return {Element} 
     */
    public getPanel(): Element {
        return this.headerPanel;
    }

    /**
     * Get the header table element of grid
     * @return {Element} 
     */
    public getTable(): Element {
        return this.headerPanel.querySelector('.e-table');
    }

    public renderTable(): void {
        this.vHelper.refreshColOffsets();
        this.parent.setColumnIndexesInView(this.vHelper.getColumnIndexes(<HTMLElement>this.getPanel().querySelector('.e-headercontent')));
        this.virtualEle.table = <HTMLElement>this.getTable();
        this.virtualEle.content = <HTMLElement>this.getPanel().querySelector('.e-headercontent');
        this.virtualEle.content.style.position = 'relative';
        this.virtualEle.renderWrapper();
        this.virtualEle.renderPlaceHolder();
    }

}
/**
 * @hidden
 */
    export class VirtualElementHandler {
        public wrapper: HTMLElement;
        public movableHeaderWrapper: HTMLElement;
        public movableContentWrapper: HTMLElement;
        public placeholder: HTMLElement;
        public content: HTMLElement;
        public table: HTMLElement;
        public parent: SfGrid;
        public filterTranslateX: number;

        constructor(parent: SfGrid) {
            this.parent = parent;
        }

        public renderWrapper(height?: number): void {
            this.wrapper = this.content.querySelector('.e-virtualtable');
            this.wrapper.setAttribute('styles', `min-height:${formatUnit(height)}`);
            if (this.content.querySelector('.e-gridcontent')) {
                this.movableHeaderWrapper = this.content.querySelector('.e-virtualtable');
            }
            if (this.content.querySelector('.e-gridcontent') != null) {
                this.movableContentWrapper = this.content.querySelector('.e-virtualtable');
            }
        }

        public renderPlaceHolder(): void {
            this.placeholder = this.content.lastElementChild as HTMLElement;
        }

        public adjustTable(xValue: number, yValue: number): void {
            this.filterTranslateX = xValue;
            if (this.parent.options.enableColumnVirtualization && !this.parent.options.enableVirtualization && yValue > 0) {
                yValue = 0;
            }
            let cells: HTMLElement[] = [].slice.call(this.content.querySelectorAll('.e-leftfreeze,.e-rightfreeze,.e-fixedfreeze'));
            let frzLeftWidth: number = 0;
            let frzRightWidth: number = 0;
            if (this.parent.getHeaderContent().querySelectorAll('.e-fixedfreeze').length) {
                frzLeftWidth = this.parent.leftrightColumnWidth('left');
                frzRightWidth = this.parent.leftrightColumnWidth('right');
            }
            if (cells.length) {
                for (var i = 0; i < cells.length; i++) {
                    let cell: HTMLElement = cells[parseInt(i.toString())];
                    let col: Column = null;
                    if (cell.classList.contains('e-rowcell')) {
                        if (!isNullOrUndefined(cell.getAttribute('data-colindex')) && cell.querySelector('[e-mappinguid]')) {
                            var uid = cell.querySelector('[e-mappinguid]').getAttribute('e-mappinguid');
                            col = this.parent.getColumnByUid(uid);
                        }
                        else {
                            let idx: number = parseInt(cell.getAttribute('data-colindex'));
                            col = this.parent.getColumnByIndex(parseInt(idx.toString()), true);
                        }
                    }
                    else {
                        if (cell.classList.contains('e-headercell') || cell.classList.contains('e-filterbarcell')) {
                            var uid = cell.classList.contains('e-filterbarcell') ? cell.getAttribute('e-mappinguid') :
                                cell.querySelector('[e-mappinguid]').getAttribute('e-mappinguid');
                            col = this.parent.getColumnByUid(uid);
                        }
                    }
                    if (col.freeze === 'Left') {
                        cell.style.left = (col.translateLeftRightValue - xValue) + 'px';
                    }
                    else if (col.freeze === 'Right') {
                        cell.style.right = (col.translateLeftRightValue + xValue) + 'px';
                    }else if (col.freeze === 'Fixed') {
                        cell.style.left = (frzLeftWidth  - xValue) + 'px';
                        cell.style.right = (frzRightWidth  + xValue) + 'px';
                    }
                }
            }
            yValue = this.parent.options.enableVirtualization ? yValue : 0;
            this.wrapper.style.transform = "translate(" + xValue + "px, " + yValue + "px)";
        }

        public extractTranslateY(transformStyle: string): string {
            const match = transformStyle.match(/translate\([^,]+,([^)]+)\)/)
            if (match && match[1]) {
              return match[1].trim();
            }
            return "0";
        }

        public setWrapperWidth(width: string, full?: boolean): void {            
            this.wrapper.style.width = width ? `${width}px` : full ? '100%' : '';
        }

        public setVirtualHeight(height?: number, width?: string): void {
            if (this.parent.options.enableVirtualization) {
                this.placeholder.style.height = `${height}px`;
            } 
            this.placeholder.style.width = width;
        }

    }

/**
 * Content module is used to render grid content
 */
export class VirtualHelper {
    public parent: SfGrid;
    public cOffsets: { [x: number]: number } = {};
    public mOffsets: { [x: number]: number } = {};
    public data: { [x: number]: Object[] } = {};
    public groups: { [x: number]: Object } = {};

    constructor(parent: SfGrid) {
        this.parent = parent;
    }

    public getBlockIndexes(page: number): number[] {
        return [page + (page - 1), page * 2];
    }

    public getPage(block: number): number {
        return block % 2 === 0 ? block / 2 : (block + 1) / 2;
    }

    // public isBlockAvailable(value: number): boolean {
    //     // return value in this.cache;
    // }

    public getData(): VirtualInfo {
        return {
            page: this.parent.options.currentPage,
            blockIndexes: this.getBlockIndexes(this.parent.options.currentPage),
            direction: 'down',
            columnIndexes: this.parent.getColumnIndexesInView()
        };
    }

    // private getStartIndex(blk: number, data: Object[], full: boolean = true): number {
    //     let page: number = this.getPage(blk); let even: boolean = blk % 2 === 0;
    //     let index: number = (page - 1) * this.model.pageSize;
    //     return full || !even ? index : index + ~~(this.model.pageSize / 2);
    // }

    public getColumnIndexes(content: HTMLElement =
        (<HTMLElement>this.parent.getHeaderContent())): number[] {
        if (!isNullOrUndefined(this.parent.getContent())) {
            content = this.parent.getContent();
        }
        let frozenLeftColumns: Column[] = this.parent.getColumns().filter((a: Column) => {
            return a.isFrozen && a.freeze === "Left";
        });
        let frozenRightColumns: Column[] = this.parent.getColumns().filter((a: Column) => {
            return a.isFrozen && a.freeze === "Right";
        });
        let FrozenLeftColWidth: number = 0;
        for(var i = 0; i < frozenLeftColumns.length; i++)
        {
            FrozenLeftColWidth += parseInt(frozenLeftColumns[i].width as string);
        }
        var FrozenRightColWidth = 0;
        for (var i = 0; i < frozenRightColumns.length; i++) {
            FrozenRightColWidth += parseInt(frozenRightColumns[i].width as string);
        }
        let indexes: number[] = []; 
        let sLeft: number = this.parent.options.enableColumnVirtualization && this.parent.options.enableRtl? -1 * content.scrollLeft | 0 : content.scrollLeft | 0;
        let keys: string[] = Object.keys(this.cOffsets);
        let cWidth: number = this.parent.options.needClientAction ? (this.parent.options.frozenColumns && this.parent.options.enableColumnVirtualization ? this.parent.getHeaderContent().offsetWidth : content.getBoundingClientRect().width) :
                        parseInt(this.parent.options.width);
        sLeft = Math.min(this.cOffsets[keys.length - 1] - cWidth, sLeft); let calWidth: number = Browser.isDevice ? 2 * cWidth : cWidth / 2;
        let left: number = sLeft + cWidth + (sLeft === 0 ? calWidth : 0);
        keys.some((offset: string, indx: number, input: string[]) => {
            let iOffset: number = Number(offset); let offsetVal: number = this.cOffsets[offset];
            let border: boolean = sLeft - calWidth <= offsetVal && left + calWidth >= offsetVal;
            if (border) {
                indexes.push(iOffset);
            }
            return left + calWidth < offsetVal;
        });
        if (!indexes.length && !this.parent.options.frozenColumns) {
            indexes = [];
            left = left + this.cOffsets[this.getColumnIndexes()[0]];
            keys.some((offset: string, indx: number, input: string[]) => {
                let iOffset: number = Number(offset); let offsetVal: number = this.cOffsets[offset];
                let border: boolean = sLeft - calWidth <= offsetVal && left + calWidth >= offsetVal;
                if (border) {
                    indexes.push(iOffset);
                }
                return left + calWidth < offsetVal;
            });
        }
        if (indexes.length == 1 && !this.parent.options.frozenColumns) {
            this.parent.virtualContentModule.startColIndex = indexes[0];
            this.parent.virtualContentModule.endColIndex = indexes[0] + 1;
            indexes.push(indexes[0] + 1);
        } else {
            this.parent.virtualContentModule.startColIndex = indexes[0];
            this.parent.virtualContentModule.endColIndex = indexes[indexes.length - 1];
        }
        return indexes;
    }

    // public checkAndResetCache(action: string): boolean {
    //     let clear: boolean = ['paging', 'refresh', 'sorting', 'filtering', 'searching', 'grouping', 'ungrouping', 'reorder',
    //                         'save', 'delete'].some((value: string) => action === value);
    //     if (clear) {
    //         this.cache = {}; this.data = {}; this.groups = {};
    //     }
    //     return clear;
    // }

    public refreshColOffsets(): void {
        let col: number = 0; this.cOffsets = {}; this.mOffsets = {}; let gLen: number = this.parent.options.groupCount;
        let cols: Column[] = (<Column[]>this.parent.options.columns);
        if(this.parent.options.enableColumnVirtualization){
            cols = cols.filter((e) => e.visible);
        }
        let cLen: number = cols.length;
        // let isVisible: Function = (column: Column) => column.visible &&
        //     (!this.parent.options.showGroupedColumn ? this.parent.options.groupedColumns.indexOf(column.field) < 0 : column.visible);
        // let c: string[] = this.parent.options.groupedColumns || [];
        // for (let i: number = 0; i < c.length; i++) {
        //     this.cOffsets[i] = (this.cOffsets[i - 1] | 0) + 30;
        // }
        let blocks: number[] = Array.apply(null, Array(cLen)).map(() => col++);
        for (let j: number = 0; j < blocks.length; j++) {
            this.cOffsets[blocks[j]] = (this.cOffsets[blocks[j] - 1] | 0) + (cols[j].visible ? parseInt(<string>cols[j].width, 10) : 0);
        }
        if (this.parent.options.frozenColumns) {
            var mCol = 0; 
            if (!this.parent.options.actualFrozenColumns) {
                var fCols = cols.filter(col => col.isFrozen && (col.freeze === "Left" || col.freeze === "Right"));
                var mCols = cols.filter(col => !fCols.some(fCol => fCol === col));
            }
            else {
                let fColsLen: number = 0;
                for(var i = 0; i < cols.length; i++) {
                    if(!cols[i].isFrozen && cols[i].index < this.parent.options.frozenColumns) {
                        fColsLen++;
                    }
                    else {
                        break;
                    }
                }
                mCols = cols.slice(fColsLen, cLen);
            }
            var mColLen = mCols.length;

            let blocks = Array.apply(null, Array(mColLen)).map(function () {
                return mCol++;
            });
            for (var j = 0; j < blocks.length; j++) {
                blocks[j] = blocks[j] + gLen;
                this.mOffsets[blocks[j]] = (this.mOffsets[blocks[j] - 1] | 0) + (mCols[j].visible ? parseInt(<string>mCols[j].width, 10) : 0);
            }
        }
    }

}


type ScrollArg = { direction: string, sentinel: SentinelType, offset: Offsets, focusElement: HTMLElement, isWheelScroll: boolean };


export type SentinelType = {
    check?: (rect: ClientRect, info: SentinelType) => boolean,
    top?: number, entered?: boolean,
    axis?: string;
};

export type SentinelInfo = { up?: SentinelType, down?: SentinelType, right?: SentinelType, left?: SentinelType };

export type Offsets = { top?: number, left?: number };
