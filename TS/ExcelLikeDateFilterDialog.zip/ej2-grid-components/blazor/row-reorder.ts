import { MouseEventArgs, Droppable, removeClass, Draggable, DropEventArgs, createElement, isNullOrUndefined } from '@syncfusion/ej2-base';
import { remove, closest as closestElement, classList, BlazorDragEventArgs } from '@syncfusion/ej2-base';
import { parentsUntil, isActionPrevent, getPosition, getScrollBarWidth, removeElement, addRemoveActiveClasses } from './util';
import { SfGrid } from './sf-grid-fn';
import { IPosition } from './interfaces';


/**
 * 
 * Reorder module is used to handle row reordering.
 * @hidden
 */
export class RowDD {
    //Internal variables    
    private startedRow: HTMLTableRowElement;
    private dragTarget: number;
    private timer: number;
    private isOverflowBorder: boolean = true;
    private rowData: Object;
    private dragStartData: Object;
    private draggable: Draggable;
    private droppable: Droppable;
    private borderIndex: number;
    private destinationGrid: SfGrid;
    private istargetGrid: boolean = false;
    private dataRowElements : HTMLElement[] = [];
    private showAddNewRowDisable: boolean = false;

    /* tslint:disable-next-line:max-line-length */
    // tslint:disable-next-line:max-func-body-length
    private helper: Function = (e: { sender: MouseEventArgs }) => {
        let gObj: SfGrid = this.parent;
        let target: Element = this.draggable.currentStateTarget as Element;
        this.draggable.queryPositionInfo = function(value: any){
            if(gObj.options.enableRtl && isNullOrUndefined(gObj.options.rowDropTarget))
            {
                value.left = (this.position.left) - ((this.parentClientRect.left + this.borderWidth.left)) - gObj.element.querySelector('.e-cloneproperties').clientWidth + (gObj.element.querySelector('.e-rowdragdrop').clientWidth/2) + "px";
            }
            return value;
        }
        let visualElement: HTMLElement = createElement('div', {
            className: 'e-cloneproperties e-draganddrop e-grid e-dragclone',
            styles: 'height:"auto", z-index:2, width:' + gObj.element.offsetWidth
        });
        let table: Element = createElement('table', { styles: 'width:' + gObj.element.offsetWidth });
        let tbody: Element = createElement('tbody');

        if (document.getElementsByClassName('e-griddragarea').length ||
            (gObj.options.rowDropTarget && (!(e.sender.target as Element).classList.contains('e-selectionbackground')
                && gObj.options.selectionType !== 'Single')) ||
            (!gObj.options.rowDropTarget && !parentsUntil(target as Element, 'e-rowdragdrop')) ||
            gObj.options.rowDropTarget && gObj.options.selectionType === 'Single' && (target as Element).parentElement.getAttribute('data-rowindex') === null) {
                if(isNullOrUndefined(parentsUntil(target as Element, 'e-rowdragdrop'))){
                    return false;
                }
        }
        if (gObj.options.rowDropTarget &&
            gObj.options.selectionMode === 'Row' && gObj.options.selectionType === 'Single' &&
            (this.draggable.currentStateTarget as Element).parentElement.getAttribute('data-rowindex') !== null) {
            gObj.dotNetRef.invokeMethodAsync("SelectRow", parseInt((this.draggable.currentStateTarget as Element).parentElement.getAttribute('data-rowindex'), 10), false, -1);
        }
        this.startedRow = closestElement(target as Element, 'tr').cloneNode(true) as HTMLTableRowElement;
        if (!isNullOrUndefined(this.startedRow.querySelector('.e-rowcell.e-focus'))) {
            removeClass([this.startedRow.querySelector('.e-rowcell.e-focus')], ['e-focus', 'e-focused']);
        }
        let selectedRows: Element[] = gObj.getSelectedRows();
        let targetRowIsDetailRow: HTMLElement = parentsUntil(target, 'e-detailrow') as HTMLElement;
        let rowsSelected: Element[] = selectedRows.filter(function(row) {
            let rowIsDetailRow: HTMLElement = parentsUntil(row, 'e-detailrow') as HTMLElement;
            return (
                isNullOrUndefined(rowIsDetailRow) ||
                (!isNullOrUndefined(targetRowIsDetailRow) && !isNullOrUndefined(rowIsDetailRow))
            );
        });
        removeElement(this.startedRow, '.e-indentcell');
        removeElement(this.startedRow, '.e-detailrowcollapse');
        removeElement(this.startedRow, '.e-detailrowexpand');
        this.removeCell(this.startedRow, 'e-gridchkbox');
        let exp: RegExp = new RegExp('e-active', 'g'); //high contrast issue
        this.startedRow.innerHTML = this.startedRow.innerHTML.replace(exp, '');
        tbody.appendChild(this.startedRow);

        if (!isNullOrUndefined(rowsSelected) && rowsSelected.length > 1 && gObj.getSelectedRows().length > 1 && this.startedRow.hasAttribute('aria-selected')) {
            let dropCountEle: HTMLElement = createElement('span', {
                className: 'e-dropitemscount', innerHTML: '' + rowsSelected.length,
            });
            visualElement.appendChild(dropCountEle);
        }
        let ele: Element = closestElement(target as Element, 'tr').querySelector('.e-icon-rowdragicon');
        if (ele && parentsUntil(target, 'e-rowdragdrop')) {
            ele.classList.add('e-dragstartrow');
        }
        table.appendChild(tbody);
        visualElement.appendChild(table);
        gObj.element.appendChild(visualElement);
        return visualElement;
    }

    private dragStart: Function = (e: { target: HTMLElement, event: MouseEventArgs } & BlazorDragEventArgs) => {
        let gObj: SfGrid = this.parent;
        document.body.classList.add('e-prevent-select');
        if (document.getElementsByClassName('e-griddragarea').length) {
            return;
        }
        const spanCssEle: HTMLSpanElement = this.parent.element.querySelector('.e-dropitemscount') as HTMLSpanElement;
        if (this.parent.getSelectedRows().length > 1 && spanCssEle) {
            spanCssEle.style.left = (this.parent.element.querySelector('.e-cloneproperties table') as HTMLTableRowElement)
                .offsetWidth - 5 + 'px';
        }
        let fromIdx: number = parseInt(this.startedRow.getAttribute('data-rowindex'), 10);
        let dragUid: string = !isNullOrUndefined(this.startedRow.getAttribute('data-uid')) ? this.startedRow.getAttribute('data-uid') : null;
        this.parent.dotNetRef.invokeMethodAsync("RowDragStartEvent", fromIdx, dragUid);
        e.bindEvents(e.dragElement);
        this.dragStartData = this.rowData;
        let dropElem: any = document.getElementById(gObj.options.rowDropTarget);
        if (gObj.options.rowDropTarget && dropElem && dropElem.blazor__instance &&
            (typeof (<{ getModuleName?: Function }>dropElem.blazor__instance).getModuleName === 'function') &&
            (<{ getModuleName?: Function }>dropElem.blazor__instance).getModuleName() === 'grid') {
                if(isNullOrUndefined(gObj.element.querySelector('.e-dragstartrow'))) {
                    dropElem.blazor__instance.getContent().classList.add('e-allowRowDrop');
                }
        }
    }

    private drag: Function = (e: { target: HTMLElement, event: MouseEventArgs }) => {
        let gObj: SfGrid = this.parent;
        this.istargetGrid = false;
        this.destinationGrid = this.parent;
        this.showAddNewRowDisable = false;
        let cloneElement: HTMLElement = this.parent.element.querySelector('.e-cloneproperties') as HTMLElement;
        let target: Element = this.getElementFromPosition(cloneElement, e.event);
        let cloneElementGrid: HTMLElement | null = (parentsUntil(cloneElement, 'e-grid') as HTMLElement).parentElement;
        let cloneElementDragRow : HTMLElement | null = !isNullOrUndefined(cloneElementGrid) ? cloneElementGrid.querySelector('.e-dragstartrow') as HTMLElement : null;
        let targetElementGrid: HTMLElement = parentsUntil(e.target, 'e-grid') as HTMLElement;
        if (this.parent.options.rowDropTarget) {
            var dropElement = document.getElementById(gObj.options.rowDropTarget);
            if (!isNullOrUndefined(cloneElementGrid) && !isNullOrUndefined(targetElementGrid) && cloneElementGrid.id !== targetElementGrid.id) {
                this.destinationGrid = (isNullOrUndefined((dropElement)) || isNullOrUndefined((<any>dropElement).blazor__instance)) ? this.parent : (<any>dropElement).blazor__instance;
            }
           
            if (parentsUntil(e.target, 'e-grid')) {
                this.istargetGrid = this.parent.options.rowDropTarget === parentsUntil(e.target, 'e-grid').id;
            }
        }
        if (!isNullOrUndefined(targetElementGrid) && (targetElementGrid as any).blazor__instance.options.showAddNewRow && !this.showAddNewRowDisable) {
            gObj.dotNetRef.invokeMethodAsync("DisableShowAddForm", "RowDragStart", false, this.destinationGrid.dotNetRef);
            this.showAddNewRowDisable = true;
        }
        
        classList(cloneElement, ['e-defaultcur'], ['e-notallowedcur', 'e-movecur']);
        this.isOverflowBorder = true;
        let trElement: HTMLTableRowElement = parentsUntil(target, 'e-grid') ? closestElement(e.target, 'tr') as HTMLTableRowElement : null;
        let cloneIsDetailRow = parentsUntil(cloneElementGrid, 'e-detailrow');
        let targetIsDetailRow = parentsUntil(targetElementGrid, 'e-detailrow');
        let targetRow = parentsUntil(target, 'e-row') as HTMLTableRowElement;
        if (!e.target) { return; }
        this.stopTimer();
        gObj.element.classList.add('e-rowdrag');
        this.dragTarget = trElement && parentsUntil(target, 'e-grid').id === cloneElement.parentElement.id ?
            gObj.options.groupCount > 0 || this.parent.options.showAddNewRow ? parseInt(trElement.getAttribute('data-rowindex'), 10) : trElement.rowIndex : parseInt(this.startedRow.getAttribute('data-rowindex'), 10);
        if(gObj.options.rowDropTarget && !isNullOrUndefined(targetElementGrid) && cloneElementGrid.id !== targetElementGrid.id && !isNullOrUndefined(cloneElementDragRow)){
            this.dragTarget = trElement && parentsUntil(target, 'e-grid').id !== cloneElement.parentElement.id ? trElement.rowIndex : parseInt(this.startedRow.getAttribute('data-rowindex'), 10);
        }
            if (gObj.options.rowDropTarget) {
            const dropElement = document.getElementById(gObj.options.rowDropTarget);
            const gridRow = parentsUntil(e.target, 'e-row');
            if (parentsUntil(target, 'e-gridcontent')) {
                if (parentsUntil(cloneElement.parentElement, 'e-grid').id === parentsUntil(target, 'e-grid').id && (isNullOrUndefined(cloneElementDragRow) || !isNullOrUndefined(targetRow) && targetRow.getAttribute('aria-selected') === 'true')
                    || (isNullOrUndefined(gridRow) && isNullOrUndefined(targetElementGrid.querySelector('.e-emptyrow')))
                    || (!isNullOrUndefined(dropElement) && dropElement.classList.contains('e-grid') && !isNullOrUndefined(targetElementGrid) && this.destinationGrid.element.id !== targetElementGrid.id)) {
                    classList(cloneElement, ['e-notallowedcur'], ['e-defaultcur']);
                }
                else if (parentsUntil(trElement, 'e-showAddNewRow')) {
                    classList(cloneElement, ['e-notallowedcur'], ['e-defaultcur']);
                } 
                else {
                    classList(cloneElement, ['e-defaultcur'], ['e-notallowedcur']);
                }
            } else if (parentsUntil(target, 'e-droppable:not(.e-headercontent)')) {
                classList(cloneElement, ['e-defaultcur'], ['e-notallowedcur']);
            }
            else if (!isNullOrUndefined(dropElement) && !isNullOrUndefined(target) && parentsUntil(target, 'e-grid') || !dropElement.contains(target)) {
                classList(cloneElement, ['e-notallowedcur'], ['e-defaultcur']);
            }
        } else {
            let elem: Element = parentsUntil(target, 'e-grid');
            if (elem && elem.id === cloneElement.parentElement.id && !isNullOrUndefined(targetRow) && targetRow.getAttribute('aria-selected') === 'false') {
                classList(cloneElement, ['e-movecur'], ['e-defaultcur']);
            } else {
                classList(cloneElement, ['e-notallowedcur'], ['e-movecur']);
            }
        }
        
        if (gObj.options.allowRowDragAndDrop ||
            (!gObj.options.rowDropTarget && e.target.classList.contains('e-selectionbackground'))) {
            if (parentsUntil(target, 'e-grid')) {
                let treeGridElement: HTMLElement = !isNullOrUndefined(cloneElementGrid) ? parentsUntil(cloneElementGrid, 'e-treegrid') as HTMLElement : null;
                if ((!isNullOrUndefined(cloneElementDragRow) && (!isNullOrUndefined(targetElementGrid) && cloneElementGrid === targetElementGrid || treeGridElement))) {
                    if(!isNullOrUndefined(trElement) && !parentsUntil(trElement, 'e-content')){
                        this.removeTargetGridBorder((<any>cloneElementGrid).blazor__instance);
                        this.removeTargetGridBorder((<any>targetElementGrid).blazor__instance);
                    }
                    this.updateScrollPostion(e.event, target);
                }
            }
            if(!isNullOrUndefined(document.querySelector('.e-lastrow-dragborder'))){
                document.querySelector('.e-lastrow-dragborder').remove();
            }
            if (parentsUntil(trElement, 'e-columnheader')) {
                let detailRow = parentsUntil(trElement, 'e-detailrow');
                if (!isNullOrUndefined(detailRow) && detailRow.getElementsByClassName('e-emptyrow')) {
                    return;
                }
            }
            let isNotEmptyGrid: boolean = !isNullOrUndefined(trElement) && !trElement.classList.contains('e-emptyrow');
            let isFrozenRowsAndColumn: boolean = this.parent.options.frozenRows && this.parent.options.frozenColumns && !isNullOrUndefined(trElement) && parseInt(this.startedRow.getAttribute('data-rowindex'), 10) !== parseInt(trElement.getAttribute('data-rowindex'), 10);
            if (this.isOverflowBorder && ((parseInt(this.startedRow.getAttribute('data-rowindex'), 10) !== this.dragTarget) || isFrozenRowsAndColumn) && isNotEmptyGrid) {
                this.moveDragRows(e, this.startedRow, trElement);
            } else {
                let rows : Element[] = this.parent.getRows();
                let isLastRow: boolean = !isNullOrUndefined(trElement) && this.startedRow.getAttribute('data-uid') !== rows[(rows.length - 1)].getAttribute('data-uid');
                if (trElement && !isNullOrUndefined(this.parent.getRowByIndex(rows.length - 1)) && 
                    this.parent.getRowByIndex(rows.length - 1).getAttribute('data-uid') ===
                    trElement.getAttribute('data-uid') && isLastRow && !(gObj.options.groupCount)) {
                    let bottomborder: HTMLElement = createElement('div', { className: 'e-lastrow-dragborder' });
                    let gridcontentEle: Element = this.parent.getContent();
                    if(!isNullOrUndefined(gridcontentEle)){
                        const isHorizontalScrollAlone: boolean = gridcontentEle.scrollWidth > gridcontentEle.clientWidth && gridcontentEle.scrollHeight <= gridcontentEle.clientHeight;
                        bottomborder.style.width = isHorizontalScrollAlone ? (this.parent.getContent() as HTMLElement).offsetWidth + 'px' : (this.parent.getContent() as HTMLElement).offsetWidth - this.getScrollWidth() + 'px';
                        this.borderIndex = Number(parentsUntil(trElement, 'e-row').getAttribute('data-rowindex'));
                        if (!gridcontentEle.parentElement.querySelectorAll('.e-lastrow-dragborder').length) {
                            gridcontentEle.classList.add('e-grid-relative');
                            gridcontentEle.parentElement.appendChild(bottomborder);
                            bottomborder.style.bottom = this.parent.options.allowPaging ? ((this.parent.element.querySelector('.e-pager') as HTMLElement).offsetHeight + this.getScrollWidth()) + 'px' : this.getScrollWidth() + 'px';
                        }
                    }
                }
                else if(!isNullOrUndefined(targetElementGrid) && targetElementGrid.querySelector('.e-emptyrow') && cloneElementGrid.id !== targetElementGrid.id && targetElementGrid.querySelector('.e-content').getElementsByClassName("e-emptyrow").length > 0){
                    if ((<any>targetElementGrid).blazor__instance.getRows().length == 0 || !isNullOrUndefined(trElement) && parentsUntil(trElement, 'e-detailrow') && trElement.getElementsByClassName('e-emptyrow').length > 0) 
                    {
                        if(!isNullOrUndefined(cloneIsDetailRow) || (isNullOrUndefined(cloneIsDetailRow) && isNullOrUndefined(targetIsDetailRow))){
                            let bottomborder: HTMLElement = createElement('div', { className: 'e-lastrow-dragborder' });
                            let gridcontentEle: Element = targetElementGrid.querySelector('.e-content');
                            if(!isNullOrUndefined(gridcontentEle)){
                                const isHorizontalScrollAlone: boolean = gridcontentEle.scrollWidth > gridcontentEle.clientWidth && gridcontentEle.scrollHeight <= gridcontentEle.clientHeight;
                                bottomborder.style.width = isHorizontalScrollAlone ? (this.destinationGrid.getContent() as HTMLElement).offsetWidth + 'px' : (this.destinationGrid.getContent() as HTMLElement).offsetWidth - this.getScrollWidth() + 'px';
                                let isDetailRow : boolean = !isNullOrUndefined(trElement) ? trElement.classList.contains('e-detailrow') : false;
                                gridcontentEle = isDetailRow ? trElement.getElementsByClassName('e-grid')[0].querySelector('.e-content') : gridcontentEle;
                                bottomborder.style.position = isDetailRow ? 'relative': bottomborder.style.position;
                                if (!gridcontentEle.parentElement.querySelectorAll('.e-lastrow-dragborder').length) {
                                    gridcontentEle.classList.add('e-grid-relative');
                                    gridcontentEle.parentElement.appendChild(bottomborder);
                                    bottomborder.style.bottom = this.destinationGrid.options.allowPaging ? ((this.destinationGrid.element.querySelector('.e-pager') as HTMLElement).offsetHeight + this.getScrollWidth()) + 'px' : this.getScrollWidth() + 'px';
                                }
                            }
                        } 
                    }    
                }
                this.removeBorder(trElement);
            }

            if (gObj.options.groupCount) {

                if (!isNullOrUndefined(trElement) && !(trElement.querySelector('td.e-groupcaption')) && (this.startedRow.getAttribute('caption-uid') !== trElement.getAttribute('caption-uid')) && gObj.options.groupCount) {
                    
                    this.addorRemoveDashedBorder(e, false, this.dataRowElements);
                    this.dataRowElements = this.parent.getDataRows().filter((row: Element) => {
                        return row.getAttribute('caption-uid') === trElement.getAttribute('caption-uid');
                    }) as HTMLElement[]; 
                    this.addorRemoveDashedBorder(e, true, this.dataRowElements);                 
                }
                else {
                    this.addorRemoveDashedBorder(e, false, this.dataRowElements);
                }
            }

            if (!this.isOverflowBorder) {
                this.addorRemoveDashedBorder(e, false, this.dataRowElements);
            }           
        }
        if (gObj.options.rowDropTarget && this.istargetGrid) {
            if(cloneElementGrid !== targetElementGrid){
                this.updateScrollPostion(e.event, target);
                this.moveDragRows(e, this.startedRow, trElement);
                if(!isNullOrUndefined(trElement)){
                    this.lastRowBorderBetweenGrids(trElement, e.event);
                }
            }
        }
    }

    private lastRowBorderBetweenGrids: Function = (trElement : HTMLElement, event: MouseEventArgs) => {
        let gObj: SfGrid = this.destinationGrid;
        let rowElements: Element[] = gObj.getRows();
        const isLastRow: boolean = rowElements.length > 0 && !isNullOrUndefined(trElement) && gObj.getContent().querySelector('tr:last-child') === trElement;
        //Get the mouse position relative to the target row
        const mouseY: number = event.clientY - trElement.getBoundingClientRect().top;
        //Calculate the midpoint of the target row
        const targetMidpoint: number = trElement.offsetHeight / 2;
        //Calculate the combined height of the rows
        const rowsHeight: number = Array.from(rowElements).reduce((totalHeight: number, row: Element) => {
            return totalHeight + (row as HTMLElement).offsetHeight;
        }, 0);
        //Check if there is empty space after the last row
        let checkEmptySpace = rowsHeight >= gObj.getContent().clientHeight;
        if (rowElements.length > 0 && mouseY > targetMidpoint && checkEmptySpace && trElement && !isNullOrUndefined(gObj.getRowByIndex(rowElements.length - 1)) && gObj.getRowByIndex(rowElements.length - 1).getAttribute('data-uid') === trElement.getAttribute('data-uid') && isLastRow && !gObj.options.groupCount) {
            var bottomborder = createElement('div', {className: 'e-lastrow-dragborder'});
            var gridcontentEle = gObj.getContent() as HTMLElement;
            if(!isNullOrUndefined(gridcontentEle)){
                const isHorizontalScrollAlone: boolean = gridcontentEle.scrollWidth > gridcontentEle.clientWidth && gridcontentEle.scrollHeight <= gridcontentEle.clientHeight;
                bottomborder.style.width = isHorizontalScrollAlone ? gridcontentEle.offsetWidth + 'px' : gridcontentEle.offsetWidth - this.getScrollWidth() + 'px';
                this.borderIndex = Number(parentsUntil(trElement, 'e-row').getAttribute('data-rowindex'));
                if (!gridcontentEle.parentElement.querySelectorAll('.e-lastrow-dragborder').length) {
                    gridcontentEle.classList.add('e-grid-relative');
                    gridcontentEle.parentElement.appendChild(bottomborder);
                    bottomborder.style.bottom = gObj.options.allowPaging ? (gObj.element.querySelector('.e-pager') as HTMLElement).offsetHeight + this.getScrollWidth() + 'px' : this.getScrollWidth() + 'px';
                }
            }
        }
    }

    private dragStop: Function = (e: { target: HTMLTableRowElement, event: MouseEventArgs, helper: Element }) => {
        document.body.classList.remove('e-prevent-select');
        this.processDragStop(e);
    }

    private emptyTargertInGrid: Function = (target : HTMLElement) => {
        let gObj: SfGrid = this.parent;
        let contentDragBorder = gObj.getContent().getElementsByClassName('e-dragborder');
        let headerDragBorder = gObj.getHeaderContent().getElementsByClassName('e-firstrow-dragborder');
        let lastRowDragBorder = gObj.getContent().parentElement.getElementsByClassName('e-lastrow-dragborder');
        let iconTarget: boolean = !target.classList.contains("e-rowdragdrop") && !target.classList.contains("e-icon-rowdragicon");
        let emptyTarget: boolean = this.destinationGrid.getRows().length > 0 && !isNullOrUndefined(gObj.element.querySelector('.e-dragstartrow')) && !isNullOrUndefined(contentDragBorder) && !isNullOrUndefined(headerDragBorder) && contentDragBorder.length === 0 && headerDragBorder.length === 0 && isNullOrUndefined(parentsUntil(target, 'e-rowcell')) && iconTarget;
        if (!this.parent.options.rowDropTarget && !emptyTarget && !this.isOverflowBorder && !isNullOrUndefined(headerDragBorder) && !isNullOrUndefined(lastRowDragBorder) && (headerDragBorder.length === 0 && lastRowDragBorder.length === 0)) {
            return true;
        }
        return emptyTarget;
    }

    private processDragStop: Function = (e: { target: HTMLTableRowElement, event: MouseEventArgs, helper: Element }) => {
        let gObj: SfGrid = this.parent;
        let targetEle: Element = this.getElementFromPosition(e.helper as HTMLElement, e.event);
        let target: Element = targetEle && !targetEle.classList.contains('e-dlg-overlay') ?
            targetEle : e.target;
        gObj.element.classList.remove('e-rowdrag');
        let dropElement: any = document.getElementById(gObj.options.rowDropTarget);
        let dragStartRow: Element = gObj.element.querySelector('.e-dragstartrow');
        let cloneElement: HTMLElement = gObj.element.querySelector('.e-cloneproperties') as HTMLElement;
        let cloneElementGrid: HTMLElement = (parentsUntil(cloneElement, 'e-grid') as HTMLElement).parentElement;
        let targetElementGrid: HTMLElement = parentsUntil(e.target, 'e-grid') as HTMLElement;
        let targetIsNotGrid: boolean = !isNullOrUndefined(dropElement) && !dropElement.classList.contains('e-grid') && !isNullOrUndefined(targetElementGrid) && cloneElementGrid.id !== targetElementGrid.id;
        let whiteSpaceInEmptyGrid: boolean = !isNullOrUndefined(targetElementGrid) && !isNullOrUndefined(targetElementGrid.querySelector('.e-emptyrow'));//When a row is dropped into an empty grid that displays 'no records to display,' and the target is a content element, then the variable becomes true.
        if (this.parent.options.allowRowDragAndDrop && this.parent.options.rowDropTarget && ((!parentsUntil(target, 'e-grid') && dropElement.contains(e.target)) || (targetIsNotGrid && (parentsUntil(e.target, 'e-row') || whiteSpaceInEmptyGrid)))) {
            let toIdx: number = 0;
            let targetClass: string = this.getElementXPath(target as HTMLTableRowElement);
            let targetID: string = target.id;
            let fromIdx: number = parseInt(this.startedRow.getAttribute('data-rowindex'), 10);
            let positions: ClientRect  = target.getBoundingClientRect();
            gObj.dotNetRef.invokeMethodAsync("ReorderRows", fromIdx, toIdx, 'add', false, targetClass, targetID, positions, null, true, false, null, null, false);
        }
        if (gObj.options.rowDropTarget && dropElement && dropElement.blazor__instance &&
            (typeof (<{ getModuleName?: Function }>dropElement.blazor__instance).getModuleName === 'function') &&
            (<{ getModuleName?: Function }>dropElement.blazor__instance).getModuleName() === 'grid') {
            dropElement.blazor__instance.getContent().classList.remove('e-allowRowDrop');
        }
        
        if (!parentsUntil(target, 'e-gridcontent') || target.classList.contains('e-lastrow-dragborder') || this.emptyTargertInGrid(target) || parentsUntil(e.target, 'e-columnheader')) {
            this.dragTarget = null;
            remove(e.helper);
            this.stopTimer();
            this.removeBorder(targetEle);
            if (this.parent.options.rowDropTarget && !isNullOrUndefined(targetElementGrid)) {
                this.removeTargetGridBorder((<any>targetElementGrid).blazor__instance);
            }
            if (gObj.options.groupCount) {
                this.addorRemoveDashedBorder(e, false, this.dataRowElements);
            }
            if (dragStartRow) {
                dragStartRow.classList.remove('e-dragstartrow');
            }
            if (gObj.options.showAddNewRow && this.showAddNewRowDisable) {
                gObj.dotNetRef.invokeMethodAsync("DisableShowAddForm", "RowDragStop", true, null);
                this.showAddNewRowDisable = false;
            }
            return;
        }
        if (this.parent.options.allowRowDragAndDrop) {
            this.stopTimer();
            this.parent.getContent().classList.remove('e-grid-relative');
            this.removeBorder(targetEle);
            if (gObj.options.groupCount) {
                this.addorRemoveDashedBorder(e, false, this.dataRowElements);
            }
            if(dragStartRow && this.parent.options.rowDropTarget && !isNullOrUndefined(targetElementGrid) && cloneElementGrid.id !== targetElementGrid.id){
                return;
            }
            if (dragStartRow && !isNullOrUndefined(targetElementGrid) && cloneElementGrid.id === targetElementGrid.id) {
                dragStartRow.classList.remove('e-dragstartrow');
            }
            if (isNullOrUndefined(dragStartRow)) {
                if (cloneElementGrid.querySelector('.e-selectionbackground')) {
                    return;
                }
            }
            let targetClass: string = this.getElementXPath(e.target);
            let targetID: string = target.id;
            let fromIdx: number = parseInt(this.startedRow.getAttribute('data-rowindex'), 10);
            let fromUid: string = !isNullOrUndefined(this.startedRow.getAttribute('data-uid')) ? this.startedRow.getAttribute('data-uid') : null;
            let toUid: string = !isNullOrUndefined(closestElement(e.target, 'tr') as HTMLTableRowElement) ? (closestElement(e.target, 'tr') as HTMLTableRowElement).getAttribute('data-uid') : null;
            let toIdx: number = this.parent.options.enableVirtualization ? fromIdx === this.dragTarget ? this.dragTarget :  fromIdx < this.borderIndex ? this.borderIndex : this.borderIndex + 1 : this.parent.options.frozenRows ? fromIdx < this.borderIndex ? this.borderIndex : this.borderIndex + 1 : this.dragTarget;
            if (Number.isNaN(toIdx) || isNullOrUndefined(toIdx)) {
                if (gObj.options.showAddNewRow && this.showAddNewRowDisable) {
                    gObj.dotNetRef.invokeMethodAsync("DisableShowAddForm", "RowDragStop", true, null);
                    this.showAddNewRowDisable = false;
                }
                return;
            }
            setTimeout(() => {
                gObj.dotNetRef.invokeMethodAsync("ReorderRows", fromIdx, toIdx, 'delete', true, targetClass, targetID, null, null, false, false, fromUid, toUid, false);
            }, 10);
            this.dragTarget = null;
        }
        if (gObj.options.showAddNewRow && this.showAddNewRowDisable) {
            gObj.dotNetRef.invokeMethodAsync("DisableShowAddForm", "RowDragStop", false, null);
            this.showAddNewRowDisable = false;
        }
    }

    private removeCell: Function = (targetRow: HTMLTableRowElement, className: string) => {
        return [].slice.call(targetRow.querySelectorAll('td')).filter((cell: HTMLTableCellElement) => {
            if (cell.classList.contains(className)) { (targetRow as HTMLTableRowElement).deleteCell(cell.cellIndex); }
        });
    }

    //Module declarations
    private parent: SfGrid;

    /**
     * Constructor for the Grid print module
     * @hidden
     */
    constructor(parent?: SfGrid) {
        this.parent = parent;
        if (this.parent.options.allowRowDragAndDrop) {
            this.initializeDrag();
        }
    }

    private stopTimer(): void {
        window.clearInterval(this.timer);
    }

    public initializeDrag(): void {
        let gObj: SfGrid = this.parent;
        this.draggable = new Draggable(gObj.getContent() as HTMLElement, {
            dragTarget: '.e-rowcelldrag, .e-rowdragdrop, .e-rowcell',
            distance: 5,
            helper: this.helper,
            dragStart: this.dragStart,
            drag: this.drag,
            dragStop: this.dragStop,
            isPreventSelect: false
        });
        this.droppable = new Droppable(gObj.getContent() as HTMLElement, {
            accept: '.e-dragclone',
            drop: this.drop as (e: DropEventArgs) => void
        });
    }

    private updateScrollPostion(e: MouseEvent | TouchEvent, target: Element): void {
  
        let y: number = getPosition(e).y;
        let cliRect: ClientRect = this.destinationGrid.getContent().getBoundingClientRect();
        let rowHeight: number = this.destinationGrid.getRowHeight() - 15;
        let scrollElem: Element = this.destinationGrid.getContent();
        if (cliRect.top + rowHeight >= y) {
            let scrollPixel: number = -(this.destinationGrid.getRowHeight());
            this.isOverflowBorder = false;
            this.timer = window.setInterval(
                () => { this.setScrollDown(scrollElem, scrollPixel, true); }, 200);
        } else if (cliRect.top + this.destinationGrid.getContent().clientHeight - rowHeight - 20 <= y) {
            let scrollPixel: number = (this.destinationGrid.getRowHeight());
            this.isOverflowBorder = false;
            this.timer = window.setInterval(
                () => { this.setScrollDown(scrollElem, scrollPixel, true); }, 200);
        }
    }

    private setScrollDown(scrollElem: Element, scrollPixel: number, isLeft: boolean): void {
        scrollElem.scrollTop = scrollElem.scrollTop + scrollPixel;
    }

    private moveDragRows(e: { target: HTMLElement, event: MouseEventArgs }, startedRow: HTMLTableRowElement, targetRow: HTMLTableRowElement)
        : void {
        let cloneElement: HTMLElement = this.parent.element.querySelector('.e-cloneproperties') as HTMLElement;
        let element: HTMLTableRowElement = closestElement(e.target, 'tr') as HTMLTableRowElement;
        if (parentsUntil(element, 'e-gridcontent') && ((!isNullOrUndefined(cloneElement) && (parentsUntil(cloneElement.parentElement, 'e-grid').id ===
        parentsUntil(element, 'e-grid').id)) || this.istargetGrid)) {
        let targetElement: HTMLTableRowElement = element ?
            element : this.startedRow;
        this.setBorder(targetElement, e.event, startedRow, targetRow);
        }
    }

    private setBorder(element: Element, event: MouseEventArgs, startedRow: HTMLTableRowElement, targetRow: HTMLTableRowElement): void {
        let node: Element = this.parent.element as Element;
        if (this.istargetGrid) {
            node = this.destinationGrid.element as Element;
        }
        let cloneElement: HTMLElement = this.parent.element.querySelector('.e-cloneproperties') as HTMLElement;
        if (this.parent.element.id !== this.destinationGrid.element.id && (this.parent.element.getElementsByClassName('e-firstrow-dragborder').length > 0 || this.parent.element.getElementsByClassName('e-lastrow-dragborder').length > 0)) {
            this.removeTargetGridBorder(this.parent);
        }
        if(this.parent.options.groupCount) {
            this.removeBorder(element);
        }
        else {
            this.removeFirstRowBorder(element);
            this.removeLastRowBorder(element);
        }
        var dragIconIsActive = this.parent.element.querySelector('.e-dragstartrow');
        // Get the mouse position relative to the target row
        let mouseY = event.clientY - targetRow.getBoundingClientRect().top;
        // Calculate the midpoint of the target row
        let targetMidpoint = targetRow.offsetHeight / 2;
        if(isNullOrUndefined(dragIconIsActive) && mouseY > targetMidpoint){
            return;
        }
        if(!isNullOrUndefined(targetRow)){
            let targetRowGrid: HTMLElement = parentsUntil(targetRow, 'e-grid') as HTMLElement;
            if(!isNullOrUndefined(targetRowGrid) && targetRowGrid.id === parentsUntil(startedRow, 'e-grid').parentElement.id && (isNullOrUndefined(targetRowGrid.querySelector('.e-dragstartrow'))
            || targetRow.getAttribute('aria-selected') === 'true')){
                this.removeBorder(element);
                return;
            }
        }
        if (parentsUntil(element, 'e-gridcontent') && ((parentsUntil(cloneElement.parentElement, 'e-grid').id ===
            parentsUntil(element, 'e-grid').id) || this.istargetGrid)) {
            removeClass(node.querySelectorAll('.e-rowcell,.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'), ['e-dragborder']);
            let rowElement: HTMLElement[] = [];
            let targetRowIndex : number = parseInt(targetRow.getAttribute('data-rowindex'), 10);
            let lastRow: HTMLElement = this.destinationGrid.getContentTable().querySelector('tr:last-child');
            let addNewRowElement: HTMLTableRowElement = this.destinationGrid.element.querySelector('.e-showAddNewRow') as HTMLTableRowElement;
            if (targetRow && targetRowIndex === 0 && isNullOrUndefined(addNewRowElement) && (this.parent.element.id !== this.destinationGrid.element.id && mouseY < targetMidpoint || this.parent.element.id === this.destinationGrid.element.id)) {
                if(!targetRow.classList.contains('e-emptyrow') && targetRow.classList.contains('e-row')){
                    if (this.parent.options.groupCount && !targetRow.classList.contains('e-groupcaption')) {
                        element = targetRow;
                        rowElement = [].slice.call(element.querySelectorAll('.e-groupcaption,.e-summarycell,.e-rowcell,.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
                    }
                    else {
                        let div: HTMLElement = createElement('div', { className: 'e-firstrow-dragborder' });
                        let gridheaderEle: Element = this.destinationGrid.getHeaderContent();
                        gridheaderEle.classList.add('e-grid-relative');
                        if(!isNullOrUndefined(this.destinationGrid.getContent())){
                            let isHorizontalScrollAlone: boolean = this.destinationGrid.getContent().scrollWidth > this.destinationGrid.getContent().clientWidth && this.destinationGrid.getContent().scrollHeight <= this.destinationGrid.getContent().clientHeight;
                            div.style.width = isHorizontalScrollAlone ? (node as HTMLElement).offsetWidth + 'px' : (node as HTMLElement).offsetWidth - this.getScrollWidth() + 'px';
                        }
                        if (!gridheaderEle.querySelectorAll('.e-firstrow-dragborder').length) {
                            gridheaderEle.appendChild(div);
                        }
                    }  
                }           
                this.borderIndex = -1;
                if (this.destinationGrid.element.getElementsByClassName('e-lastrow-dragborder').length > 0) {
                    this.destinationGrid.element.getElementsByClassName('e-lastrow-dragborder')[0].remove();
                }
                else if(document.getElementsByClassName('e-lastrow-dragborder').length > 0){
                    let lastRowBorder: HTMLElement = document.getElementsByClassName('e-lastrow-dragborder')[0] as HTMLElement;
                    if(!isNullOrUndefined(parentsUntil(lastRowBorder, 'e-grid'))){
                        lastRowBorder.remove();
                    }  
                }
            } else if (targetRow && (parseInt(startedRow.getAttribute('data-rowindex'), 10) > targetRowIndex) || (this.parent.options.rowDropTarget && this.parent.element.id !== this.destinationGrid.element.id)) {
                if (this.parent.options.groupCount && this.parent.options.enableVirtualization) {
                    targetRowIndex = this.parent.getDataRows().indexOf(targetRow);
                }

                if (this.parent.options.groupCount && !targetRow.classList.contains('e-groupcaption')) {
                    element = targetRow;
                    if (!isNullOrUndefined(element) && !element.classList.contains('e-detailrow')) {
                        rowElement = [].slice.call(element.querySelectorAll('.e-rowcell,.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
                    }
                }

                else {
                    if(!isNullOrUndefined(this.parent.element.querySelector('.e-dragstartrow')) && targetRow === lastRow && mouseY > targetMidpoint){
                        element = this.destinationGrid.getRowByIndex(targetRowIndex);
                    }
                    else{
                        element = this.destinationGrid.options.frozenRows ? this.destinationGrid.getRowByIndex(targetRowIndex) : this.destinationGrid.getRowByIndex(targetRow.rowIndex - 1);
                    }
                    if (!isNullOrUndefined(element) && !element.classList.contains('e-detailrow')) {
                        rowElement = [].slice.call(element.querySelectorAll('.e-rowcell,.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
                    }
                }
                
            } else {
                if (!isNullOrUndefined(element) && !element.classList.contains('e-detailrow') && !cloneElement.classList.contains('e-notallowedcur')) {
                    rowElement = [].slice.call(element.querySelectorAll('.e-rowcell,.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
                }
            }
            if (rowElement.length > 0) {
                this.borderIndex = Number(parentsUntil(rowElement[0], 'e-row').getAttribute('data-rowindex'));
                if (!(this.parent.options.groupCount)) {
                    addRemoveActiveClasses(rowElement, true, 'e-dragborder');
                    if (this.destinationGrid.element.getElementsByClassName('e-lastrow-dragborder').length > 0) {
                        this.destinationGrid.element.getElementsByClassName('e-lastrow-dragborder')[0].remove();
                    }
                    else if(document.getElementsByClassName('e-lastrow-dragborder').length > 0){
                        let lastRowBorder: HTMLElement = document.getElementsByClassName('e-lastrow-dragborder')[0] as HTMLElement;
                        if(!isNullOrUndefined(parentsUntil(lastRowBorder, 'e-grid'))){
                            lastRowBorder.remove();
                        }  
                    }
                    if (this.destinationGrid.element.getElementsByClassName('e-firstrow-dragborder').length > 0) {
                        this.destinationGrid.element.getElementsByClassName('e-firstrow-dragborder')[0].remove();
                    } else if (document.getElementsByClassName('e-firstrow-dragborder').length > 0) {
                        var lastRowBorder = document.getElementsByClassName('e-firstrow-dragborder')[0];
                      if (!isNullOrUndefined(parentsUntil(lastRowBorder, 'e-grid'))) {
                          lastRowBorder.remove();
                      }
                    }
                }
                
            }
        }
    }

    private addorRemoveDashedBorder(e: { target: HTMLElement, event: MouseEventArgs }, add: boolean, dataRowElements: HTMLElement[]) : void {
        if(dataRowElements.length <= 0) {
            return;
        }

        let firstDataRow : HTMLElement = dataRowElements[0];
        let lastDataRow : HTMLElement = dataRowElements[dataRowElements.length - 1];
        let firstDataRowCells = [];
        let lastDataRowCells = [];
        firstDataRowCells = [].slice.call(firstDataRow.querySelectorAll('.e-rowcell:not(.e-hide),.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
        lastDataRowCells = [].slice.call(lastDataRow.querySelectorAll('.e-rowcell:not(.e-hide),.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
        addRemoveActiveClasses(firstDataRowCells, add, 'e-dragtop');
        addRemoveActiveClasses(lastDataRowCells, add, 'e-dragbottom');
        this.updateDragClasses(add, dataRowElements);        
        
    }

    private updateDragClasses (add: boolean, dataRowElements: HTMLElement[]): void {
        for (let i : number = 0; i < dataRowElements.length; i++) {
            let rowElementCells : HTMLElement[] = [];
            rowElementCells = [].slice.call(dataRowElements[i].querySelectorAll('.e-rowcell:not(.e-hide),.e-rowdragdrop,.e-detailrowcollapse, .e-detailrowexpand'));
            if (rowElementCells.length) {
                if (add) {
                    rowElementCells[0].classList.add('e-dragleft');
                    rowElementCells[rowElementCells.length - 1].classList.add('e-dragright');
                }
                else {
                    rowElementCells[0].classList.remove('e-dragleft');
                    rowElementCells[rowElementCells.length - 1].classList.remove('e-dragright');
                }
            }
        }
    }

    private getScrollWidth(): number {
        let scrollElem: HTMLElement = !isNullOrUndefined(this.destinationGrid) && this.destinationGrid.element.id !== this.parent.element.id ? this.destinationGrid.getContent() :  this.parent.getContent() as HTMLElement;
        return scrollElem.scrollWidth > scrollElem.offsetWidth ? getScrollBarWidth() : 0;
    }

    private removeFirstRowBorder(element: Element): void {
        if (this.destinationGrid.element.getElementsByClassName('e-firstrow-dragborder').length > 0 && element &&
            (element as HTMLTableRowElement).rowIndex !== 0) {
            this.destinationGrid.element.getElementsByClassName('e-firstrow-dragborder')[0].remove();
        }
    }

    private removeLastRowBorder(element: Element): void {
        let islastRowIndex: boolean = element && !isNullOrUndefined(this.destinationGrid.getRowByIndex(this.destinationGrid.getRows().length - 1)) &&
            this.destinationGrid.getRowByIndex(this.destinationGrid.getRows().length - 1).getAttribute('data-uid') !==
            element.getAttribute('data-uid');
        if (this.destinationGrid.element.getElementsByClassName('e-lastrow-dragborder').length > 0 && element && islastRowIndex) {
            this.destinationGrid.element.getElementsByClassName('e-lastrow-dragborder')[0].remove();
        }
    }

    private removeBorder(element: Element): void {
        this.removeFirstRowBorder(element);
        this.removeLastRowBorder(element);
        element = this.destinationGrid.getRows().filter((row: Element) =>
            row.querySelector('td.e-dragborder'))[0];
        if (element) {
            let rowElement: HTMLElement[] = [].slice.call(element.querySelectorAll('.e-dragborder'));
            addRemoveActiveClasses(rowElement, false, 'e-dragborder');
        }
    }

    private getElementFromPosition(element: HTMLElement, event: MouseEventArgs): Element {
        let target: Element;
        let position: IPosition = getPosition(event);
        element.style.display = 'none';
        target = document.elementFromPoint(position.x, position.y);
        element.style.display = '';
        return target;
    }

    private getElementXPath(element: HTMLTableRowElement): string {
        if (!element) return null

        if (element.id) {
            return `//[@id=${element.id}]` + (element.className != '' ? ('.' + element.className.toLowerCase()) : '')
        } else if (element.tagName === 'BODY') {
            return '/html/body'
        } else {
            let sameTagSiblings: HTMLElement[] = [].slice.call(element.parentElement.childNodes)
                .filter((e: HTMLTableRowElement) => e.nodeName === element.nodeName);
            let idx: number = sameTagSiblings.indexOf(element);

            return this.getElementXPath(element.parentNode as HTMLTableRowElement) +
                '/' +
                element.tagName.toLowerCase() + (element.className != '' ? ('.' + element.className.toLowerCase()) : '') +
                (sameTagSiblings.length > 1 ? `[${idx + 1}]` : '')
        }
    }

    private getTargetIdx(targetRow: Element): number {
        return targetRow ? parseInt(targetRow.getAttribute('data-rowindex'), 10) : 0;
    }

    private drop: Function = (e: DropEventArgs) => {
        this.columnDrop({ target: e.target as HTMLTableRowElement, droppedElement: e.droppedElement, mouseEvent: e.event as MouseEvent });
        remove(e.droppedElement);
    }

    public columnDrop(e: { target: HTMLTableRowElement, droppedElement: HTMLElement, mouseEvent: MouseEvent }): void {
        let gObj: SfGrid = this.parent;
        if (e.droppedElement.getAttribute('action') !== 'grouping') {
            let targetRow: HTMLTableRowElement = closestElement(e.target, 'tr') as HTMLTableRowElement;
            let srcControl: SfGrid;
            let currentIndex: number;
            if ((e.droppedElement.querySelector('tr').getAttribute('single-dragrow') !== 'true' &&
                e.droppedElement.parentElement.id === gObj.element.id)
                || (e.droppedElement.querySelector('tr').getAttribute('single-dragrow') === 'true' &&
                    e.droppedElement.parentElement.id !== gObj.element.id)) {
                        this.removeTargetGridBorder(this.parent);
                        this.removeTargetGridBorder(this.destinationGrid);
                return;
            }
            if (e.droppedElement.parentElement.id !== gObj.element.id) {
                srcControl = (<any>e.droppedElement.parentElement).blazor__instance;
            }
            const dragStartRow: HTMLElement = srcControl.content.querySelector('.e-dragstartrow') as HTMLElement;
            if (srcControl.element.id !== gObj.element.id && srcControl.options.rowDropTarget !== gObj.element.id) {
                if (!isNullOrUndefined(dragStartRow)) {
                    dragStartRow.classList.remove('e-dragstartrow');
                    if(gObj.element.getElementsByClassName('e-lastrow-dragborder').length > 0){
                        this.removeTargetGridBorder(gObj);
                    }
                }
                return;
            }
            let targetIndex: number = currentIndex = this.getTargetIdx(targetRow);
            if(!isNullOrUndefined(targetRow)){
                // Get the mouse position relative to the target row
                let mouseY: number =  e.mouseEvent.clientY - targetRow.getBoundingClientRect().top;
                // Calculate the midpoint of the target row
                let targetMidpoint : number = targetRow.offsetHeight / 2;
                var lastRow : HTMLElement = gObj.getContentTable().querySelector('tr:last-child');
                if (e.target && !lastRow.classList.contains('e-emptyrow')) {
                    if (lastRow && targetRow == lastRow && mouseY > targetMidpoint) {
                        targetIndex = currentIndex = parseInt(lastRow.getAttribute('aria-rowindex'), 10);
                    }
                }
            }
            if (isNaN(targetIndex)) {
                targetIndex = currentIndex = 0;
            }
            if (gObj.options.allowPaging) {
                targetIndex = targetIndex + (gObj.options.currentPage * gObj.options.pageSize) - gObj.options.pageSize;
            }
            let targetClass: string = this.getElementXPath(e.target);
            let targetID: string = e.target.id;
            let positions: ClientRect = e.target.getBoundingClientRect();
            this.removeTargetGridBorder(this.parent);
            let fromIndex: number = 0;
            let withInBothGrid: boolean = false;
            if (gObj.options.tValue == srcControl.options.tValue) {
                
                if(!isNullOrUndefined(dragStartRow)){
                    const clonedRowElement: HTMLElement = parentsUntil(dragStartRow, 'e-row') as HTMLElement;
                    const isClonedRowNotSelected: boolean = clonedRowElement.getAttribute('aria-selected') === 'false';
                    fromIndex = isClonedRowNotSelected ? parseInt(clonedRowElement.getAttribute('data-rowindex'), 10) : 0;
                    withInBothGrid = isClonedRowNotSelected;
                    dragStartRow.classList.remove('e-dragstartrow');
                }
                gObj.dotNetRef.invokeMethodAsync("ReorderRows", fromIndex, targetIndex, 'add', false, targetClass, targetID, positions, srcControl.dotNetRef, false, false, null, null, withInBothGrid);
                srcControl.dotNetRef.invokeMethodAsync("ReorderRows", fromIndex, targetIndex, 'delete', false, targetClass, targetID, positions, null, false, false, null, null, withInBothGrid);
            } else {
                if (!isNullOrUndefined(dragStartRow)) {
                    dragStartRow.classList.remove('e-dragstartrow');
                }
                srcControl.dotNetRef.invokeMethodAsync("ReorderRows", fromIndex, targetIndex, 'delete', false, targetClass, targetID, positions, null, false, true, null, null, withInBothGrid);
            }
        }
    }

    private removeTargetGridBorder(grid: SfGrid): void {
        if (!isNullOrUndefined(grid)){
            if (grid.element.getElementsByClassName('e-firstrow-dragborder').length > 0) {
                grid.element.getElementsByClassName('e-firstrow-dragborder')[0].remove();
            }
            if (grid.element.getElementsByClassName('e-lastrow-dragborder').length > 0) {
                grid.element.getElementsByClassName('e-lastrow-dragborder')[0].remove();
            }
            else if(document.getElementsByClassName('e-lastrow-dragborder').length > 0){
                let lastRowBorder: HTMLElement = document.getElementsByClassName('e-lastrow-dragborder')[0] as HTMLElement;
                if(!isNullOrUndefined(parentsUntil(lastRowBorder, 'e-grid'))){
                    lastRowBorder.remove();
                }
            }
            removeClass(grid.element.querySelectorAll('.e-rowcell.e-dragborder,.e-detailrowcollapse.e-dragborder, .e-rowdragdrop.e-dragborder, e-detailrowexpand.e-dragborder'), ['e-dragborder']);
        }
    }

    /**
     * To destroy the print 
     * @return {void}
     * @hidden
     */
    public destroy(): void {
        let gridElement: Element = this.parent.element;
        if (!gridElement || (!gridElement.querySelector('.e-gridheader') &&
            !gridElement.querySelector('.e-gridcontent'))) { return; }
        if (!isNullOrUndefined(this.draggable)) {
            this.draggable.destroy();
        }
        if (!isNullOrUndefined(this.droppable)) {
            this.droppable.destroy();
        }
    }

}
