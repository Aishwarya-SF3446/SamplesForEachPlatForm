import { BlazorDotnetObject, EventHandler, isNullOrUndefined, enableBlazorMode, closest } from '@syncfusion/ej2-base';
import { SfGrid } from './sf-grid-fn';
import { getScrollBarWidth } from './util';
import { BlazorGridElement, IGridOptions, Column, FreezeLineMovingClientOptions } from './interfaces';
import { ColumnWidthService } from './width-controller';
import { parentsUntil } from './util';
/**
 * Blazor grid interop handler
 */
// tslint:disable
let Grid: object = {
    initialize(dataId: string, element: BlazorGridElement, options: IGridOptions, dotnetRef: BlazorDotnetObject): void {
        enableBlazorMode();
        new SfGrid(dataId, element, options, dotnetRef);
    },
    contentReady(dataId: string, options: IGridOptions, action: string, isResetData?: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.setOptions(options, instance.options);
            instance.options = options;
            instance.scrollModule.setPadding();
            instance.contentReady(action, isResetData);
            if (instance.options.isColumnWidthChanged) {
                var widthService = new ColumnWidthService(instance);
                widthService.setWidthToTable();
            }
            if (options.height == "100%") {
                instance.scrollModule.refresh();
            }
        }
    },
    refreshPivotRowHeight(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
	    instance.freezeModule.refreshFreeze({ case: 'textwrap' });
        }
        
    },
    customFilterDialog(dataId: string, dlgID: string, isExcel: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            let dialogElement: HTMLElement = (document.querySelector("#" + dlgID) as HTMLElement);
            dialogElement.style.maxHeight = "100%";
            dialogElement.style.border = "1px";
	    dialogElement.style.top = "0px";	
            if (isExcel) {
                let contextMenuElement: HTMLElement = gridInstance.element.querySelector(".e-sfcontextmenu");
                (contextMenuElement.querySelector(".e-caret") as HTMLElement).style.paddingRight = "8px";
            }
        }
    },
    setCustomFilterDialogPadding(element: BlazorGridElement, field: string) {
        let setPadding: HTMLElement = document.querySelector("#" + field);
        (setPadding as HTMLElement).style.padding = "16px";
    },
    searchClear(dataId: string, inputId: string, inputValue: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            let inputElement: HTMLInputElement = document.querySelector("#" + inputId);
            //Note: The variable 'inputValue' is used to update checkbox input element values when the input value is changed using events.
            inputElement.value = !isNullOrUndefined(inputValue) ? inputValue : "";
            inputElement.focus();
        }
    },
    updateTableWidth(dataId: string, columns: Column[]) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.options.columns = columns;
            if (instance.options.allowResizing && instance.options.isResizedGrid) {
                var widthService = new ColumnWidthService(instance);
                let tablewidth: boolean = columns.some(x => (x.width == "" || x.width == null));
                widthService.setWidthToTable(columns, tablewidth);
            }
        }
    },
    preventResizeAction(dataId: string, isCancel: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.resizeModule.preventResizeAction(isCancel);
        }
    },
    preventFreezeLineMoving(dataId: string, isCancel: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if(!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.frozenDragDropModule.preventFreezeLineMoving(isCancel);
        }
    },
    freezeLineMovedActions(dataId: string, freezeLineMovingClientOptions :FreezeLineMovingClientOptions) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.options.actualFrozenColumns = freezeLineMovingClientOptions.actualFrozenColumns;
            instance.options.columns = freezeLineMovingClientOptions.columns;
            instance.options.frozenRightCount = freezeLineMovingClientOptions.frozenRightCount;
            instance.options.frozenLeftCount = freezeLineMovingClientOptions.frozenLeftCount;
            instance.options.frozenLeftColumnsCount = freezeLineMovingClientOptions.frozenLeftColumnsCount;
            instance.options.frozenColumns = freezeLineMovingClientOptions.frozenColumns;
            instance.options.isColumnReordered = freezeLineMovingClientOptions.isColumnReordered;
            instance.freezeLineMovedAction();
            instance.freezeModule.setFrozenHeight();            
        }
    },
    frozenHeight(dataId: string, options: IGridOptions, action: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.freezeModule.setFrozenHeight();
            if(options.allowTextWrap){
                instance.freezeModule.refreshRowHeight();
                instance.freezeModule.refreshFreeze({
                    "case": 'textwrap'
                });
            }
            if(options.allowResizing){
                instance.freezeModule.updateResizeHandler();
            }
        }
    },
    updateVirtualColumns(dataId: string, virtualizedColumns: Column[]){
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.options.virtualizedColumns = virtualizedColumns;
            if (instance.options.allowResizing && instance.options.frozenColumns == 0 && instance.getContent().querySelector('table').style.width != '') {
                let widthService: ColumnWidthService = new ColumnWidthService(instance);
                widthService.setWidthToTable(null, false, 'resize');
            }
        }
    },
    updateOptions(dataId: string, options: IGridOptions) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.setOptions(options, instance.options);
        }
    },
    
    virtualHeight(dataId: string, options: IGridOptions, totalItemCount: number) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.options = options;
            instance.options.totalItemCount = totalItemCount;
            instance.virtualContentModule.refreshOffsets();
            instance.virtualContentModule.setVirtualHeight();            
        }
    },

    lazyGroupExpand(dataId: string, options: IGridOptions) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.setOptions(options, instance.options);
            instance.options = options;
            if (instance.options.enableVirtualization) {
                instance.virtualContentModule.onDataReady();
            }
            if(instance.options.enableInfiniteScrolling){
                instance.scrollModule.infiniteOnDataReady();
                instance.scrollModule.isLazyChidLoad = false;
            }
        }
    },

    viewRefresh(dataId: string, columns: Column[]) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            let widthService: ColumnWidthService;
            widthService = new ColumnWidthService(gridInstance);
            columns = columns.filter(x => x.visible);
            let tablewidth: boolean = columns.some(x => (x.width == "" || x.width == null));
            gridInstance.parent.getColumns();
            if(gridInstance.options.frozenColumns){
                gridInstance.parent.updateColumnLevelFrozen();
            }
            widthService.setWidthToTable(columns, tablewidth);
            
        }
    },

    virtualDisconnect(dataId: string, options: IGridOptions) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && !isNullOrUndefined(gridInstance.element.blazor__instance.virtualContentModule)) {
            gridInstance.element.blazor__instance.options.enableVirtualization = options.enableVirtualization;
            gridInstance.element.blazor__instance.virtualContentModule.observer.disconnect();
        }
    },

    reorderColumns(dataId: string, fromFName: string | string[], toFName: string) { //NEW
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.reorderModule.reorderColumns(fromFName, toFName);
        }
    },

    reorderColumnByIndex(dataId: string, fromIndex: number, toIndex: number) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.reorderModule.reorderColumnByIndex(fromIndex, toIndex);
        }
    },

    reorderColumnByTargetIndex(dataId: string, fieldName: string, toIndex: number) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.reorderModule.reorderColumnByTargetIndex(fieldName, toIndex);
        }
    },
    renderColumnChooser: function (dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.columnChooserModule.renderColumnChooser();
        }
    },

    renderColumnMenu: function (dataId: string, uid: string, isFilter: boolean, key: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            return gridInstance.element.blazor__instance.columnMenuModule.renderColumnMenu(uid, isFilter, key);
        }
        else {
            return { Left: 1, Top: 1 };
        }
    },

    renderAdaptiveMenuItems:function (dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        let columnMenuElement: Element = document.getElementsByClassName(`e-${gridInstance.element.id}-column-menu`)[0];
        let element: HTMLElement = !isNullOrUndefined(columnMenuElement) ? columnMenuElement.getElementsByTagName('ul')[0] : null;
        let e: any = document.getElementById(gridInstance.element.id + "_responsivetoolbaritems");
        let btnOffset: ClientRect = e.getBoundingClientRect();
        let left: number = btnOffset.left + pageXOffset;
        let top: number = btnOffset.bottom + pageYOffset;
        let popupOffset: ClientRect = element.getBoundingClientRect();
        let docElement: HTMLElement = document.documentElement;
        if (btnOffset.bottom + popupOffset.height > docElement.clientHeight) {
            if (top - btnOffset.height - popupOffset.height > docElement.clientTop) {
                top = top - btnOffset.height - popupOffset.height;
            }
        }
        if (btnOffset.left + popupOffset.width > docElement.clientWidth) {
            if (btnOffset.right - popupOffset.width > docElement.clientLeft) {
                left = (left + btnOffset.width) - popupOffset.width;
            }
        }
        left = e.getAttribute('data-index') == "0" ? left - element.getBoundingClientRect().width + popupOffset.width : left - element.getBoundingClientRect().width + btnOffset.width - getScrollBarWidth();
        (columnMenuElement as HTMLElement).style.left = Math.ceil(left + 1) + 'px';
        (columnMenuElement as HTMLElement).style.top = Math.ceil(top + 1) + 'px';
    },
    
    filterPopupRender: function filterPopupRender(dataId: string, dlgID: string, uid: string, type: string, isColumnMenu: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.filterModule.filterPopupRender(dlgID, uid, type, isColumnMenu);
        }
    },
    clientHeight: function clientHeight(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            return Math.max(gridInstance.element.blazor__instance.content.clientHeight, window.innerHeight || 0);
        }
        return 0;
    },
    clientTransformUpdate: function clientTransformUpdate(dataId: string, xPosition: number, yPosition: number, isOverscan : boolean = false) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.virtualContentModule.updateTransform(xPosition, yPosition, isOverscan);
        }
    },
    autoFitColumns(dataId: string, columns: Column[], fieldNames: string | string[], isAutoFit: boolean, isColumnResized: boolean = false) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            if (isAutoFit) {
                instance.options.columns = columns;
                instance.resizeModule.autoFitColumns(fieldNames);
            }
            if (isColumnResized) {
                var widthService = new ColumnWidthService(instance);
                widthService.setPersistedWidth(columns[0]);
            }
        }
    },
    autoFit(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.resizeModule.autoFit();
	    instance.scrollModule.setPadding();
        }
    },
    refreshColumnIndex(dataId: string, columns: Column[]) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var instance = gridInstance.element.blazor__instance;
            instance.options.columns = columns;
            instance.virtualContentModule.refreshColumnIndexes();
        }
    },
    focus(dataId: string, rowuid: string, celluid: string, action: string, keyCombination?: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        let cell: HTMLElement = gridInstance.element.querySelector("[data-uid=\"" + celluid + "\"]");
        let expandCollapseCell: boolean = cell.classList.contains('e-recordplusexpand') || cell.classList.contains('e-recordpluscollapse');
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && !isNullOrUndefined(cell)) {
            var instance = gridInstance.element.blazor__instance;
            if (!instance.options.enableVirtualization || (instance.options.enableVirtualization && !isNullOrUndefined(action) && (action === "UpdateRecord" || action === "ScrollSelect")) || (instance.options.enableColumnVirtualization && !isNullOrUndefined(action) && action === "ScrollSelect") || expandCollapseCell) {
                cell.focus();
            } else {
                instance.virtualContentModule.focusCell(cell, action, keyCombination);
            }
        }
    },
    handleCheckBoxSelection(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (gridInstance.element.querySelectorAll('.e-ftrchk.e-chkfocus').length > 0) {
            var selElements = gridInstance.element.querySelectorAll('.e-ftrchk.e-chkfocus');
            var crntElement = parentsUntil(document.activeElement, 'e-ftrchk');
            for (var i = 0; i < selElements.length; i++) {
                if (!isNullOrUndefined(crntElement) && (selElements[i].getAttribute('uid') == crntElement.getAttribute('uid') || crntElement.classList.contains("e-selectall"))) {
                    continue;
                }
                selElements[i].classList.remove('e-chkfocus');
            }
        }
    },
    focusFilterCheckBox(dataId: string, uid: string, isHeaderCheckBox: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        var headerCheckBox = gridInstance.element.querySelector('.e-selectall');

        if (isHeaderCheckBox) {
            if (!headerCheckBox.classList.contains('e-chkfocus'))
              {
                  parentsUntil(headerCheckBox, 'e-ftrchk').classList.add('e-chkfocus');
              }
            gridInstance.element.querySelector('.e-selectall').focus();
        } else {
            gridInstance.element.querySelector("[uid=\"" + uid + "\"]").querySelector('.e-chk-hidden').focus();
        }
    },
    focusFilterDialogElements(dataId: string, keyCombination: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        var activeElement = document.activeElement;
        var allCheckBoxes = gridInstance.element.querySelectorAll(".e-ftrchk");
        var isTabOrShiftTab = keyCombination == "Tab" || keyCombination == "ShiftTab";

        if (gridInstance.element.querySelectorAll('.e-ftrchk.e-chkfocus').length > 0) {
            var selElements = gridInstance.element.querySelectorAll('.e-ftrchk.e-chkfocus');
            for (var i = 0; i < selElements.length; i++) {
                selElements[i].classList.remove('e-chkfocus');
            }
        }

        if (activeElement.classList.contains("e-chk-hidden") && isTabOrShiftTab && !isNullOrUndefined(parentsUntil(activeElement, 'e-ftrchk'))) {
            parentsUntil(document.activeElement, 'e-ftrchk').classList.add('e-chkfocus');
        }
        else if (keyCombination == "ArrowDown" && !isNullOrUndefined(parentsUntil(activeElement, 'e-searchbox'))) {
            // move the focus to the first checkbox element, when ArrowDown is pressed from search bar in the filter dialog
            gridInstance.element.querySelector(".e-ftrchk").classList.add("e-chkfocus");
            gridInstance.element.querySelector(".e-ftrchk").querySelector(".e-chk-hidden").focus();
        }
        else if ((keyCombination == "ArrowDown" || keyCombination == "ArrowUp") && activeElement.classList.contains("e-chk-hidden")) {
              var siblings = Array.from(parentsUntil(activeElement, 'e-checkboxlist').children);
              var currentIndex = siblings.indexOf(parentsUntil(document.activeElement, 'e-ftrchk'));
              if (currentIndex < siblings.length - 1 && keyCombination == "ArrowDown") {
                  // Focus the next check-box sibling when ArrowDown is pressed
                  siblings[currentIndex + 1].classList.add('e-chkfocus');
                  (siblings[currentIndex + 1].querySelector(".e-chk-hidden") as HTMLElement).focus();
              } else if (currentIndex == siblings.length - 1 && keyCombination == "ArrowDown") {
                  var filterButton = !isNullOrUndefined(gridInstance.element.querySelector(".e-primary.e-flat"));
                  if (filterButton) {
                      // Focussing the filter button in the checkbox filter, while ArrowDown is pressed in the last checkbox.
                      gridInstance.element.querySelector(".e-primary.e-flat").focus();
                  }
              } else if (currentIndex - 1 >= 0 && keyCombination == "ArrowUp") {
                  // Focus the previous check-box sibling when ArrowUp is pressed
                  siblings[currentIndex - 1].classList.add('e-chkfocus');
                  (siblings[currentIndex - 1].querySelector(".e-chk-hidden") as HTMLElement).focus();
              } else if (keyCombination == "ArrowUp" && allCheckBoxes[0].querySelector(".e-chk-hidden") == activeElement) {
                  var searchBar = !isNullOrUndefined(gridInstance.element.querySelector(".e-searchinput.e-input"));
                  if (searchBar) {
                      gridInstance.element.querySelector(".e-searchinput.e-input").focus();
                  }
              }
        }
        else if ((keyCombination == "ArrowDown" || keyCombination == "ArrowUp") && activeElement.classList.contains("e-primary") && activeElement.classList.contains("e-flat")) {
            var cancelButton = !isNullOrUndefined(gridInstance.element.querySelector(".e-flat:not(.e-primary)"));
              if (cancelButton && keyCombination == "ArrowDown") {
                  // Focussing the Cancel button in the checkbox filter, while ArrowDown is pressed whwn the focus is on filter button.
                  gridInstance.element.querySelector(".e-flat:not(.e-primary)").focus();
              } else if (keyCombination == "ArrowUp") {
                  // Focussing the last checkbox in the checkbox filter, while ArrowUp is pressed whwn the focus is on filter button.
                  allCheckBoxes[allCheckBoxes.length - 1].classList.add("e-chkfocus");
                  allCheckBoxes[allCheckBoxes.length - 1].querySelector(".e-chk-hidden").focus();
              }
        }
        else if (keyCombination == "ArrowUp" && activeElement.classList.contains("e-flat") && !activeElement.classList.contains("e-primary")) {
            var filterButton = !isNullOrUndefined(gridInstance.element.querySelector(".e-primary.e-flat"));
            if (filterButton) {
                // Focussing the filter button when ArrowUp is pressed while the focus is on Cancel button.
                gridInstance.element.querySelector(".e-primary.e-flat").focus();
            }
        }
    },
    blurActiveElement(dataId: string) {
        const gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && !isNullOrUndefined(parentsUntil(document.activeElement, 'e-grid'))) {
          (document.activeElement as HTMLElement).blur();
        }
    },
    iterateElements(detailTemplateElements: HTMLElement, childGrid: HTMLElement, isChildGridNull: boolean ) { 
        for (let i = detailTemplateElements.children.length - 1; i >= 0; i--) {
            if (detailTemplateElements.children[i].classList.contains("sf-grid") && !isChildGridNull) {
                const isPagerNull = isNullOrUndefined(childGrid.querySelector(".e-pagercontainer"));
                const isLastPageIconNull = isNullOrUndefined(childGrid.querySelector(".e-lastpage"));
                if (isPagerNull) {
                    (childGrid.querySelectorAll(".e-rowcell:not(.e-hide)")[childGrid.querySelectorAll(".e-rowcell:not(.e-hide)").length - 1] as HTMLElement).focus();
                } else if (!isPagerNull && !isLastPageIconNull) {
                    (childGrid.querySelector(".e-lastpage") as HTMLElement).focus();
                } else if (!isPagerNull && isLastPageIconNull && childGrid.querySelectorAll(".e-numericitem")) {
                    (childGrid.querySelectorAll(".e-numericitem")[childGrid.querySelectorAll(".e-numericitem").length - 1] as HTMLElement).focus();
                }
                return;
            } else if ((detailTemplateElements.children[i] as HTMLElement).tabIndex == 0) {
                (detailTemplateElements.children[i] as HTMLElement).focus();
                return;
            } else if (!isNullOrUndefined(detailTemplateElements.children[i].children) && detailTemplateElements.children[i].children.length != 0) {
                this.iterateElements(detailTemplateElements.children[i] as HTMLElement, childGrid as HTMLElement, isChildGridNull);
                if (!document.activeElement.classList.contains("e-detailcell")) { return; }
                
            }
        }
    },
    focusDetailTemplateElements(dataId: string, keyCombination: string, isDetailTemplateCell: boolean) {
        let gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (isNullOrUndefined(gridInstance.element) && isNullOrUndefined(gridInstance.element.blazor__instance) && isNullOrUndefined(parentsUntil(document.activeElement, "e-grid"))) { 
            return;
        }
        var childGrid = document.activeElement.querySelector(".e-grid");
        var isChildGridNull = isNullOrUndefined(childGrid);
        if (keyCombination == "Tab") {
            (document.activeElement as HTMLElement).blur();
        } else if (keyCombination == "ShiftTab") {
            var detailTemplateElements = parentsUntil(document.activeElement, "e-detailcell").firstElementChild;

            if (detailTemplateElements.children.length != 0 && isDetailTemplateCell) {
                this.iterateElements(detailTemplateElements as HTMLElement, childGrid as HTMLElement, isChildGridNull);
            }
            
            if (document.activeElement.classList.contains("e-detailcell")) {
                var previousRowCells = document.activeElement.parentElement.previousElementSibling.querySelectorAll(".e-rowcell:not(.e-hide)");
                (previousRowCells[previousRowCells.length - 1] as HTMLElement).focus();
                return;
            }
        }
        
    },
    updateFilterBarCell(dataId: string, filteredFields: string[], filteredActualValue: string[]){
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        var filterRow = gridInstance.element.querySelector(".e-filterbar");
        if (isNullOrUndefined(filterRow)) { return; }
        filteredFields.forEach((fieldName, i) => {
            var filterCell = filterRow.querySelectorAll("#" + fieldName + "_filterBarcell");
            if (filterCell.length > 0) {
                filterCell[0].value = filteredActualValue[i];
            }
        });
    },
    focusFilterBar(dataId: string, keyCombination: string, isFilterTemplate: boolean, index: number) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        var filterRow = gridInstance.element.querySelector(".e-filterbar");
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && !isNullOrUndefined(filterRow)) {
            if (keyCombination == "Tab") {
                if (document.activeElement.classList.contains("e-headercell")) {
                    var filterBar = filterRow.querySelector(".e-textbox.e-input:not([disabled])");
                    
                    if (isFilterTemplate) {
                        var filterTemplateInput = filterRow.querySelector(".e-fltrinputdiv").querySelector("input");
                        if (!isNullOrUndefined(filterTemplateInput)) {
                            filterTemplateInput.focus();
                        }
                        else {
                            filterRow.querySelector(".e-fltrinputdiv").children[0].focus();
                        }
                        
                    } else if (!isNullOrUndefined(filterBar)) {
                          filterBar.focus();
                    }
                }
            }
            else if (keyCombination == "ShiftTab") {
                if (document.activeElement.classList.contains("e-rowcell") || document.activeElement.classList.contains("e-recordplusexpand")) {
                    var filterBar = filterRow.querySelectorAll(".e-textbox.e-input:not([disabled])");
                    
                    if (isFilterTemplate) {
                        var filterElements = filterRow.querySelectorAll(".e-fltrinputdiv");
                        var lastFilterTemplate = filterElements[filterElements.length - 1].querySelector("input");
                        if (!isNullOrUndefined(lastFilterTemplate)) {
                            lastFilterTemplate.focus();
                        } else {
                            filterElements[filterElements.length - 1].children[0].focus();
                        }
                    } else if (!isNullOrUndefined(filterBar)) {
                        filterBar[filterBar.length - 1].focus();
                    }
                }                                
            }
            else if (keyCombination == "ArrowUp" || keyCombination == "ArrowDown") {
                if (document.activeElement.classList.contains("e-groupcaption") || document.activeElement.classList.contains("e-recordplusexpand")) {
                    filterRow.querySelector(".e-textbox.e-input:not([disabled])").focus();
                } else if (isFilterTemplate ) {
                    var filterTemplateInput = filterRow.querySelectorAll(".e-fltrinputdiv")[index == -1 ? document.activeElement.getAttribute("data-colIndex") : index].querySelector("input");
                    
                    if (!isNullOrUndefined(filterTemplateInput)) {
                        filterTemplateInput.focus();
                    } else {
                        filterRow.querySelectorAll(".e-fltrinputdiv")[index == -1 ? document.activeElement.getAttribute("data-colIndex") : index].children[0].focus();
                    }
                    
                } else {
                    filterRow.querySelectorAll(".e-input")[index == -1 ? document.activeElement.getAttribute("data-colIndex") : index].focus();
                }
            }
        }
    },
    focusAddForm: function (dataId: string, keyCombination: string) {
        let gridInstance = this.sfBlazor.getCompInstance(dataId);
        let showAddNewRow: HTMLTableRowElement = gridInstance.element.querySelector(".e-showAddNewRow");
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && !isNullOrUndefined(showAddNewRow)) {
            if (keyCombination == "Tab") {
                if ((document.activeElement as HTMLElement).classList.contains("e-headercell")) {
                    let inputTextBox: HTMLInputElement = showAddNewRow.querySelector(".e-input:not([disabled])");
                    if (!isNullOrUndefined(inputTextBox)) {
                        inputTextBox.focus();
                    }
                }
            }
            else if (keyCombination == "ShiftTab") {
                if ((document.activeElement as HTMLElement).classList.contains("e-rowcell") || (document.activeElement as HTMLElement).classList.contains("e-recordplusexpand") || (document.activeElement as HTMLElement).classList.contains("e-recordpluscollapse")) {
                    let inputTextBox: NodeListOf<HTMLInputElement> = showAddNewRow.querySelectorAll(".e-input:not([disabled])");
                    var tds = showAddNewRow.querySelectorAll(".e-rowcell:not(.e-hide)");
                    let commonElements:  HTMLElement[]  = [];
                    tds.forEach(function (td) {
                        let inputInTd : HTMLElement = td.querySelector('.e-input:not([disabled])');
                        if (inputInTd && Array.from(inputTextBox).some(input => input === inputInTd)) {
                            commonElements.push(inputInTd);
                        }
                    });
                    if (!isNullOrUndefined(tds)) {
                        commonElements[commonElements.length - 1].focus();
                    }
                }
            }
            else if (keyCombination == "ArrowUp" || keyCombination == "ArrowDown") {
                if ((document.activeElement as HTMLElement).classList.contains("e-groupcaption") || (document.activeElement as HTMLElement).classList.contains("e-recordplusexpand") || (document.activeElement as HTMLElement).classList.contains("e-recordpluscollapse")) {
                    let inputTextBox: HTMLElement = showAddNewRow.querySelector(".e-input:not([disabled])");
                    if (!isNullOrUndefined(inputTextBox)) {
                        inputTextBox.focus();
                    }
                }
                else {
                    let colIndex = (document.activeElement as HTMLElement).getAttribute("data-colIndex");
                    let index: number = 0;
                    if (colIndex !== null) {
                    index = parseInt(colIndex, 10);
                    } 
                    let inputElement = showAddNewRow.querySelectorAll(".e-input")[index] as HTMLInputElement;
                    inputElement.focus();
                }
            }
        }
    },
    focusFirstGroupHeader(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var firstGroupHeader = gridInstance.element.querySelector(".e-groupheadercell");
            if (!isNullOrUndefined(firstGroupHeader)){
                firstGroupHeader.focus();
            }
        }
    },
    focusExcelInput(dataId: string, celluid: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        let excelPopup: HTMLElement = document.querySelector("#" + celluid + "_excelDlg");
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && !isNullOrUndefined(excelPopup)) {
            setTimeout(() => {
                (excelPopup.querySelector("#" + gridInstance.element.id + "_SearchBox") as HTMLElement).focus();
            }, 10);
        }
    },
    refreshOnDataChange(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.virtualContentModule.refreshOnDataChange();
        }
    },
    updateAutofillPosition(dataId: string, cellindex: number, index: number) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var _this = gridInstance.element.blazor__instance;
            return _this.selectionModule.updateAutofillPosition(cellindex, index);
        }
        else{
            return null;
        }
    },
    createBorder(dataId: string, rowIndex: number, cellIndex: number) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            var _this = gridInstance.element.blazor__instance;
            return _this.selectionModule.createBorder(rowIndex, cellIndex);
        }
        else{
            return null;
        }
    },
    removePersistItem(dataId: string, id: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            let _this: SfGrid = gridInstance.element.blazor__instance;
            (_this.getHeaderTable() as HTMLTableElement).style.width = "";
            (_this.getContentTable() as HTMLTableElement).style.width = "";
            if (_this.options.aggregatesCount != 0) {
                (_this.getFooterContent().querySelector(".e-table") as HTMLTableElement).style.width  = "";
            }
            if (_this.options.frozenColumns > 0) {
                (_this.element.querySelector(".e-movableheader").querySelector('.e-table') as HTMLTableElement).style.width = "";
                (_this.element.querySelector(".e-movablecontent").querySelector('.e-table') as HTMLTableElement).style.width = "";
            }
        }
        localStorage.removeItem(id);
    },
    focusChild(dataId: string, rowuid: string, celluid: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        var childElements = gridInstance.element.querySelector("[data-uid=\"" + celluid + "\"]").firstElementChild.children;
        var firstFocusableElement = gridInstance.iterateTemplateElementsForward(childElements);

        /* Select the first focusable child element
         * if no child found then select the cell itself.
         * if Grid is in editable state, check for editable control inside child.
         */
        
        !isNullOrUndefined(firstFocusableElement) ? firstFocusableElement.focus(): (<HTMLElement>gridInstance.element.querySelector("[data-uid=\"" + celluid + "\"]")).focus();
        return !isNullOrUndefined(firstFocusableElement) ? true : false;
    },
    exportSave(filename: string, bytesBase64: string) {
        if (navigator.msSaveBlob) {
            //Download document in Edge browser
            let data: string = window.atob(bytesBase64);
            let bytes: any = new Uint8Array(data.length);
            for (var i = 0; i < data.length; i++) {
                bytes[i] = data.charCodeAt(i);
            }
            let blob = new Blob([bytes.buffer], { type: "application/octet-stream" });
            navigator.msSaveBlob(blob, filename);
        }
        else {
            let link: HTMLAnchorElement = document.createElement('a');
            link.download = filename;
            link.href = "data:application/octet-stream;base64," + bytesBase64;
            document.body.appendChild(link); // Needed for Firefox
            link.click();
            document.body.removeChild(link);
        }
    },
    destroy(dataId: string, isRerendered: Boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.destroy(isRerendered);
        }
    },

    validation(dataId: string, results: object[], isAdd: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.editModule.createTooltip(results, isAdd);
        }
    },

    focusCell(dataId: string, field: string, isAdd: boolean, frozenEdit: boolean = false) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (isAdd && !isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance) && gridInstance.element.blazor__instance.options.frozenColumns && !gridInstance.element.blazor__instance.options.showAddNewRow) {
            (gridInstance.element.querySelector('.e-frozencontent') as HTMLElement).style.height =
            gridInstance.element.querySelector('.e-movablecontent').getBoundingClientRect().height + 'px';
        }
        let complexField: string = `#${field.replace(/[.]/g, "___")}`;
        complexField = complexField + ':not(.e-disabled)';
        if (frozenEdit) {
            let forms: HTMLFormElement[] = [].slice.call(gridInstance.element.querySelectorAll('form'));
            let td: HTMLElement;
            for (let i: number = 0; i < forms.length; i++) {
                td = forms[i].querySelector('td:not(.e-hide)');
                td.style.height = closest(td, '.e-row').getBoundingClientRect().height + 'px';
            }
        }
        let complexElement: HTMLElement = gridInstance.element.querySelector(complexField);
        if (field !== "" && complexElement === null && complexField.includes('___')) {
            complexField = complexField.split('___').pop();
            complexElement = gridInstance.element.querySelector('#' + complexField);
        }
        if (field === "" && gridInstance.element.querySelector("input.e-boolcell")) {
            (gridInstance.element.querySelector("input.e-boolcell") as HTMLElement).focus();
        } else if (field !== "" && complexElement) {
            let lastAddedRow: boolean = (gridInstance.getContent().querySelector('tbody') as HTMLElement).classList.contains('e-addedrow');
            let preventScrolling: boolean = gridInstance.options.enableVirtualization && gridInstance.options.allowEditing && gridInstance.options.isEdit && !lastAddedRow;
            complexElement.focus({ preventScroll : preventScrolling});
        }
    },

    CurrentPageFocus(dataId: string, key: string, currentPage: string) {
        var pagerInstance = this.sfBlazor.getCompInstance(dataId);
        var numericContainer = pagerInstance.element.querySelector(".e-numericcontainer");
        if (key == "PreviousPage" || (numericContainer.querySelectorAll(".e-link:last-child")[0] as HTMLElement).innerText != currentPage) {
            (numericContainer.querySelector(".e-link") as HTMLElement).focus();
        } else {
            (numericContainer.querySelectorAll(".e-link:last-child")[0] as HTMLElement).focus();
        }
    },

    pagerFocus(dataId: string, key: string) {
        var pagerInstance = this.sfBlazor.getCompInstance(dataId);
        let pagerContainer: HTMLElement = pagerInstance.element.querySelector(".e-gridpager").querySelector(".e-pagercontainer");
        let numericContainer: HTMLElement = pagerContainer.querySelector(".e-numericcontainer");
        let firstPage: HTMLElement = pagerContainer.querySelector(".e-firstpage.e-pager-default");
        let previousPage: HTMLElement = pagerContainer.querySelector(".e-prevpage.e-pager-default");
        if (key === "ArrowDown") {
            if (firstPage) {
                (firstPage as HTMLElement).focus();
                return "FirstPage";
            } else if (previousPage) {
                (firstPage as HTMLElement).focus();
                return "PreviousPage";
            } else {
                (numericContainer.querySelectorAll('.e-link')[1] as HTMLElement).focus();
                return "1";
            }
        } else if (key == "ArrowRight") {
            if (firstPage != null && firstPage.classList.contains("e-focused")) {
                (previousPage as HTMLElement).focus();
                return "PreviousPage";
            } else if (previousPage != null && previousPage.classList.contains("e-focused") || pagerContainer.querySelector(".e-pp.e-focused") != null) {
                if (pagerContainer.querySelector(".e-pp") != null && !pagerContainer.querySelector(".e-pp").classList.contains("e-focused")) {
                    (pagerContainer.querySelector('.e-pp') as HTMLElement).focus();
                    return "PreviousPagerCount";
                } else {
                    (numericContainer.querySelectorAll('.e-link')[0] as HTMLElement).focus();
                    return (numericContainer.querySelectorAll('.e-link')[0] as HTMLElement).innerText;
                }
            } else if (numericContainer.querySelectorAll(".e-link.e-focused").length > 0 && pagerContainer.querySelector('.e-link.e-focused') != null && pagerContainer.querySelector('.e-link.e-focused').nextElementSibling != null) {
                (numericContainer.querySelector('.e-link.e-focused').nextElementSibling as HTMLElement).focus();
                return (numericContainer.querySelector('.e-link.e-focused').nextElementSibling as HTMLElement).innerText;
            } else if (numericContainer.querySelectorAll(".e-link.e-focused").length > 0 && pagerContainer.querySelector(".e-np") != null && pagerContainer.querySelector(".e-np.e-focused") == null) {
                (pagerContainer.querySelector('.e-np') as HTMLElement).focus();
                return "NextPagerCount";
            } else if (numericContainer.querySelectorAll(".e-link.e-focused").length > 0 || pagerContainer.querySelectorAll(".e-np.e-focused").length > 0) {
                if (pagerContainer.querySelector('.e-nextpage') != null) {
                    (pagerContainer.querySelector('.e-nextpage') as HTMLElement).focus();
                    return "NextPage";
                } else {
                    (numericContainer.querySelector(".e-link.e-focused") as HTMLElement).focus();
                    return (numericContainer.querySelector(".e-link.e-focused") as HTMLElement).innerText;
                }
            } else if (pagerContainer.querySelector(".e-nextpage.e-focused") != null) {
                (pagerContainer.querySelector('.e-lastpage') as HTMLElement).focus();
                return "LastPage";
            } else {
                (pagerContainer.querySelector('.e-lastpage') as HTMLElement).focus();
                return "LastPage";
            }
        }
        else if (key == "ArrowLeft") {
            if (previousPage != null && previousPage.classList.contains("e-focused")) {
                (firstPage as HTMLElement).focus();
                return "FirstPage";
            } else if (previousPage && pagerContainer.querySelector(".e-pp.e-focused")) {
                (previousPage as HTMLElement).focus();
                return "PreviousPage";
            } else if (numericContainer.querySelectorAll('.e-link')[0].classList.contains('e-focused')) {
                if (pagerContainer.querySelector(".e-pp") != null) {
                    (pagerContainer.querySelector(".e-pp") as HTMLElement).focus();
                    return "PreviousPagerCount";
                } else if (previousPage) {
                    (previousPage as HTMLElement).focus();
                    return "PreviousPage";
                } else {
                    (numericContainer.querySelectorAll('.e-link')[0] as HTMLElement).focus();
                    return "1";
                }
            } else if (numericContainer.querySelectorAll(".e-link.e-focused").length > 0) {
                (numericContainer.querySelector('.e-link.e-focused').previousElementSibling as HTMLElement).focus();
                return (numericContainer.querySelector('.e-link.e-focused').previousElementSibling as HTMLElement).innerText;
            } else if (pagerContainer.querySelectorAll(".e-nextpage.e-focused").length > 0 && pagerContainer.querySelector(".e-np") != null) {
                (pagerContainer.querySelector('.e-np') as HTMLElement).focus();
                return "NextPagerCount";
            } else if (pagerContainer.querySelectorAll(".e-nextpage.e-focused").length > 0 || pagerContainer.querySelectorAll(".e-np.e-focused").length > 0) {
                let page = numericContainer.querySelectorAll('.e-link').length;
                (numericContainer.querySelectorAll('.e-link')[page - 1] as HTMLElement).focus();
                return (numericContainer.querySelectorAll(".e-link:last-child")[0] as HTMLElement).innerText;
            } else if (pagerContainer.querySelector(".e-lastpage.e-focused") != null) {
                (pagerContainer.querySelector('.e-nextpage') as HTMLElement).focus();
                return "NextPage";
            } else {
                if (!firstPage.classList.contains('.e-disabled')) {
                    (firstPage as HTMLElement).focus();
                    return "FirstPage";
                }
                return "0";
            }
        }
        else { return "0"; }
    }, 

    setFrozenHeight(element: BlazorGridElement) {
        (element.querySelector('.e-frozencontent') as HTMLElement).style.height =
            (element.querySelector('.e-movablecontent') as HTMLElement).offsetHeight - getScrollBarWidth() + 'px';
    },

    printGrid(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.print();
        }
    },
    updateMediaColumns(dataId: string, mediaColumnsUid: { [uid: string]: boolean }) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.columnChooserModule.updateMediaColumns(mediaColumnsUid);
        }
    },
    copyToClipBoard(dataId: string, withHeader?: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.clipboardModule.copy(withHeader);
        }
    },
    preventCopyToClipBoard(dataId: string, cancelValue: boolean, value: string, action: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        var gridclipBoardElement = gridInstance.clipboardModule;
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            if(action === "Copy"){
                gridclipBoardElement.clipBoardData(cancelValue, value);
            }
            else if(action === "Paste"){
                gridclipBoardElement.pasteAction(value, gridclipBoardElement.getSelectedRowCellIndexes()[0].rowIndex, gridclipBoardElement.getSelectedRowCellIndexes()[0].cellIndexes[0], cancelValue);
            }
        }
    },
    preventPasteAction(dataId: string, rowIndex: number, columnField: string, value: string, columnIndex: number, cancelValue: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.clipboardModule.pasteData(rowIndex, columnField, value, columnIndex, cancelValue);
        }
    },
    setMediaColumns: function setMediaColumns(dataId: string, isResetPersistData?: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            gridInstance.element.blazor__instance.columnChooserModule.setMediaColumns(isResetPersistData);
        }
    },
    gridFocus(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element)) {
            var groupHeaderCells = gridInstance.element.querySelectorAll(".e-groupheadercell").length;
            if (gridInstance.element.querySelectorAll(".e-toolbar-item").length != 0) {
                let visibleToolbarItems = gridInstance.element.querySelectorAll(".e-toolbar-item:not(.e-overlay)");
                let focusElement = null;
                if (!isNullOrUndefined(visibleToolbarItems) && visibleToolbarItems.length != 0) {
                    let lastToolbarIndex: number = visibleToolbarItems.length - 1;
                    if (!isNullOrUndefined(visibleToolbarItems[lastToolbarIndex].querySelector(".e-tbar-btn"))) {
                        for (var i = lastToolbarIndex; i >= 0; i--) {
                            if (!isNullOrUndefined(visibleToolbarItems[i].querySelector(".e-tbar-btn")) && visibleToolbarItems[i].querySelector(".e-tbar-btn").tabIndex == 0) {
                                focusElement = visibleToolbarItems[i].querySelector(".e-tbar-btn");
                                break;
                            }
                        }
                        focusElement.focus();
                        return;
                    } else if (!isNullOrUndefined(visibleToolbarItems[lastToolbarIndex].querySelector(".e-searchinput.e-input"))) {
                        visibleToolbarItems[lastToolbarIndex].querySelector(".e-searchinput.e-input").focus();
                        return;
                    }
                }
                
            } else if (groupHeaderCells > 0 && (document.activeElement.classList.contains("e-headercell") || document.activeElement.classList.contains("e-recordplusexpand") || document.activeElement.classList.contains("e-recordpluscollapse") )) {
                var unGroupButtons = gridInstance.element.querySelectorAll(".e-ungroupbutton");
                unGroupButtons[unGroupButtons.length - 1].focus();
                return;
            } else if (groupHeaderCells == 0 && gridInstance.options.allowGrouping && document.activeElement.classList.contains("e-headercell")) {
                gridInstance.element.querySelector(".e-groupdroparea").focus();
                return;
            }

            if (parentsUntil(document.activeElement, 'e-grid')) {
                gridInstance.element.focus();
            } 
        }
    },

    isMacDevice() {
		return navigator.userAgent.indexOf("Mac OS") !== -1;
	},

    updateClonedMaskTranslates(dataId:string){
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        let gObj: SfGrid = gridInstance.element.blazor__instance;
        let gridContent = gObj.getContent();
        let maskedTable: HTMLElement = gridContent.querySelector('.e-masked-table');
        let minScrollTop: number = gridContent.scrollHeight - maskedTable.getBoundingClientRect().height;
        let scrollTop: number = gridContent.scrollTop <= minScrollTop ? gridContent.scrollTop : minScrollTop;
        maskedTable.style.transform = 'translate(0px,' + scrollTop + 'px)';
    },

    refreshScrollLeftPosition: function refreshScrollLeftPosition(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        if (!isNullOrUndefined(gridInstance.element) && !isNullOrUndefined(gridInstance.element.blazor__instance)) {
            let gObj: SfGrid = gridInstance.element.blazor__instance;
            let scrollContent = gObj.getContent();
            let scrollLeft: number = scrollContent.scrollLeft;
            scrollContent.scrollLeft = scrollLeft + 20;
        }
    },

    refreshGridPageSize(dataId: string) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        gridInstance.scrollModule.refresh();
    },

    focusColumnChooserCheckBox(dataId: string, keyCombination: string, isTemplate: boolean) {
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        let activeElement = document.activeElement as HTMLElement;
        var isTabOrShiftTab = keyCombination == "Tab" || keyCombination == "ShiftTab";
        var removeFocusClass = function (selector: string) {
            var selElements = gridInstance.element.querySelectorAll(selector);
            selElements.forEach(function (el: HTMLElement) {
                el.classList.remove('e-colfocus');
            });
        };
        if (!isTemplate) {
            removeFocusClass('.e-cclist.e-colfocus');
            if (activeElement.classList.contains("e-chk-hidden") && isTabOrShiftTab && !isNullOrUndefined(parentsUntil(activeElement, 'e-cclist'))) {
                parentsUntil(document.activeElement, 'e-cclist').classList.add('e-colfocus');
            }
        }
        else {
            removeFocusClass('.e-ccheck.e-colfocus');
            if (activeElement.classList.contains("e-chk-hidden") && isTabOrShiftTab && !isNullOrUndefined(parentsUntil(activeElement, 'e-ccheck'))) {
                parentsUntil(document.activeElement, 'e-ccheck').classList.add('e-colfocus');
            }
        }
    },
    
    scrollIntoView(dataId: string, columnIndex: number, rowIndex: number, rowHeight: number, isAddBottom: boolean = false, isFromAddForm: boolean = false){
        var gridInstance = this.sfBlazor.getCompInstance(dataId);
        let gObj: SfGrid = gridInstance.element.blazor__instance;
        let scrollContent = gObj.getContent();
        let prevScrollTop: number = scrollContent.scrollTop;
        gObj.virtualContentModule.focusColumnIndex = columnIndex;
        if (isAddBottom) {
            scrollContent.scrollTop = scrollContent.scrollHeight;
        }
        else if (rowIndex != -1) {
            scrollContent.scrollTop = rowHeight != -1 ? rowIndex * rowHeight : rowIndex * gObj.getRowHeight();
            gObj.virtualContentModule.selectedRowIndex = rowIndex;
            gObj.virtualContentModule.isScrollIntoview = true;
            if (!isFromAddForm && ((rowIndex == 0 && prevScrollTop == 0) || ((prevScrollTop == scrollContent.scrollTop) && !((gObj.virtualContentModule.scrollInfo.direction === "left") || (gObj.virtualContentModule.scrollInfo.direction === "right"))))) {
                gObj.dotNetRef.invokeMethodAsync("SelectRow", rowIndex, gObj.virtualContentModule.isScrollIntoview, gObj.virtualContentModule.focusColumnIndex);
                gObj.virtualContentModule.selectedRowIndex = -1;
            }
            else if (rowIndex >= gObj.options.totalItemCount) {
                gObj.virtualContentModule.selectedRowIndex = gObj.options.totalItemCount - 1;
            }
        }
        let columnOffsets = gObj.virtualContentModule.vHelper.cOffsets;
        let colOffsets =gObj.nColumnOffsets;
        setTimeout(function() {
            if (!gObj.options.frozenColumns && columnIndex != -1) {
                if (gObj.options.enableColumnVirtualization) {
                    scrollContent.scrollLeft = columnOffsets[columnIndex - 1];
                }
                else {
                    scrollContent.scrollLeft = colOffsets[columnIndex - 1];
                }
            }
        if(gObj.options.enableColumnVirtualization && columnIndex > 0){
            if(gObj.options.frozenColumns){
                let customIndex = columnIndex - (gObj.virtualContentModule.movableColumnIndex + 1);
                scrollContent.scrollLeft = columnOffsets[customIndex];
            }
        }  
    }, 20);    
}
};

export default Grid;
