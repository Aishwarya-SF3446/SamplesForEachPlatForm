import { isNullOrUndefined } from '@syncfusion/ej2-base';
import { SfGrid } from './sf-grid-fn';
import { Column } from './interfaces';
import { formatUnit } from '@syncfusion/ej2-base';
import { parentsUntil } from './util';

/**
 * ColumnWidthService
 * @hidden
 */
export class ColumnWidthService {
    private parent: SfGrid;

    constructor(parent: SfGrid) {
        this.parent = parent;
    }

    public setMinwidthBycalculation(tWidth?: number): void {
        let difference: number = 0;
        let collection: Column[] = this.parent.getColumns().filter((a: Column) => {
            return isNullOrUndefined(a.width) || a.width === 'auto' || a.width === '';
        });
        if (collection.length) {
            if (!isNullOrUndefined(this.parent.options.width) && this.parent.options.width !== 'auto' && this.parent.options.width !== '100%') {
                difference = (typeof this.parent.options.width === 'string' ? parseInt(this.parent.options.width, 10) : this.parent.options.width) - tWidth;
            }
            else {
                difference = this.parent.element.getBoundingClientRect().width - tWidth;
            }
            let tmWidth: number = 0;
            let minWidth = 0;
            for (let cols of collection) {

                tmWidth += !isNullOrUndefined(cols.minWidth) ?
                    ((typeof cols.minWidth === 'string' ? parseInt(cols.minWidth, 10) : cols.minWidth)) : 0;
            }
            let minWidthValues = {};
            for (let i: number = 0; i < collection.length; i++) {
                if (tWidth === 0 && this.parent.options.allowResizing && this.isWidthUndefined() && (i !== collection.length - 1)) {
                    this.setUndefinedColumnWidth(collection);
                }
                if (tWidth !== 0 && difference < tmWidth) {
                    minWidthValues[collection[i].field] = collection[i].minWidth + 'px';
                    minWidth += parseInt(collection[i].minWidth.toString(), 10);
                } else if (tWidth !== 0 && difference > tmWidth) {
                    minWidthValues[collection[i].field] = '';
                    minWidth += 0;
                }
            }
            this.parent.dotNetRef.invokeMethodAsync('SetMinWidth', minWidthValues);
            if (this.parent.options.frozenColumns) {
                this.parent.freezeModule.setFrozenHeight(minWidth);
            }
        }
    }

    public setUndefinedColumnWidth(collection?: Column[]): void {
        for (let k: number = 0; k < collection.length; k++) {
            if (k !== collection.length - 1) {
                collection[k].width = 200;
                this.setWidth(200, this.parent.getColumnIndexByField(collection[k].field));
            }
        }
    }

    public setColumnWidth(column: Column, index?: number, module?: string, allowStopEvent: boolean = true, virtualAutoFit: boolean = false): void {
        if (this.parent.getColumns(virtualAutoFit).length < 1) {
            return;
        }
        let columnIndex: number;
        if (this.parent.options.enableColumnVirtualization) {
            columnIndex = this.parent.options.virtualizedColumns.findIndex(col => col.uid == column.uid) + this.parent.getIndentCount();
        } else {
            columnIndex = isNullOrUndefined(index) ? this.parent.getNormalizedColumnIndex(column.uid) : index;
        }
        let cWidth: string | number = this.getWidth(column); 
        let tgridWidth: number = this.getTableWidth(this.parent.getColumns(virtualAutoFit));
        if (cWidth !== null) {
            this.setWidth(cWidth, columnIndex);
            if (this.parent.options.width !== 'auto' && this.parent.options.width.toString().indexOf('%') === -1) {
                this.setMinwidthBycalculation(tgridWidth);
            }
            if (this.parent.options.enableColumnVirtualization && module === 'resize') {
                this.parent.options.virtualizedColumns.filter((col: Column) => col.uid == column.uid)[0].width = cWidth;
				this.parent.virtualContentModule.refreshOffsets();
				this.parent.virtualContentModule.setVirtualHeight();
            }
            else if(this.parent.options.enableColumnVirtualization && virtualAutoFit){
                this.parent.options.columns.filter((col: Column) => col.uid == column.uid)[0].width = cWidth;
				this.parent.virtualContentModule.refreshOffsets();
            }
            if ((this.parent.options.allowResizing && module === 'resize') || (this.parent.options.frozenColumns && this.parent.options.allowResizing)) {
                this.setWidthToTable(null, false, 'resize');
            }
            if (allowStopEvent) {
                if (cWidth.toString().indexOf("px") > 0) {
                    cWidth = cWidth.toString().replace("px", "");
                }
                this.parent.dotNetRef.invokeMethodAsync("ColumnWidthChanged", { index: columnIndex, width: cWidth, columnUid: column.uid });
            }
        }
    }

    public setWidth(width: string | number, index: number, clear?: boolean): void {
        let chrome: string = 'chrome';
        let webstore: string = 'webstore';
        if (typeof (width) === 'string' && width.indexOf('%') !== -1 &&
            !(Boolean(window[chrome]) && Boolean(window[chrome][webstore])) && this.parent.options.allowGrouping) {
            let elementWidth: number = this.parent.element.offsetWidth;
            width = parseInt(width, 10) / 100 * (elementWidth);
        }
        let header: Element = this.parent.getHeaderTable();
        let content: Element = this.parent.getContentTable();
        let fWidth: string = formatUnit(width);
        let headerCol: HTMLTableColElement;
        let frzCols: number = this.parent.options.frozenColumns;
        let mHdr: Element = this.parent.getHeaderContent().querySelector('.e-movableheader');
        let mCont: HTMLElement = <HTMLTableColElement>this.parent.getContent().querySelector('.e-movablecontent');
        let movableCount: number = 0;
        if (this.parent.options.frozenRightCount != 0 || this.parent.options.frozenLeftCount != 0) {
            this.parent.updateColumnLevelFrozen();
            var frozenIndex = this.parent.options.enableColumnVirtualization ? index : this.parent.frozenColumnModel.findIndex(x => x.uid == this.parent.columnModel[index].uid);
            var target: Element;
            if (this.parent.options.frozenName == "Left") {
                target = frozenIndex < this.parent.options.frozenLeftCount ? header : mHdr;
            }
            if (this.parent.options.frozenName == "Right") {
                movableCount = this.parent.options.columns.length - this.parent.options.frozenRightCount;
                target = frozenIndex >= movableCount ? header : mHdr;
            }
            else if (this.parent.options.frozenName == "LeftRight") {
                movableCount = this.parent.options.columns.length - this.parent.options.frozenRightCount - this.parent.options.frozenLeftCount;
                var frHdr = this.parent.getHeaderContent().querySelector('.e-frozen-right-header');
                target = frozenIndex < this.parent.options.frozenLeftCount ? header : frozenIndex < (this.parent.options.frozenLeftCount + movableCount) ? mHdr : frHdr;
            }
            headerCol = this.getColumnLevelFrozenColgroup(frozenIndex, this.parent.options.frozenLeftCount, movableCount, target);
            if (!headerCol) {
                return;
            }
        }
        else {
            if (frzCols && index >= frzCols && mHdr && mHdr.querySelector('colgroup')) {
                headerCol = (<HTMLTableColElement>mHdr.querySelector('colgroup').children[index - frzCols]);
            } else {
                headerCol = (<HTMLTableColElement>header.querySelector('colgroup').children[index]);
            }
        }
        
        if (headerCol && !clear) {
            headerCol.style.width = fWidth;
        } else if (headerCol && clear) {
            headerCol.style.width = ' ';
        }
        let contentCol: HTMLTableColElement;
        if (this.parent.options.frozenRightCount != 0 || this.parent.options.frozenLeftCount != 0) {
            var target: Element;
            var frozenIndex = this.parent.options.enableColumnVirtualization ? index : this.parent.frozenColumnModel.findIndex(x => x.uid == this.parent.columnModel[index].uid);
            if (this.parent.options.frozenName == "Left") {
                target = frozenIndex < this.parent.options.frozenLeftCount ? content : mCont;
            }
            if (this.parent.options.frozenName == "Right") {
                movableCount = this.parent.options.columns.length - this.parent.options.frozenRightCount;
                target = frozenIndex >= movableCount ? content : mCont;
            }
            if (this.parent.options.frozenName == "LeftRight") {
                var frCont = this.parent.getContent().querySelector('.e-frozen-right-content');
                target = frozenIndex < this.parent.options.frozenLeftCount ? content : frozenIndex < (this.parent.options.frozenLeftCount + movableCount) ? mCont : frCont;
            }
            contentCol = this.getColumnLevelFrozenColgroup(frozenIndex, this.parent.options.frozenLeftCount, movableCount, target);
        }
        else {
            contentCol = (<HTMLTableColElement>content.querySelector('colgroup').children[index]);
        }
        if (contentCol && !clear) {
            contentCol.style.width = fWidth;
        } else if (contentCol && clear) {
            contentCol.style.width = ' ';
        }

        if (this.parent.options.aggregatesCount != 0) {
            let footerCol: HTMLTableColElement;
            let tcolGroup: Element = this.parent.getFooterContent().querySelector('colgroup');
            footerCol = !isNullOrUndefined(tcolGroup) ? <HTMLTableColElement>tcolGroup.children[index] : null;

            if (contentCol && footerCol && !clear) {
                footerCol.style.width = fWidth;
            } else if (contentCol && footerCol && clear) {
                footerCol.style.width = ' ';
            }
        }

        let edit: NodeListOf<Element> = this.parent.element.querySelectorAll('.e-table.e-inline-edit');
        let editTableCol: HTMLTableColElement[] = [];
        for (let i: number = 0; i < edit.length; i++) {
            if (parentsUntil(edit[i], 'e-grid').id === this.parent.element.id) {
                for (let j: number = 0; j < edit[i].querySelector('colgroup').children.length; j++) {
                    editTableCol.push((<HTMLTableColElement>edit[i].querySelector('colgroup').children[j]));
                }
            }
        }
        if (edit.length && editTableCol.length) {
            editTableCol[index].style.width = fWidth;
        }
        if (this.parent.options.frozenColumns != 0 && !this.parent.options.enableColumnVirtualization) {
            this.parent.freezeModule.setFrozenHeight();
        }
    }
    private getColumnLevelFrozenColgroup(index: number, left: number, movable: number, ele: Element): HTMLTableColElement {
        if (!ele || !ele.querySelector('colgroup')) {
            return null;
        }
        const columns:Column[]  = this.parent.options.enableColumnVirtualization ? this.parent.options.virtualizedColumns :  this.parent.frozenColumnModel;
        let headerCol: HTMLTableColElement;
        const colGroup: Element[] = [].slice.call(ele.querySelector('colgroup').children);
        if (columns[index].freeze === 'Left' && columns[index].isFrozen) {
            headerCol = colGroup[index] as HTMLTableColElement;
        }
        else if (columns[index].freeze === 'Right' && columns[index].isFrozen) {
            headerCol = colGroup[index - (left + movable)] as HTMLTableColElement;
        }
        else {
            headerCol = colGroup[index - left] as HTMLTableColElement;
        }
        return headerCol;
    };

    public isWidthUndefined(): boolean {
        let isWidUndefCount: number = this.parent.getColumns().filter((col: Column) => {
            return isNullOrUndefined(col.width) && isNullOrUndefined(col.minWidth);
        }).length;
        return (this.parent.getColumns().length === isWidUndefCount);
    }

    public getWidth(column: Column): string | number {

        //TODO: move it to c# side

        // if (isNullOrUndefined(column.width) && this.parent.options.allowResizing
        //     && isNullOrUndefined(column.minWidth) && !this.isWidthUndefined()) {
        //     column.width = 200;
        // }
        // if (this.parent.options.frozenColumns && isNullOrUndefined(column.width) &&
        //     column.index < this.parent.options.frozenColumns) {
        //     column.width = 200;
        // }
        if (!column.width) { return null; }
        let width: number = parseInt(column.width.toString(), 10);
        if (column.minWidth && width < parseInt(column.minWidth.toString(), 10)) {
            return column.minWidth;
        } else if ((column.maxWidth && width > parseInt(column.maxWidth.toString(), 10))) {
            return column.maxWidth;
        } else {
            return column.width;
        }
    }

    public getTableWidth(columns: Column[]): number {
        let tWidth: number = 0;
        for (let column of columns) {
            let cWidth: string | number = this.getWidth(column);
            if (column.width === 'auto') {
                cWidth = 0;
            }
            if (column.visible !== false && cWidth !== null) {
                tWidth += parseInt(cWidth.toString(), 10);
            }
        }
        return tWidth;
    }

    private calcMovableOrFreezeColWidth(tableType: String): string {
        let columns: Column[] = this.parent.frozenColumnModel.length != 0 ? this.parent.frozenColumnModel.slice() : this.parent.getColumns().slice();
        let frozenColumnsCount: number = 0;
        if (!this.parent.options.frozenLeftColumnsCount && !this.parent.options.frozenRightColumnsCount) {
            for (let i: number = 0; i < columns.length; i++) {
                if (columns[i].index < this.parent.options.actualFrozenColumns && !columns[i].isFrozen) {
                    frozenColumnsCount++;
                }
            }
            this.parent.options.actualFrozenColumns = frozenColumnsCount;
        }
        let left: number = this.parent.options.frozenLeftColumnsCount || this.parent.options.actualFrozenColumns;
        let movable: number = columns.length - this.parent.options.frozenColumns;
        if (tableType === 'movable') {
            if (this.parent.options.frozenRightColumnsCount) {
                columns.splice(left + movable, columns.length);
            }
            if (left) {
                columns.splice(0, left);
            }
        }
        else if (tableType === 'freeze-left') {
            columns.splice(left, columns.length);
        }
        else if (tableType === 'freeze-right') {
            columns.splice(0, left + movable);
        }
        return formatUnit(this.getTableWidth(columns));
    }

    private setWidthToFrozenLeftTable(width?: string): void {
        let freezeWidth: string = isNullOrUndefined(width) ? this.calcMovableOrFreezeColWidth('freeze-left') : width;
        freezeWidth = this.parent.getContent().querySelector('.e-frozen-left-content').classList.contains('e-frozenborderdisabled') ? "0" : freezeWidth;
        (this.parent.getHeaderTable() as HTMLTableElement).style.width = freezeWidth;
        (this.parent.getContentTable() as HTMLTableElement).style.width = freezeWidth;
        this.parent.resizeModule.leftFrozenTableWidth = freezeWidth;
        if (this.parent.getFooterContent() && !isNullOrUndefined(this.parent.getFooterContent().querySelector('.e-frozen-left-footercontent'))) {
            (this.parent.getFooterContent().querySelector('.e-frozen-left-footercontent') as HTMLElement).style.width = freezeWidth;
        }
    }
    
    private setWidthToFrozenRightTable(width?: string): void {
        let freezeWidth: string = isNullOrUndefined(width) ? this.calcMovableOrFreezeColWidth('freeze-right') : width;
        freezeWidth = this.parent.getContent().querySelector('.e-frozen-right-content').classList.contains('e-frozenborderdisabled') ? "0" : freezeWidth;
        if (!this.parent.options.enableColumnVirtualization) {
            (this.parent.getHeaderContent().querySelector('.e-frozen-right-header').querySelector('.e-table') as HTMLTableElement).style.width = freezeWidth;
            (this.parent.getContent().querySelector('.e-frozen-right-content').querySelector('.e-table') as HTMLTableElement).style.width = freezeWidth;
            this.parent.resizeModule.rightFrozenTableWidth = freezeWidth;
            if (this.parent.getFooterContent() && !isNullOrUndefined(this.parent.getFooterContent().querySelector('.e-frozen-right-footercontent'))) {
                (this.parent.getFooterContent().querySelector('.e-frozen-right-footercontent') as HTMLElement).style.width = freezeWidth;
            }
        } 
    }

    private setWidthToMovableTable(width?: string): void {
        let movableWidth: string = '';
        if (isNullOrUndefined(width)) {
            let isColUndefined: boolean = this.parent.getColumns().filter((a: Column) => { return isNullOrUndefined(a.width); }).length >= 1;
            let isWidthAuto: boolean = this.parent.getColumns().filter((a: Column) => { return (a.width === 'auto'); }).length >= 1;
            if (typeof this.parent.options.width === 'number' && !isColUndefined && !isWidthAuto) {
                movableWidth = formatUnit(this.parent.options.width - parseInt(this.calcMovableOrFreezeColWidth('freeze').split('px')[0], 10) - 5);
            } else if (!isColUndefined && !isWidthAuto) {
                movableWidth = this.calcMovableOrFreezeColWidth('movable');
            }
        } else {
            movableWidth = width;
        }
        if (this.parent.getHeaderContent().querySelector('.e-movableheader').firstElementChild &&  !this.parent.options.enableColumnVirtualization) {
            (this.parent.getHeaderContent().querySelector('.e-movableheader').firstElementChild as HTMLTableElement).style.width
                = movableWidth;
        }

        if (this.parent.getFooterContent() && this.parent.getFooterContent().querySelector('.e-movablefootercontent').firstElementChild &&  !this.parent.options.enableColumnVirtualization) {
            (<HTMLElement>this.parent.getFooterContent().querySelector('.e-movablefootercontent').firstElementChild).style.width = movableWidth;
        }
        if (!this.parent.options.enableColumnVirtualization) {
            (this.parent.getContent().querySelector('.e-movablecontent').firstElementChild as HTMLTableElement).style.width =
                movableWidth;
            this.parent.resizeModule.tableWidth = movableWidth;
        }
    }
    private setWidthToFrozenEditTable(): void {
        let freezeWidth: string = this.calcMovableOrFreezeColWidth('freeze');
        (this.parent.element.querySelectorAll('.e-table.e-inline-edit')[0] as HTMLTableElement).style.width = freezeWidth;
    }
    private setWidthToMovableEditTable(): void {
        let movableWidth: string = this.calcMovableOrFreezeColWidth('movable');
        (this.parent.element.querySelectorAll('.e-table.e-inline-edit')[1] as HTMLTableElement).style.width = movableWidth;
    }

    public setPersistedWidth(column: Column): void {
        if (this.parent.options.frozenColumns) {
            if (this.parent.options.frozenRightColumnsCount != 0 || this.parent.options.frozenLeftColumnsCount != 0) {
                if (this.parent.options.frozenLeftColumnsCount != 0) {
                    this.setWidthToFrozenLeftTable(column.leftFrozenTableWidth);
                }
                if (this.parent.options.frozenRightColumnsCount != 0) {
                    this.setWidthToFrozenRightTable(column.rightFrozenTableWidth);
                }
                this.setWidthToMovableTable(column.tableWidth);
            } else {
                this.setWidthToFrozenLeftTable(column.leftFrozenTableWidth);
                this.setWidthToMovableTable(column.tableWidth);
            }
        } else {
            (this.parent.getHeaderTable() as HTMLTableElement).style.width = column.tableWidth;
            (this.parent.getContentTable() as HTMLTableElement).style.width = column.tableWidth;
            if (this.parent.options.aggregatesCount != 0) {
                (this.parent.getFooterContent().querySelector(".e-table") as HTMLTableElement).style.width = column.tableWidth;
            }
        }
    }
    public setWidthToTable(columns: Column[] = null, tableWidth: boolean = false, module: string = ''): void {
        let tWidth: string;
        if (this.parent.options.enableColumnVirtualization && module === 'resize') {
            tWidth = formatUnit(this.getTableWidth(this.parent.options.virtualizedColumns));
        } else {
            tWidth = formatUnit(this.getTableWidth(columns != null? columns: <Column[]>this.parent.getColumns()));
        }
        let autoFitColumns: Column[];
        autoFitColumns = this.parent.getColumns().filter((c: Column) => c.autoFit === true);
        if(!this.parent.options.frozenColumns || (this.parent.options.frozenColumns && autoFitColumns.length > 0) || (this.parent.options.frozenColumns && this.parent.options.enableColumnVirtualization && module === 'resize')){
            if (this.parent.options.hasDetailTemplate) {
                this.setWidth('30', 0);
            }
            if (tableWidth) {
                tWidth = "";
            }
            this.parent.resizeModule.tableWidth = tWidth;
            (this.parent.getHeaderTable() as HTMLTableElement).style.width = tWidth;
            (this.parent.getContentTable() as HTMLTableElement).style.width = tWidth;
            if (this.parent.options.aggregatesCount != 0 && !isNullOrUndefined((this.parent.getFooterContent().querySelector(".e-table") as HTMLTableElement))) {
                (this.parent.getFooterContent().querySelector(".e-table") as HTMLTableElement).style.width = tWidth;
            }   
        }
        let edit: HTMLTableElement = <HTMLTableElement>this.parent.element.querySelector('.e-table.e-inline-edit');
        if (edit && this.parent.options.frozenColumns) {
            this.setWidthToFrozenEditTable();
            this.setWidthToMovableEditTable();
        } else if (edit) {
            edit.style.width = tWidth;
        }
    }
}
