import { Browser, EventHandler } from '@syncfusion/ej2-base';
import { addClass, removeClass } from '@syncfusion/ej2-base';
import { formatUnit, isNullOrUndefined } from '@syncfusion/ej2-base';
import { getScrollBarWidth, getUpdateUsingRaf, getSiblingsHeight } from './util';
import { SfGrid } from './sf-grid-fn';
import { calculateRelativeBasedPosition } from '@syncfusion/ej2-popups';
import { Column } from './interfaces';

/**
 * The `Scroll` module is used to handle scrolling behaviour.
 */
export class Scroll {
    private parent: SfGrid;
    //To maintain scroll state on grid actions.
    private previousValues: { top: number, left: number } = { top: 0, left: 0 };
    private oneTimeReady: boolean = true;
    private content: HTMLDivElement;
    private header: HTMLDivElement;
    private pageXY: { x: number, y: number };
    private gridParentElement: HTMLElement;
    public infiniteScrollTop: number = 0;
    private infiniteDataRequested: boolean = false;
    public infiniteScollDirection: string = '';
    public maxPage: number = 0;
    public infiniteInitialRender : boolean = true;
    private rowElements: Element[] = [];
    public isLazyChildLoad: boolean = false;
    private currentRowIndex: number = 0;

    /**
     * Constructor for the Grid scrolling.
     * @hidden
     */
    constructor(parent?: SfGrid) {
        this.parent = parent;
        this.addEventListener();
        this.setHeight();
        this.setPadding();
    }

    /**
     * @hidden
     */
    public setHeight(): void {
        let mHdrHeight: number = 0;
        let content: HTMLElement = (<HTMLElement>this.parent.element.querySelector('.e-content'));
        if (this.parent.options.frozenRows && this.parent.options.height !== 'auto' && !this.parent.options.height.match(/%/g)) {
            let tbody: HTMLElement = (this.parent.element.querySelector('.e-headercontent').querySelector('tbody') as HTMLElement);
            mHdrHeight = tbody ? tbody.offsetHeight : 0;
            content.style.height = formatUnit((parseInt(this.parent.options.height) - mHdrHeight));
        }
    }
    /**
     * @hidden
     */
    
    public removeUnwantedScroll(offsetValue: string, minWidth: number = 0): boolean {
        let isFrozenColumn: boolean = false;
        let isFrozenRowWidth: boolean = this.parent.content.offsetWidth >= (this.parent.getContentTable() as HTMLElement).offsetWidth;
        let isFrozenRow: boolean = this.parent.options.frozenRows != 0 && this.parent.options.frozenColumns == 0;
        const movablescrollbarDiv : HTMLElement = this.parent.element.querySelector('.e-movablescrollbar');
        let movableScrollbarHeight: number = movablescrollbarDiv ? movablescrollbarDiv.offsetHeight : 0;
        if (this.parent.options.frozenColumns != 0 && !isNullOrUndefined(this.getMovableContent())) {
            isFrozenColumn = this.getMovableContent().offsetWidth >= ((this.getMovableContentTable().offsetWidth + minWidth) - 2) || this.getMovableContent().offsetWidth == 0;
        }
        let isHorizontalScrollBarRendered: boolean = this.parent.content.scrollWidth > this.parent.content.offsetWidth;
        let actualScrollHeight: number = (isHorizontalScrollBarRendered ? this.parent.content.scrollHeight + 17 : this.parent.content.scrollHeight);
        if (offsetValue === "Height" && this.parent.content.offsetHeight >= actualScrollHeight) {
            return true;
        }
        if (offsetValue === "Width" && (isFrozenColumn || (isFrozenRow && isFrozenRowWidth))) {
            if (this.parent.options.height == "100%") {
                this.frozenContentElement().style.borderBottom = "none";
            }
            return true;
        }
        return false;
    }
    /**
     * @hidden
     */

    public getMovableContent(): HTMLElement {
        return this.parent.element.querySelector(".e-movablecontent");
    }
    /**
     * @hidden
     */

    public getMovableContentTable(): HTMLElement {
        return this.parent.element.querySelector(".e-movablecontent .e-table");
    }
    /**
     * @hidden
     */

    public frozenContentElement(): HTMLElement {
        return this.parent.element.querySelector(".e-frozencontent");
    }
    /**
     * @hidden
     */
    public getScrollbar(): HTMLElement {
        return this.parent.element.querySelector(".e-scrollbar");
    }
    /**
     * @hidden
     */

    public setPadding(): void {
        let content: HTMLElement = <HTMLElement>this.parent.element.querySelector('.e-gridheader');
        if (isNullOrUndefined(content)) { return; }
        if (this.parent.options.height == "auto"  && this.parent.options.frozenName == "None" &&
            this.parent.options.frozenColumns == 0) { return; }
        if (this.removeUnwantedScroll("Height")) {
            this.content.style.overflow = this.parent.options.frozenColumns && this.parent.options.enableColumnVirtualization ? 'hidden auto' : 'auto';
            (<HTMLElement>content.querySelector('.e-headercontent')).style.borderRightWidth = '';
            content.style.paddingRight = "";
            return;
        }
        let scrollWidth: number = Scroll.getScrollBarWidth() - this.getThreshold();
        let cssProps: ScrollCss = this.getCssProperties();
        if(this.parent.options.enableRtl)
        {
            content.style['padding-right'] = '';
        }
        else{
            content.style['padding-left'] = '';
        }
        const contentElement = this.parent.element.querySelector('.e-content') as HTMLElement;
        if (!this.parent.options.enableVirtualization && contentElement.style.overflowY == 'auto' && this.parent.options.frozenColumns > 0 && this.parent.options.height == "auto") {
            scrollWidth = 0;
        }
        content.style[cssProps.padding] = scrollWidth > 0 ? scrollWidth + 'px' : '0px';
        (<HTMLElement>content.querySelector('.e-headercontent')).style[cssProps.border] = scrollWidth > 0 ? '1px' : '0px';
        let footer: HTMLElement = this.parent.element.querySelector('.e-gridfooter');
        if (footer) {
            let footerContent: HTMLElement = footer.querySelector('.e-summarycontent');
            if(!this.parent.options.enableAdaptiveUI){
                footerContent.style[cssProps.border] = scrollWidth > 0 ? '1px' : '0px'; 
            }
            footer.style[cssProps.padding] = scrollWidth > 0 ? scrollWidth + 'px' : '0px';
        }
    }
    /**
     * @hidden
     */
    public removePadding(rtl?: boolean): void {
        let cssProps: ScrollCss = this.getCssProperties(rtl);
        let hDiv: HTMLDivElement = (<HTMLDivElement>this.parent.getHeaderContent());
        hDiv.style[cssProps.border] = '';
        hDiv.parentElement.style[cssProps.padding] = '';
        let footerDiv: HTMLDivElement = (<HTMLDivElement>this.parent.getFooterContent());
    }
    /**
     * Refresh makes the Grid adoptable with the height of parent container.
     *  
     * > The [`height`](grid/#height/) must be set to 100%. 
     * @return
     */
    public refresh(): void {
        if (this.parent.options.height !== '100%') {
            return;
        }

        let content: HTMLElement = <HTMLElement>this.parent.element.querySelector(".e-gridcontent");
        let height: number = getSiblingsHeight(content);
        content.style.height = 'calc(100% - ' + height + 'px)'; //Set the height to the '.e-gridcontent';
    }

    public getThreshold(): number {
        /* Some browsers places the scroller outside the content, 
         * hence the padding should be adjusted.*/
        let appName: string = Browser.info.name;
        if (appName === 'mozilla') {
            return 0.5;
        }
        return 1;
    }
    /**
     * @hidden
     */
    public addEventListener(): void {
        this.wireEvents();
        // this.parent.on(onEmpty, this.wireEvents, this);
        // this.parent.on(contentReady, this.wireEvents, this);
        // this.parent.on(uiUpdate, this.onPropertyChanged, this);
        // this.parent.on(textWrapRefresh, this.wireEvents, this);
        // this.parent.on(headerRefreshed, this.setScrollLeft, this);
    }

    // private setScrollLeft(): void {
    //     if (this.parent.options.frozenColumns) {
    //         (<HTMLElement>(<SfGrid>this.parent).headerModule.getMovableHeader()).scrollLeft = this.previousValues.left;
    //     }
    // }

    private onContentScroll(scrollTarget: HTMLElement): Function {
        let element: HTMLElement = scrollTarget;
        let isHeader: boolean = element.classList.contains('e-headercontent');
        return (e: Event) => {
            if (this.content.querySelector('tbody') === null || this.parent.options.isPreventScrollEvent) {
                return;
            }

            let target: HTMLElement = (<HTMLElement>e.target);
            let left: number = target.scrollLeft;
            let sLimit: number = target.scrollWidth;
            this.updateFrozenShadow(target);
            let frozenRightColumns: Column[] = this.parent.getColumns().filter((a: Column) => {
                return a.isFrozen && a.freeze === "Right";
            });
            if (this.content.scrollTop > 0 && this.parent.options.frozenRows) {
                this.parent.element.classList.add('e-top-shadow');
            } else {
                this.parent.element.classList.remove('e-top-shadow');
            }
            let widthVal = Math.round((target.scrollWidth - target.scrollLeft));
            if (widthVal === target.offsetWidth && frozenRightColumns.length > 0) {
                this.parent.element.classList.remove('e-right-shadow');
            } else {
                this.parent.element.classList.add('e-right-shadow');
            }
            let isFooter: boolean = target.classList.contains('e-summarycontent');

            if(this.parent.options.enableInfiniteScrolling && !this.parent.options.isEdit){
                if(!this.isLazyChildLoad){
                    this.infiniteScrollHandler(target);
                }  
            }
            if(this.parent.options.groupCount > 0 && this.parent.options.enableLazyLoading){
                let isDown: boolean = this.previousValues.top < target.scrollTop;
                this.lazyLoadInfiniteScrollHandler(target, isDown);
            }
            if (this.previousValues.left === left) {
                this.previousValues.top = !isHeader ? this.previousValues.top : target.scrollTop;
                return;
            }

            element.scrollLeft = left;
            let footer: HTMLElement = this.parent.element.querySelector('.e-summarycontent');
            if (footer) {
                footer.scrollLeft = left;
            }
            if (isFooter) { this.header.scrollLeft = left; }
            this.previousValues.left = left;
        };
    }

    private onFreezeContentScroll(scrollTarget: HTMLElement): Function {
        let element: HTMLElement = scrollTarget;
        return (e: Event) => {
            if (this.content.querySelector('tbody') === null) {
                return;
            }
            let target: HTMLElement = <HTMLElement>e.target;
            let top: number = target.scrollTop;
            if (this.previousValues.top === top) {
                return;
            }
            element.scrollTop = top;
            this.previousValues.top = top;
        };
    }
    private updateFrozenShadow(target: HTMLElement): void {
        let frozenLeftColumns: Column[] = this.parent.getColumns().filter((a: Column) => {
            return a.isFrozen && a.freeze === "Left";
        });
        let frozenRightColumns: Column[] = this.parent.getColumns().filter((a: Column) => {
            return a.isFrozen && a.freeze === "Right";
        });
        if (target.scrollLeft !== 0 && ((this.parent.options.frozenColumns > 0 && frozenRightColumns.length == 0) || frozenLeftColumns.length > 0)) {
            this.parent.element.classList.add('e-left-shadow');
        } else if (this.parent.element.classList.contains('e-left-shadow')) {
            this.parent.element.classList.remove('e-left-shadow');
        }
    }
    private onCustomScrollbar(mCont: HTMLElement, mHdr: HTMLElement): Function {
        let content: HTMLElement = mCont;
        let header: HTMLElement = mHdr;
        let mfooter: HTMLElement;
        return (e: Event) => {
            if (this.content.querySelector('tbody') === null) {
                return;
            }

            let target: HTMLElement = <HTMLElement>e.target;
            let left: number = target.scrollLeft;
            if (this.previousValues.left === left) {
                return;
            }
            this.updateFrozenShadow(target);
            if (this.parent.options.aggregatesCount) {
                mfooter = this.parent.element.querySelector('.e-movablefootercontent');
            }
            content.scrollLeft = left;
            header.scrollLeft = left;
            if (mfooter) {
                mfooter.scrollLeft = left;
            }
            this.previousValues.left = left;

        };
    }
    private onWheelScroll(scrollTarget: HTMLElement): Function {
        let element: HTMLElement = scrollTarget;
        return (e: WheelEvent) => {
            if (this.content.querySelector('tbody') === null) {
                return;
            }
            let top: number = element.scrollTop + (e.deltaMode === 1 ? e.deltaY * 30 : e.deltaY);
            if (this.previousValues.top === top) {
                return;
            }
            e.preventDefault();
            this.parent.getContent().querySelector('.e-frozencontent').scrollTop = top;
            element.scrollTop = top;
            this.previousValues.top = top;
        };
    }

    private onTouchScroll(scrollTarget: HTMLElement): Function {
        let element: HTMLElement = scrollTarget;
        return (e: PointerEvent | TouchEvent) => {
            if ((e as PointerEvent).pointerType === 'mouse') {
                return;
            }
            let isFrozen: boolean = this.parent.options.frozenColumns > 0;
            let pageXY: { x: number, y: number } = this.getPointXY(e);
            const left: number = element.scrollLeft + (this.pageXY.x - pageXY.x);
            const mHdr: Element = isFrozen ?
                this.parent.getHeaderContent() :
                this.parent.getHeaderContent().querySelector('.e-headercontent') as Element;
            const mCont: Element = isFrozen ?
                this.parent.getContent() :
                this.parent.getContent().querySelector('.e-content') as Element;
            if (this.previousValues.left === left || (left < 0 || (mHdr.scrollWidth - mHdr.clientWidth) < left)) {
                return;
            }
            if ((event as Event).cancelable) {
                e.preventDefault();
            }
            mHdr.scrollLeft = left;
            mCont.scrollLeft = left;
            if (isFrozen) {
                const scrollBar: HTMLElement = this.parent.element.querySelector('.e-movablescrollbar');
                scrollBar.scrollLeft = left;
            }
            this.pageXY.x = pageXY.x;
            this.previousValues.left = left;
            // let cont: Element;
            // let mHdr: Element;
            // let pageXY: { x: number, y: number } = this.getPointXY(e);
            // let top: number = element.scrollTop + (this.pageXY.y - pageXY.y);
            // let left: number = element.scrollLeft + (this.pageXY.x - pageXY.x);
            // if (this.parent.getHeaderContent().contains(e.target as Element)) {
            //     mHdr = this.parent.options.frozenColumns ?
            //         this.parent.getHeaderContent().querySelector('.e-movableheader') :
            //         this.parent.getHeaderContent().querySelector('.e-headercontent') as Element;
            //     if (this.previousValues.left === left || (left < 0 || (mHdr.scrollWidth - mHdr.clientWidth) < left)) {
            //         return;
            //     }
            //     e.preventDefault();
            //     mHdr.scrollLeft = left;
            //     element.scrollLeft = left;
            //     this.pageXY.x = pageXY.x;
            //     this.previousValues.left = left;
            // } else {
            //     cont = this.parent.getContent().querySelector('.e-frozencontent');
            //     if (this.previousValues.top === top && (top < 0 || (cont.scrollHeight - cont.clientHeight) < top)
            //         || (top < 0 || (cont.scrollHeight - cont.clientHeight) < top)) {
            //         return;
            //     }
            //     e.preventDefault();
            //     cont.scrollTop = top;
            //     element.scrollTop = top;
            //     this.pageXY.y = pageXY.y;
            //     this.previousValues.top = top;
            // }
        };
    }

    private setPageXY(): Function {
        return (e: PointerEvent | TouchEvent) => {
            if ((e as PointerEvent).pointerType === 'mouse') {
                return;
            }
            this.pageXY = this.getPointXY(e);
        };
    }

    private getPointXY(e: PointerEvent | TouchEvent): { x: number, y: number } {
        let pageXY: { x: number, y: number } = { x: 0, y: 0 };
        if ((e as TouchEvent).touches && (e as TouchEvent).touches.length) {
            pageXY.x = (e as TouchEvent).touches[0].pageX;
            pageXY.y = (e as TouchEvent).touches[0].pageY;
        } else {
            pageXY.x = (e as PointerEvent).pageX;
            pageXY.y = (e as PointerEvent).pageY;
        }
        return pageXY;
    }

    private wireEvents(): void {
        if (this.oneTimeReady) {
            this.content = <HTMLDivElement>this.parent.getContent();
            this.header = <HTMLDivElement>this.parent.getHeaderContent();
            let mScrollBar: HTMLElement = this.content.parentElement.querySelector('.e-movablescrollbar') as HTMLElement;
            //Need for custom scrollbar
            if (this.parent.options.frozenColumns > 0 && this.parent.options.enableColumnVirtualization) {
                EventHandler.add(mScrollBar, 'scroll', this.onCustomScrollbar(this.content, this.header), this);
                EventHandler.add(this.content, 'scroll', this.onCustomScrollbar(mScrollBar, this.header), this);
                EventHandler.add(this.header, 'scroll', this.onCustomScrollbar(mScrollBar, this.content), this);
                EventHandler.add(this.header, 'touchstart pointerdown', this.setPageXY(), this);
                EventHandler.add(this.content, 'touchstart pointerdown', this.setPageXY(), this);
                EventHandler.add(this.content, 'touchmove pointermove', this.onTouchScroll(this.header), this);
            }
            else {
                EventHandler.add(this.content, 'scroll', this.onContentScroll(this.header), this);
                EventHandler.add(this.header, 'scroll', this.onContentScroll(this.content), this);
            }
            if (this.parent.options.aggregatesCount) {
                let footer: HTMLElement = this.parent.element.querySelector('.e-summarycontent');
                if (!isNullOrUndefined(footer)) {
                    EventHandler.add(footer, 'scroll', this.onContentScroll(this.content), this);
                }
            }
            if (this.parent.options.enableStickyHeader) {
                this.addStickyListener(true);
            }
            this.refresh();
            this.oneTimeReady = false;
        }
        let table: Element = this.parent.getContent().querySelector(".e-table");
        let sLeft: number;
        let sHeight: number;
        let clientHeight: number;
        getUpdateUsingRaf(
            () => {
                sLeft = this.header.scrollLeft;
                sHeight = table.scrollHeight;
                clientHeight = this.parent.getContent().clientHeight;
            },
            () => {
                if (!this.parent.options.enableVirtualization) {
                    if (sHeight < clientHeight) {
                        addClass(table.querySelectorAll('tr:last-child td'), 'e-lastrowcell');
                    }
                    this.header.scrollLeft = this.previousValues.left;
                    this.content.scrollLeft = this.previousValues.left;
                    this.content.scrollTop = this.previousValues.top;
                }
                if (!this.parent.options.enableColumnVirtualization) {
                    this.content.scrollLeft = sLeft;
                }
                if (this.parent.options.frozenColumns && this.parent.getHeaderContent()) {
                    this.parent.getHeaderContent().scrollLeft = this.parent.getContent().scrollLeft;
                }
            },
        );
    }

    /** 
     * @hidden
     */
    public getCssProperties(rtl?: boolean): ScrollCss {
        let css: ScrollCss = {};
        let enableRtl: boolean = isNullOrUndefined(rtl) ? this.parent.options.enableRtl : rtl;
        css.border = enableRtl ? 'borderLeftWidth' : 'borderRightWidth';
        css.padding = enableRtl ? 'paddingLeft' : 'paddingRight';
        return css;
    }

    /**
     * @hidden
     */
    private getScrollableParent(gridParentNode: HTMLElement): HTMLElement {
        if (gridParentNode === null){
            return null;
        }
        const gridParent = isNullOrUndefined(gridParentNode.tagName) ? (gridParentNode as any).scrollingElement : gridParentNode;
        const overflowY = document.defaultView.getComputedStyle(gridParent, null).overflowY;
        if(gridParent.scrollHeight > gridParent.clientHeight && overflowY !== 'hidden' && overflowY !== 'visible' || gridParentNode.tagName === 'HTML' || gridParentNode.tagName === 'ARTICLE'){
            return gridParentNode;
        }
        else{
            return this.getScrollableParent(gridParentNode.parentNode as HTMLElement);
        }
    }

    public addStickyListener(isAdd: boolean): void{
        this.gridParentElement = this.getScrollableParent(this.parent.element.parentElement);
        if(isAdd){
            if(this.gridParentElement){
                EventHandler.add(this.gridParentElement.tagName === 'HTML' || this.gridParentElement.tagName === 'ARTICLE' ? document :
                this.gridParentElement, 'scroll', this.makeStickyHeader, this);
            }
            else{
                EventHandler.remove(this.gridParentElement, 'scroll', this.makeStickyHeader);
            }
        }
    }

    private makeStickyHeader(): void{
        if(this.parent.options.enableStickyHeader && this.parent.element && !isNullOrUndefined(this.gridParentElement) && this.parent.getContent()){
            const contentRect = this.parent.getContent().parentElement.getBoundingClientRect();
            if (contentRect){
                const headerElement: HTMLElement = this.parent.getHeaderContent().parentElement as HTMLElement;
                const toolbarElement: HTMLElement = this.parent.element.querySelector('.e-toolbar') as HTMLElement;
                const groupElement: HTMLElement = this.parent.element.querySelector('.e-groupdroparea') as HTMLElement;
                const ccElement: HTMLElement = this.parent.element.querySelector('.e-ccdlg') as HTMLElement;
                const ccToolbar: HTMLElement = this.parent.element.querySelector('.e-cc-toolbar') as HTMLElement;
                const height: number = headerElement.offsetHeight + (toolbarElement ? toolbarElement.offsetHeight : 0) + (groupElement ? groupElement.offsetHeight : 0);
                const parentTop: number = this.gridParentElement.getBoundingClientRect().top;
                const top_1: number = contentRect.top - (parentTop < 0 ? 0 : parentTop);
                const left: number = contentRect.left;
                if (top_1 < height && contentRect.bottom > 0){
                    headerElement.classList.add('e-sticky');
                    let elemTop: number = 0;
                    if(groupElement){
                        this.setSticky(groupElement, elemTop, contentRect.width, left, true);
                        elemTop += groupElement.getBoundingClientRect().height - 2;
                    }
                    if(toolbarElement){
                        this.setSticky(toolbarElement, elemTop, contentRect.width, left, true);
                        elemTop += toolbarElement.getBoundingClientRect().height - 2;
                    }
                    this.setSticky(headerElement, elemTop, contentRect.width, left, true);
                }
                else{
                    if(headerElement.classList.contains('e-sticky')){
                        this.setSticky(headerElement, null, null, null, false);
                    }
                    if(groupElement){
                        this.setSticky(groupElement, null, null, null, false);
                    }
                    if(toolbarElement){
                        this.setSticky(toolbarElement, null, null, null, false);
                    }
                    if(ccElement){
                        let position = calculateRelativeBasedPosition(ccToolbar, ccElement);
                        let ccTop : number = position.top + ccToolbar.getBoundingClientRect().height;
                        let elementVisible: string = ccElement.style.display;
                        ccElement.style.display = 'block';
                        const ccRect = ccElement.getBoundingClientRect();
                        let left: number = ccToolbar.getBoundingClientRect().left - contentRect.left - ccRect.width + ccToolbar.clientWidth + 2;
                        ccElement.style.display = elementVisible;
                        this.setSticky(ccElement, ccTop, ccRect.width, left, false);
                    }
                }
            }
        }
    }

    private setSticky(element: HTMLElement, top? : number, width? : number, left?: number, isAdd?: boolean): void{
        if(isAdd){
            element.classList.add('e-sticky');
        }
        else{
            element.classList.remove('e-sticky');
        }
        element.style.width = width != null ? width + 'px' : '';
        element.style.top = top != null ? top - 2 + 'px' : '';
        element.style.left = left !== null ? parseInt(element.style.left, 10) !== left ? left + 'px' : element.style.left : '';
    }

    private infiniteScrollHandler(scrollElement: HTMLElement): void { //scroll data request for infinite scrolling
        const _this: Scroll = this;
        let isLeftRightScroll : boolean = scrollElement.scrollLeft !== this.previousValues.left;
        let infiniteContent: boolean = scrollElement.classList.contains('e-content');
        let delay : number = Browser.info.name === 'chrome' ? 200 : 100;
        if (infiniteContent && !isLeftRightScroll) {
            let offset: number = scrollElement.scrollHeight - scrollElement.scrollTop;
            let offsetRound: number = Math.round(offset);
            let offsetFloor: number = offset < scrollElement.clientHeight ? Math.ceil(offset) : Math.floor(offset);
            this.rowElements = this.parent.getDataRows();
            if(offsetFloor > scrollElement.clientHeight){
                offsetFloor = offsetFloor - 1;
            }
            let isBottom: boolean = offsetFloor === scrollElement.clientHeight || offsetRound === scrollElement.clientHeight;
            let groupCurrentPage: boolean = this.parent.options.allowGrouping && !this.parent.options.enableLazyLoading && this.parent.options.groupCount > 0 && this.parent.options.currentPage >= 1 && !this.infiniteInitialRender;
            if(isBottom && !this.infiniteDataRequested && !this.infiniteInitialRender && ((this.parent.options.currentPage <= this.maxPage - 1) || (this.parent.options.totalItemCount != this.rowElements.length && !this.infiniteInitialRender && !this.parent.options.infiniteCacheMode))){
                setTimeout(function(){ 
                    _this.parent.dotNetRef.invokeMethodAsync("LoadInfiniteData", {
                    requestType: 'InfiniteScrolling',
                }, isBottom, false, false, null, null, 0);
            }, delay);
                this.infiniteScrollTop = this.calculateScrollPosition("down");
                this.infiniteScollDirection = "down";
                this.infiniteDataRequested = true;
            }
            
            else if(scrollElement.scrollTop === 0 && ((this.parent.options.currentPage !== 1 && this.parent.options.currentPage > 1) || groupCurrentPage) && this.parent.options.infiniteCacheMode){
                setTimeout(function(){
                    _this.parent.dotNetRef.invokeMethodAsync("LoadInfiniteData", {
                        requestType: 'InfiniteScrolling',
                    }, isBottom, true, false, null, null, 0);
                }, delay);
                this.infiniteScrollTop = this.calculateScrollPosition("up");
                this.infiniteScollDirection = "up";
            }
            this.infiniteInitialRender = false;
        }
    }

    private lazyLoadInfiniteScrollHandler(scrollElement: HTMLElement, scrollDown: boolean): void{
        const _this: Scroll = this;
        let downTrs = [].slice.call(this.parent.getContent().getElementsByClassName('e-lazyload-middle-down'));
        let endTrs = [].slice.call(this.parent.getContent().getElementsByClassName('e-lazyload-last-down'));
        let lazyLoadDown: boolean = false;
        let lazyLoadEnd: boolean = false;
        let middleRowIndex: number = 0;
        let endRowIndex: number = 0;
        let tr: HTMLElement;
        let middleTr: HTMLElement;
        let endTr: HTMLElement;
        let prevRowIndex: number = this.currentRowIndex;
        let delay : number = Browser.info.name === 'chrome' ? 200 : 100;
        if(scrollDown && downTrs.length > 0){
            const result: { rowEntered: boolean, rowIndex: number, row: HTMLElement } = this.findRowElementsInGrid(downTrs);
            lazyLoadDown = result.rowEntered;
            middleRowIndex = result.rowIndex;
            tr = middleTr = result.row;
            if(lazyLoadDown){
                this.currentRowIndex = middleRowIndex;
            }
        }
        if(!scrollDown && endTrs.length > 0){
            for(var i = 0; i < endTrs.length; i++){
                let top: number = endTrs[parseInt(i.toString(), 10)].getBoundingClientRect().top;
                let endRowIndex: number = endTrs[i].rowIndex;
                let scrollHeight: number = this.parent.getContent().parentElement.scrollHeight;
                this.isLazyChildLoad = false;
                if(top > 0 && top < scrollHeight){
                    tr = endTr = endTrs[parseInt(i.toString(), 10)];
                    lazyLoadEnd = true;
                    endRowIndex = (tr as HTMLTableRowElement).rowIndex;
                    if(lazyLoadEnd){
                        this.currentRowIndex = endRowIndex;
                    }
                    break;
                }
            }
        }
        if(((scrollDown && lazyLoadDown) || (!scrollDown && lazyLoadEnd)) && this.currentRowIndex != prevRowIndex && !this.isLazyChildLoad){
            let middleTrUid: string = !isNullOrUndefined(middleTr) ? middleTr.getAttribute('data-uid') : null;
            let endTrUid: string = !isNullOrUndefined(endTr) ? endTr.getAttribute('data-uid') : null;
            var childRequest = lazyLoadDown || lazyLoadEnd;
            setTimeout(function (){
                _this.parent.dotNetRef.invokeMethodAsync("LoadInfiniteData",{
                    requestType: 'InfiniteScrolling',
                }, false, false, childRequest, middleTrUid, endTrUid, middleRowIndex);
            }, delay);
            this.isLazyChildLoad = true;
        }
    }

    private findRowElementsInGrid(rows: HTMLElement[]): any{
       let rowEntered: boolean = false;
       let row: HTMLElement;
       let rowIndex: number = 0;
       for(var i = 0; i < rows.length; i++){
        rowIndex = (rows[parseInt(i.toString(), 10)] as HTMLTableRowElement).rowIndex;
        if(this.isRowEnteredInGrid(rowIndex)){
            rowEntered = true;
            row = rows[i];
        }
       }
       return {rowEntered, rowIndex, row};
    }

    private isRowEnteredInGrid(index: number): any{
        let startIndex: number = this.parent.getContent().scrollTop / this.parent.getRowHeight();
        let endIndex: number = startIndex + (this.parent.getContent().offsetHeight / this.parent.getRowHeight());
        return index < endIndex && index > startIndex;
    }

    private calculateScrollPosition(direction: string): number{ //scrolltop value updating for infinite scroll
        let scrollTop: number = 0;
        let scrollElement: HTMLDivElement = <HTMLDivElement>this.parent.getContent();
        if(direction === "down"){
            if(this.parent.options.allowGrouping && !isNullOrUndefined(this.parent.options.initGroupingField) && this.parent.options.initGroupingField.length > 0 && !this.parent.options.infiniteCacheMode){
                let groupRowHeight: number = 0;
                let contentTable: HTMLElement = this.parent.getContentTable() as HTMLElement;
                let captionRows = contentTable.querySelectorAll('tr:not(.e-row)');
                groupRowHeight = captionRows.length * this.parent.getRowHeight();
                scrollTop += groupRowHeight;
            }
            else{
                let pageSizeMaxBlock: number = this.parent.options.pageSize * (this.parent.options.infiniteMaxBlocks - 1);
                pageSizeMaxBlock = pageSizeMaxBlock == 0 ? this.parent.options.pageSize : pageSizeMaxBlock;
                let currentViewRowCount: number = 0;
                let i: number = 0;
                while(currentViewRowCount < scrollElement.offsetHeight){
                    i++;
                    currentViewRowCount = i * this.parent.getRowHeight();
                }
                i = i - 1.5;
                scrollTop += (pageSizeMaxBlock - i) * this.parent.getRowHeight();
            }
            
        }
        else if(direction === "up"){
            scrollTop += this.parent.options.pageSize * this.parent.getRowHeight() + getScrollBarWidth() + 10;
        }
        return scrollTop;
    }

    public resetInfniniteScrollPositions(): void{ //Resets the infinite positions for actions
        const _this: Scroll = this;
        let scrollElement: HTMLDivElement = <HTMLDivElement>this.parent.getContent();
        if(this.infiniteInitialRender){
            this.maxPage = Math.ceil(this.parent.options.totalItemCount / this.parent.options.pageSize);
        }
        if (['Refresh', 'Filtering', 'ClearFiltering', 'Sorting', 'sorting' , 'Searching', 'Grouping', 'UnGrouping', 'Reorder',
            'refresh', 'filtering', 'searching', 'grouping', 'ungrouping', 'reorder', "GroupExpandCollapse", null]
            .some((value: string) => { return this.parent.options.requestType === value; })) {
            _this.infiniteInitialRender = true;
            scrollElement.scrollTop = 0;
            _this.infiniteScollDirection = "";
        }
        if(this.parent.options.requestType == "Delete"){
            var reachedBottom = scrollElement.scrollTop + scrollElement.offsetHeight >= scrollElement.scrollHeight;
            this.infiniteInitialRender = reachedBottom ? true : this.infiniteInitialRender;
        }
        if(this.infiniteScollDirection === "down" || this.infiniteScollDirection === "up"){
            this.infiniteDataRequested = false;
            if(((this.parent.options.currentPage <= (this.maxPage - 1)) || scrollElement.scrollTop === 0) && this.parent.options.infiniteCacheMode && this.parent.options.requestType === "InfiniteScrolling"){
                scrollElement.scrollTop = this.infiniteScrollTop;
            }
        }
        if(this.isLazyChildLoad){
            this.isLazyChildLoad = false;
        }
    }

    public infiniteOnDataReady(): void{
        const _this: Scroll = this;
        this.maxPage = Math.ceil(this.parent.options.totalItemCount / this.parent.options.pageSize);
        if(this.parent.options.allowGrouping && !this.parent.options.enableLazyLoading && this.parent.options.groupCount > 0){
            this.maxPage = this.maxPage + 1;
        }
        if (['Refresh', 'Filtering', 'Sorting', 'sorting' , 'Searching', 'Grouping', 'UnGrouping', 'Reorder', 'RowDragAndDrop',
            'refresh', 'filtering', 'searching', 'grouping', 'ungrouping', 'reorder', "GroupExpandCollapse", null]
            .some((value: string) => { return this.parent.options.requestType === value; })) {
                _this.infiniteDataRequested = false;
        }
    }

    public destroy(): void {
        let gridElement: Element = this.parent.element;
        if (!gridElement || (!gridElement.querySelector('.e-gridheader') && !gridElement.querySelector('.e-gridcontent'))) { return; }
        
        if (this.parent.options.enableStickyHeader) {
            this.addStickyListener(false);
        }
        //Remove padding
        this.removePadding();

        //Remove Dom event
        EventHandler.remove(<HTMLDivElement>this.parent.getContent(), 'scroll', this.onContentScroll);
        EventHandler.remove(this.header, 'scroll', this.onContentScroll);
        if (this.parent.options.aggregatesCount) {
            let footer: HTMLElement = this.parent.element.querySelector('.e-summarycontent');
            if (!isNullOrUndefined(footer)) {
                EventHandler.remove(footer, 'scroll', this.onContentScroll);
            }
        }
    }

    /**
     * Function to get the scrollbar width of the browser.
     * @return {number} 
     * @hidden
     */
    public static getScrollBarWidth(): number {
        return getScrollBarWidth();
    }
}

/**
 * @hidden
 */
export interface ScrollCss {
    padding?: string;
    border?: string;
}
