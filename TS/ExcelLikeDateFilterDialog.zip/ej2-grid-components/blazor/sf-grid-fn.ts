import { BlazorDotnetObject, extend, isNullOrUndefined, print } from '@syncfusion/ej2-base';
import { EventHandler, MouseEventArgs, KeyboardEventArgs, KeyboardEvents, closest, Browser } from '@syncfusion/ej2-base';
import { getScrollableParent } from '@syncfusion/ej2-popups';
import { Scroll } from './scroll';
import { Freeze } from './freeze';
import { BlazorGridElement, IGridOptions, Column, ScrollPositionType } from './interfaces';
import { iterateArrayOrObject, parentsUntil, getRowHeight, Global, getScrollBarWidth, getSiblingsHeight } from './util';
import { ColumnWidthService } from './width-controller';
import { HeaderDragDrop } from './header-drag-drop';
import { ContentDragDrop } from './content-drag-drop';
import { Reorder } from './reorder';
import { Resize } from './resize';
import { Group } from './group';
import { ColumnChooser } from './column-chooser';
import { ColumnMenu } from './column-menu';
import { Filter } from './filter';
import { Edit } from './edit';
import { Clipboard } from './clipboard';
import { CustomToolTip } from './tooltip';
import { RowDD } from './row-reorder';
import { Selection } from './selection';
import { VirtualHeaderRenderer, VirtualContentRenderer } from './virtual-scroll';
import { FrozenDD } from './frozen-drag-drop';

/**
 * SfGrid client constructor
 */
export class SfGrid {
    public element: HTMLElement;
    public dotNetRef: BlazorDotnetObject;
    public dataId: string;
    public options: IGridOptions;
    public header: HTMLElement;
    public content: HTMLElement;
    public footer: HTMLElement;
    public columnModel: Column[] = [];
    public frozenColumnModel: Column[] = [];
    public scrollModule: Scroll;
    public freezeModule: Freeze;
    public headerDragDrop: HeaderDragDrop;
    public contentDragDrop: ContentDragDrop;
    public reorderModule: Reorder;
    public groupModule: Group;
    public columnChooserModule: ColumnChooser;
    public columnMenuModule: ColumnMenu;
    public filterModule: Filter;
    public resizeModule: Resize;
    public frozenDragDropModule: FrozenDD;
    public editModule: Edit;
    public clipboardModule : Clipboard;
    public virtualHeaderModule: VirtualHeaderRenderer;
    public virtualContentModule: VirtualContentRenderer;
    public keyModule: KeyboardEvents;
    private toolTipModule: CustomToolTip;
    public rowDragAndDropModule: RowDD;
    public selectionModule : Selection;
    private widthService: ColumnWidthService;
    private sfBlazor: any = (window as any).sfBlazor;
    private editedCellIndex: number = null;

    private firstFocusableTemplateElement: Element = null;
    private lastFocusableTemplateElement: Element = null;
    private stackedColumn: Column;
    private inViewIndexes: number[] = [];
    /** @hidden */
    public scrollPosition: ScrollPositionType;
    private isRendered: boolean = false;
    private isGridFirstRender: boolean = false;
    public nColumnOffsets: number[] = [];

    constructor(dataId: string, element: HTMLElement, options: IGridOptions, dotnetRef: BlazorDotnetObject) {
        this.element = element;
        if (isNullOrUndefined(this.element)) { return; }        
        this.dotNetRef = dotnetRef;
        this.dataId = dataId;
        this.options = options;
        this.header = this.element.querySelector('.e-headercontent');
        this.content = this.element.querySelector('.e-gridcontent .e-content');
        this.footer = this.element.querySelector('.e-summarycontent');
        if (this.element.offsetWidth <= 0) {
            let gridtimer: number = setInterval(() => {
                if (this.element.offsetWidth > 0) {
                    this.initModules();
                    clearInterval(gridtimer);
                }
            }, 500);
        }
        else {
            this.initModules();
        }
        this.addScrollEvents(true);
        if (!isNullOrUndefined(this.element)) {
            (this.element as BlazorGridElement).blazor__instance = this;
            this.sfBlazor.setCompInstance(this);
        }
    }

    public initModules() {
        this.scrollModule = new Scroll(this);
        this.freezeModule = new Freeze(this);
        this.headerDragDrop = new HeaderDragDrop(this);
        this.contentDragDrop =  new ContentDragDrop(this);
        this.reorderModule = new Reorder(this);
        this.groupModule = new Group(this);
        this.resizeModule = new Resize(this);
        this.frozenDragDropModule = new FrozenDD(this);
        this.editModule = new Edit(this);
        this.columnChooserModule = new ColumnChooser(this);
        this.clipboardModule = new Clipboard(this);
        this.columnMenuModule = new ColumnMenu(this);
        this.filterModule = new Filter(this);
        this.virtualContentModule = new VirtualContentRenderer(this);
        this.virtualHeaderModule = new VirtualHeaderRenderer(this);
        this.toolTipModule = new CustomToolTip(this);
        this.rowDragAndDropModule = new RowDD(this);
        this.selectionModule = new Selection(this);
        this.widthService = new ColumnWidthService(this);        
        this.isRendered = this.options.isPrerendered;
        this.keyModule = new KeyboardEvents(
            this.element,
            {
                keyAction: this.keyActionHandler.bind(this),
                keyConfigs: gridKeyConfigs,
                eventName: 'keydown'
            }
            )
        if (this.options.enableColumnVirtualization){
            this.virtualHeaderModule.renderTable();
        }
        if (this.options.enableVirtualization || this.options.enableColumnVirtualization) {
            this.virtualContentModule.renderTable();
        }
        if (this.options.allowResizing){
            this.resizeModule.render();
        }
        if (this.options.isFreezeLineMoved) {
            this.freezeLineMovedAction();
        }

        // needClientAction should only be used for virtual scroll and hideAtMedia features
        if (!this.options.needClientAction) {
            this.contentReady();
        } else {
            this.clientActions();
        }
        this.lastRowBorderCheck();
        this.wireEvents();

        if (!this.options.enableColumnVirtualization) {
            this.updateColumnWidth(this.options.columns);
        }
    }

    public getHeaderContent() { return this.header; }
    public getHeaderTable() { return this.header.querySelector('.e-table'); }
    public getContent() { return this.content; }
    public getContentTable() { return this.content.querySelector('.e-table'); }
    public getFooterContent() { return this.footer; }

    public getColumns(autoFitVirtual: boolean = false, isRefresh?: boolean): Column[] {
        // let inview: number[] = this.inViewIndexes.map((v: number) => v - this.groupSettings.columns.length).filter((v: number) => v > -1);
        // let vLen: number = inview.length;
        // if (!this.enableColumnVirtualization || isNullOrUndefined(this.columnModel) || this.columnModel.length === 0 || isRefresh) {
        //     this.columnModel = [];
        //     this.updateColumnModel(this.columns as Column[]);
        // }
        // let columns: Column[] = vLen === 0 ? this.columnModel :
        //     this.columnModel.slice(inview[0], inview[vLen - 1] + 1);
        this.columnModel = [];
        let columns: Column[] = this.options.enableColumnVirtualization && autoFitVirtual ? this.options.virtualizedColumns as Column[] : this.options.columns as Column[];
        if (autoFitVirtual && this.options.frozenColumns > 0) {
            columns = this.getOrderedFrozenColumns()
            this.columnModel = columns;
        }
        else {
            this.updateColumnModel(columns);
        }
        return this.columnModel;
    }

    public getOrderedFrozenColumns(): Column[] {
        let columns: Column[] = [];
        let gridColumns: Column[] = this.getColumns();
        gridColumns.filter((c: Column) => c.isFrozen && c.freeze === 'Left')
            .map((c: Column) => columns.push(c));
        gridColumns.filter((c: Column) => !c.isFrozen || (c.isFrozen && c.freeze === 'Fixed'))
            .map((c: Column) => columns.push(c));
        gridColumns.filter((c: Column) => c.isFrozen && c.freeze === 'Right')
            .map((c: Column) => columns.push(c));
        return columns;
    }

    public autofitFrozenColumns(autofitAllColumns?: boolean): string[] {
        let columns: string[] = [];
        let gridColumns: Column[] = this.getColumns();
        var left = gridColumns.filter((c: Column) => (autofitAllColumns || c.autoFit) && c.isFrozen && c.freeze === 'Left')
            .map((c: Column) => columns.push(c.field || c.uid));
        var movable = gridColumns.filter((c: Column) => (autofitAllColumns || c.autoFit) && !c.isFrozen)
            .map((c: Column) => columns.push(c.field || c.uid));
        var right = gridColumns.filter((c: Column) => (autofitAllColumns || c.autoFit) && c.isFrozen && c.freeze === 'Right')
            .map((c: Column) => columns.push(c.field || c.uid));
        return columns;
    }

    public freezeLineMovedAction(): void {
        this.options.isFreezeLineMoved = false;        
        let movableContent: HTMLElement = this.getContent().querySelector('.e-movablecontent');
        if (isNullOrUndefined(movableContent)) {
            movableContent = this.getContent();
        }
        if (movableContent.querySelector('table').style.width != '') {
            if (this.options.frozenLeftColumnsCount != 0 || this.options.frozenRightColumnsCount != 0) {
                this.updateColumnLevelFrozen();
            }
            let widthService: ColumnWidthService = new ColumnWidthService(this);
            widthService.setWidthToTable();
        }
        movableContent.scrollLeft = 0;
        if (!isNullOrUndefined(this.element.querySelector('.e-movablescrollbar'))) {
            this.element.querySelector('.e-movablescrollbar').scrollLeft = 0;
        }
        
    }

    private addScrollEvents(add: boolean): void {
        if (this.options.showColumnMenu) {
            let elements: HTMLElement[] = getScrollableParent(this.element);
            for (let i: number = 0; i < elements.length; i++) {
                if (elements[i] instanceof HTMLElement) {
                    add ? EventHandler.add(elements[i], 'scroll', this.scrollHandler, this) :
                        EventHandler.remove(elements[i], 'scroll', this.scrollHandler);
                }
            }
            add ? EventHandler.add(this.content, 'scroll', this.scrollHandler, this) :
            EventHandler.remove(this.content, 'scroll', this.scrollHandler);
        }
    }

    private scrollHandler(e: MouseEvent): void {
        if (!isNullOrUndefined(this.element) && !isNullOrUndefined((this.element as BlazorGridElement).blazor__instance)) {
            return this.columnMenuModule.setPosition();
        }
    }

    public updateColumnLevelFrozen(): void {
        let cols: Column[] = this.columnModel;
        if(this.options.enableColumnVirtualization){
            cols = cols.filter(x => x.visible);
        }
        const leftCols: Column[] = []; const rightCols: Column[] = []; const movableCols: Column[] = [];
        if (this.options.frozenRightCount != 0 || this.options.frozenLeftCount != 0 || this.options.frozenColumns != 0) {
            for (var i = 0, len = cols.length; i < len; i++) {
                var col = cols[i];
                if (col.freeze === 'Left' && col.isFrozen || col.index < this.options.frozenColumns) {
                    leftCols.push(col);
                }
                else if (col.freeze === 'Right' && col.isFrozen) {
                    rightCols.push(col);
                }
                else {
                    movableCols.push(col);
                }
            }
            this.frozenColumnModel = leftCols.concat(movableCols).concat(rightCols);
        }
    };

    private updateColumnModel(columns: Column[]): void {
        if (!isNullOrUndefined(columns)) {
            for (let i: number = 0, len: number = columns.length; i < len; i++) {
                if (columns[i].columns != null && (columns[i].columns as Column[]).length > 0 ) {
                    this.updateColumnModel(columns[i].columns as Column[]);
                } else {
                    this.columnModel.push(columns[i] as Column);
                }
            }
        }
    }
    public updateColumnWidth(columns:Column[]):void{
        this.nColumnOffsets = [];
        let offset:number = 0;
        if(!this.options.enableColumnVirtualization){
            for(var i: number = 0, len:number= columns.length; i < len ;i++){
                offset = parseInt(offset.toString()) + (columns[i].visible? parseInt(<string>columns[i].width):0);
                this.nColumnOffsets.push(offset);
            }
        }     
    }

    public getColumnByIndex(index: number, frozenCols:boolean = false): Column {
        let column: Column;
        this.getColumns(frozenCols).some((col: Column, i: number) => {
            column = col;
            return i === index;
        });
        return column;
    }

    public getDataRows(): Element[] {
        if (isNullOrUndefined(this.getContentTable().querySelector('tbody'))) { return []; }
        let rows: HTMLElement[] = [].slice.call(this.getContentTable().querySelector('tbody').children);
        if (this.options.frozenRows) {
            let freezeRows: HTMLElement[] = [].slice.call(this.getHeaderTable().querySelector('tbody').children);
            rows = this.addMovableRows(freezeRows, rows);
        }
        let dataRows: Element[] = this.generateDataRows(rows);
        return dataRows;
    }

    public addMovableRows(fRows: HTMLElement[], mrows: HTMLElement[]): HTMLElement[] {
        for (let i: number = 0, len: number = mrows.length; i < len; i++) {
            fRows.push(mrows[i]);
        }
        return fRows;
    }

    private generateDataRows(rows: HTMLElement[]): Element[] {
        let dRows: Element[] = [];
        for (let i: number = 0, len: number = rows.length; i < len; i++) {
            if (rows[i].classList.contains('e-row') && !rows[i].classList.contains('e-hiddenrow')) {
                dRows.push(rows[i] as Element);
            }
        }
        return dRows;
    }

    public getMovableDataRows(): Element[] {
        let rows: HTMLElement[] =
            [].slice.call(this.getContent().querySelector('tbody').children);
        if (this.options.frozenRows) {
            let freezeRows: HTMLElement[] =
                [].slice.call(this.getHeaderContent().querySelector('tbody').children);
            rows = this.addMovableRows(freezeRows, rows);
        }
        let dataRows: Element[] = this.generateDataRows(rows);
        return dataRows;
    }

    public getFrozenDataRows(): Element[] {
        let rows: HTMLElement[] =
            [].slice.call(this.getContent().querySelector('.e-frozencontent').querySelector('tbody').children);
        if (this.options.frozenRows) {
            let freezeRows: HTMLElement[] =
                [].slice.call(this.getHeaderContent().querySelector('.e-frozenheader').querySelector('tbody').children);
            rows = this.addMovableRows(freezeRows, rows);
        }
        let dataRows: Element[] = this.generateDataRows(rows);
        return dataRows;
    }

    public leftrightColumnWidth(position?: string): number {
        let cols: Column[] = position === 'left' ? this.getFrozenLeftColumns() : position === 'right' ? this.getFrozenRightColumns() : [];
        let width: number = 0;
        cols.filter((col: Column) => {
            if (col.visible) {
                width += parseInt(col.width.toString(), 10);
            }
        });
        return width;
    }

    public getFrozenLeftColumns = function () {
        let columns: Column[] = [];
        let gridColumns: Column[] = this.getColumns();
        gridColumns.filter((c: Column) => c.isFrozen && c.freeze === 'Left')
            .map((c: Column) => columns.push(c));
        return columns;
    }
    
    public getFrozenRightColumns = function () {
        let columns: Column[] = [];
        let gridColumns: Column[] = this.getColumns();
        gridColumns.filter((c: Column) => c.isFrozen && c.freeze === 'Right')
            .map((c: Column) => columns.push(c));
        return columns;
    }

    public getFrozenRightDataRows(): Element[] {
        let rows: HTMLElement[] =
            [].slice.call(this.getContent().querySelector('.e-frozen-right-content').querySelector('tbody').children);
        if (this.options.frozenRows) {
            let freezeRows: HTMLElement[] =
                [].slice.call(this.getHeaderContent().querySelector('.e-frozenheader').querySelector('tbody').children);
            rows = this.addMovableRows(freezeRows, rows);
        }
        return this.generateDataRows(rows);
    }

    public getRowByIndex(index: number): Element {
        return this.getDataRows()[index];
    }

    public getCellFromIndex(rowIndex: number, columnIndex: number): Element {
        return this.getDataRows()[rowIndex] && this.getDataRows()[rowIndex].querySelectorAll('.e-rowcell')[columnIndex];
    }

    public isMovableGrid(index: number, frozenColumns:boolean): boolean {
        let gridColumns: Column[] = this.getColumns(frozenColumns);
        if (this.options.actualFrozenColumns > 0) {
            return index >= this.options.actualFrozenColumns;
        }
        else{
            let isFrozenColumnsIndexes : number[] = [];
            gridColumns.forEach(col => { if (col.isFrozen) { isFrozenColumnsIndexes.push(col.index); } });
            return isFrozenColumnsIndexes.indexOf(index) == -1;
        }
    }

    public getColumnHeaderByIndex(index: number): Element {
        return this.getHeaderTable().querySelectorAll('.e-headercell')[index];
    }

    public getRows(): Element[] {
        let dataRows : HTMLElement[] = [].slice.call(this.getContentTable().querySelectorAll('tr.e-row[data-uid]'));
        if (this.options.frozenRows) {
            let freezeRows: HTMLElement[] =
                [].slice.call(this.getHeaderContent().querySelectorAll('tr.e-row[data-uid]'));
            dataRows = this.addMovableRows(freezeRows, dataRows);
        }
        return dataRows as Element[];
    }

    public getSelectedRows(): Element[] {
       return this.getRows().filter(row => row.getAttribute('aria-selected') === 'true');
    }

    public getSelectedRowIndexes(isVirtualScroll?: boolean): number[] {
        let selectedIndexes: number[] = [];
        let rows : Element[] = this.getRows();
        for(let i: number = 0; i < rows.length; i++) {
            if (rows[i].hasAttribute('aria-selected') && rows[i].getAttribute('aria-selected') === "true") {
                let rowIndex: number = ((this.options.allowDragSelection && this.options.enableVirtualization) || isVirtualScroll) ? parseInt(rows[i].getAttribute('data-rowindex'), 10) : i;
                selectedIndexes.push(rowIndex);
            }
        }
        return selectedIndexes;
    }

    public getVisibleColumns(): Column[] {
        let cols: Column[] = [];
        for (let col of this.columnModel) {
            if (col.visible) {
                cols.push(col);
            }
        }
        return cols;
    }
    /**
     * Gets a Column by column name.
     * @param  {string} field - Specifies the column name.
     * @return {Column}
     * @blazorType GridColumn
     */
    public getColumnByField(field: string): Column {
        return iterateArrayOrObject<Column, Column>(<Column[]>this.getColumns(), (item: Column, index: number) => {
            if (item.field === field) {
                return item;
            }
            return undefined;
        })[0];
    }

    /**
     * Gets a column index by column name.
     * @param  {string} field - Specifies the column name.
     * @return {number}
     */
    public getColumnIndexByField(field: string, virtualAutoFit: boolean = false): number {
        let cols: Column[] = this.getColumns(virtualAutoFit);
        for (let i: number = 0; i < cols.length; i++) {
            if (cols[i].field === field) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Gets a column by UID.
     * @param  {string} uid - Specifies the column UID.
     * @return {Column}
     * @blazorType GridColumn
     */
    public getColumnByUid(uid: string): Column {
        return iterateArrayOrObject<Column, Column>(
            [...<Column[]>this.getColumns(), ...this.getStackedColumns(this.options.columns as Column[])],
            (item: Column, index: number) => {
                if (item.uid === uid) {
                    return item;
                }
                return undefined;
            })[0];
    }

    /**
     * @hidden   
     */
    public getStackedColumns(columns: Column[], stackedColumn: Column[] = []): Column[] {
        for (const column of columns) {
            if (column.columns) {
                stackedColumn.push(column);
                this.getStackedColumns(column.columns as Column[], stackedColumn);
            }
        }
        return stackedColumn;
    }

    /**
     * Gets a column index by UID.
     * @param  {string} uid - Specifies the column UID.
     * @return {number}
     */
    public getColumnIndexByUid(uid: string, virtualAutoFit: boolean = false): number {
        let index: number = iterateArrayOrObject<number, Column>
            (<Column[]>this.getColumns(virtualAutoFit), (item: Column, index: number) => {
                if (item.uid === uid) {
                    return index;
                }
                return undefined;
            })[0];

        return !isNullOrUndefined(index) ? index : -1;
    }

    /**
     * Gets a column header by UID.
     * @param  {string} field - Specifies the column uid.
     * @return {Element} 
     */
    public getColumnHeaderByUid(uid: string): Element {
        return this.getHeaderContent().querySelector('[e-mappinguid=' + uid + ']').parentElement;
    }

    /**
     * Gets UID by column name.
     * @param  {string} field - Specifies the column name.
     * @return {string}
     */
    public getUidByColumnField(field: string, virtualAutoFit: boolean = false): string {
        return iterateArrayOrObject<string, Column>(<Column[]>this.getColumns(virtualAutoFit), (item: Column, index: number) => {
            if (item.field === field) {
                return item.uid;
            }
            return undefined;
        })[0];
    }

    public getStackedHeaderColumnByHeaderText(stackedHeader: string, col: Column[]): Column {
        for (let i: number = 0; i < col.length; i++) {
            let individualColumn: Column = col[i];
            if (individualColumn.field === stackedHeader || individualColumn.headerText === stackedHeader) {
                this.stackedColumn = individualColumn;
                break;
            } else if (individualColumn.columns) {
                this.getStackedHeaderColumnByHeaderText(stackedHeader, <Column[]>individualColumn.columns);
            }
        }
        return this.stackedColumn;
    }

        /**
     * Gets TH index by column uid value.
     * @private
     * @param  {string} uid - Specifies the column uid.
     * @return {number}
     */
    public getNormalizedColumnIndex(uid: string, virtualAutoFit : boolean = false): number {
        let index: number = this.getColumnIndexByUid(uid, virtualAutoFit);        
        return index + this.getIndentCount();
    }

     /**
     * Gets indent cell count.
     * @private
     * @return {number}
     */
    public getIndentCount():number {
        let index: number = 0;
        if (this.options.allowGrouping) {
            index += this.options.groupCount;
        }
        if (this.options.hasDetailTemplate) {
            index++;
        }
        if (this.options.allowRowDragAndDrop && !this.options.hasDropTarget) {
            index++;
        }
        /**
         * TODO: index normalization based on the stacked header, grouping and detailTemplate 
         * and frozen should be handled here 
         */
        return index;
    }

    public isPercentageWidth(): boolean {

    const columns: Column[] = this.getVisibleColumns();
    let percentageCol: number = 0;
    let undefinedWidthCol: number = 0;

    for (let i: number = 0; i < columns.length; i++) {

        if (isNullOrUndefined(columns[i].width)) {
            undefinedWidthCol++;
        } else if (columns[i].width.toString().indexOf('%') !== -1) {
            percentageCol++;
        }
    }
        return percentageCol === columns.length && !undefinedWidthCol;
}

    /**  
     * Gets indent Cell Width  
     * @hidden
     */
    public recalcIndentWidth(): void {
        if ((this.options.isRenderedFromTreeGrid && this.options.hasDetailTemplate && this.options.allowRowDragAndDrop) || (!this.isRendered || !this.getHeaderTable().querySelector('.e-emptycell'))) {
            return;
        }
        // Handle Detail and DragDrop
        if ((!this.options.groupCount && !this.options.hasDetailTemplate && 
            (this.options.allowRowDragAndDrop && this.options.hasDropTarget)) || !this.getContentTable()
        || this.getHeaderTable().querySelector('.e-emptycell').getAttribute("indentRefreshed")) {
            return;
        }
        let indentWidth: number = (this.getHeaderTable().querySelector('.e-emptycell').parentElement as HTMLElement).offsetWidth;
        let perPixel: number = indentWidth / 30;
        let i: number = 0;
        if (perPixel >= 1) {
            indentWidth = (30 / perPixel);
        }
        // if (this.enableColumnVirtualization || this.isAutoGen) { indentWidth = 30; }
        // if (this.isDetail()) {
        //     applyWidth(i, indentWidth);
        //     i++;
        // }
        // if (this.isRowDragable()) {
        //     applyWidth(i, indentWidth);
        // }
        this.getHeaderTable().querySelector('.e-emptycell').setAttribute('indentRefreshed', 'true');
        if (this.isPercentageWidth()) {
            const perPixel = indentWidth / 30;
            if (perPixel >= 1) {
                indentWidth = (30 / perPixel);
                indentWidth = indentWidth > 5 ? 3.5 : indentWidth;
            }

            this.dotNetRef.invokeMethodAsync('SetIndentWidth', indentWidth + '%');

        }
        else {
            this.dotNetRef.invokeMethodAsync('SetIndentWidth', indentWidth + 'px');
        }
    }

    public resetColumnWidth(): void {
        if ((this.options.width === 'auto' || typeof (this.options.width) === 'string')
            && this.getColumns().filter((col: Column) => (!col.width || col.width === 'auto') && col.minWidth).length > 0) {
            let tgridWidth: number = this.widthService.getTableWidth(this.getColumns());
            this.widthService.setMinwidthBycalculation(tgridWidth);
        }
    }

    public contentReady(action: string = null, isResetData? : boolean): void {

        //To add 100% width for main HTML element, when grid width is 100% or auto
        let mainLayoutTag = document.getElementsByTagName('main')[0] as HTMLElement;
          if (!isNullOrUndefined(mainLayoutTag) && mainLayoutTag.parentElement.classList.contains('page') && (this.element.style.width == '100%' || 'auto')) {
              mainLayoutTag.style.width = '100%';
          }
        if (this.getColumns().some(x => x.autoFit)) {

            // Add a setTimeout function to auto-fit columns when using frozen columns with a custom adapter.
            let __this = this;
            if(__this.element.querySelector('.e-emptyrow') && __this.options.frozenColumns) {
                setTimeout(function() {
                    __this.resizeModule.autoFit();
                }, 100);
            }
            else {
                this.resizeModule.autoFit();
            }           
        }
        if (this.options.allowResizing && this.isGridFirstRender && this.options.isColumnResized) {
            let widthService: ColumnWidthService = new ColumnWidthService(this);
            widthService.setWidthToTable();
            this.isGridFirstRender = false;
        }
        if(!this.isGridFirstRender && this.options.frozenColumns && (this.options.enablePersistence || isResetData)){
            let widthService: ColumnWidthService = new ColumnWidthService(this);
            widthService.setWidthToTable();
        }
        if (this.options.isColumnReordered && !isNullOrUndefined(this.getContent().querySelector('.e-movablecontent')) && 
        this.getContent().querySelector('.e-movablecontent').querySelector('table').style.width != '') {
            let widthService: ColumnWidthService = new ColumnWidthService(this);
            widthService.setWidthToTable();
        }
        if (this.options.frozenColumns && this.options.enableColumnVirtualization) {
            this.freezeModule.setFrozenHeight();
            if (this.options.aggregatesCount != 0) {
                let rowSummary: NodeListOf<HTMLElement> = this.element.querySelectorAll('.e-summaryrow');
                let height: number = 0;
                for (var i = 0; i < rowSummary.length; i++) {
                    if (rowSummary[i].querySelectorAll('.e-templatecell').length > 0) {
                        height = rowSummary[i].offsetHeight;
                        break;
                    }
                }
                for (var i = 0; i < rowSummary.length; i++) {
                    rowSummary[i].style.height = height + "px";
                    }
            }
        }
        if (this.options.enableVirtualization || this.options.enableColumnVirtualization) {
            this.virtualContentModule.onDataReady();
        }
        this.recalcIndentWidth();
        this.resetColumnWidth();
        this.lastRowBorderCheck();
        if (action === 'Paging') { //restore focus on paging.
            if (!parentsUntil(document.activeElement, 'e-grid')) {
                this.element.focus();
            }
        }
        if(this.options.enableStickyHeader){
            this.scrollModule.addStickyListener(true);
            const groupElem = this.element.querySelector('.e-groupdroparea') as HTMLElement;
            if(!isNullOrUndefined(groupElem) && groupElem.classList.contains('e-sticky') && groupElem.style.top === ""){
                groupElem.classList.remove('e-sticky');
            }
        }
        if(this.options.enableInfiniteScrolling){
           this.scrollModule.infiniteOnDataReady();
           this.scrollModule.resetInfniniteScrollPositions();
        }
        if(!isNullOrUndefined(this.toolTipModule.toolTipElement)){
            this.toolTipModule.close();
        }
        let frozenRightColumns: Column[] = this.getColumns().filter((a: Column) => {
            return a.isFrozen && a.freeze === "Right";
        });
        if (frozenRightColumns.length > 0) {
            this.element.classList.add('e-right-shadow');
        }
        if (this.options.frozenRows > 0) {
            (this.element.querySelector('.e-frozenrow-border') as HTMLElement).style.width = this.getContent().scrollHeight > this.getContent().offsetHeight ? this.element.offsetWidth - 17 + "px" : this.element.offsetWidth + "px";
        }
    }

    public lastRowBorderCheck(): void {
        if (!this.options.enableVirtualization) {
            if (this.getContent().querySelector(".e-table").scrollHeight < this.getContent().clientHeight) {
                this.dotNetRef.invokeMethodAsync('LastRowBorder', true);
            }
        }
    }

    public wireEvents(): void {
        EventHandler.add(this.element,'mousedown', this.mouseDownHandler, this);
        EventHandler.add(this.element,'focus', this.gridFocus, this);
        EventHandler.add(document,'click', this.documentClickHandler, this);
        EventHandler.add(this.element,'keydown', this.gridKeyDownHandler, this);
        EventHandler.add(this.element, 'keydown', this.keyDownHandler, this);
        EventHandler.add(document.body,'keydown', this.documentKeyHandler, this);
        EventHandler.add(this.getContent(), 'touchstart', this.tapEvent, this);
        EventHandler.add(window as any, 'resize', this.windowResized, this);
        EventHandler.add(this.element,'contextmenu', this.mouseDownHandler, this);
        if (this.options.allowEditing) {
            EventHandler.add(this.element, 'dblclick', this.doubleClickHandler, this);
        }
    }

    public unWireEvents(): void {
        EventHandler.remove(this.element, 'mousedown', this.mouseDownHandler);
        EventHandler.remove(this.element, 'focus', this.gridFocus);
        EventHandler.remove(document, 'click', this.documentClickHandler);
        EventHandler.remove(this.element, 'keydown', this.gridKeyDownHandler);
        EventHandler.remove(this.element, 'keydown', this.keyDownHandler);
        EventHandler.remove(document.body,'keydown', this.documentKeyHandler);
        EventHandler.remove(this.element, 'dblclick', this.doubleClickHandler);
        EventHandler.remove(this.getContent(), 'touchstart', this.tapEvent);
        EventHandler.remove(window as any, 'resize', this.windowResized);
        EventHandler.remove(this.element, 'contextmenu', this.mouseDownHandler);
    }
    
    private windowResized(): void {
        const _this: SfGrid = this;
        setTimeout(function(){
            let content: HTMLElement = <HTMLElement>_this.element.querySelector('.e-content.e-yscroll');
            if(_this.options.frozenColumns && (_this.options.width == '100%' || 'auto')){
                if(_this.options.allowTextWrap){
                    _this.freezeModule.refreshRowHeight();
                }
            } 
            if(!isNullOrUndefined(content) && content.scrollHeight > content.clientHeight)
            {
                (_this.element.querySelector('.e-gridheader')as HTMLElement).style.paddingRight= getScrollBarWidth() - _this.scrollModule.getThreshold() + "px";
            }
            else{
                _this.scrollModule.setPadding();
            }
            let gridContent: HTMLElement = <HTMLElement> _this.element.querySelector('.e-gridcontent');
            let startIndex: number = gridContent.style.height.indexOf("- ") + 2;
            let endIndex: number = gridContent.style.height.indexOf("p");
            let sibilingsHeight: number = !isNullOrUndefined(gridContent) && gridContent.style.height != "" ? parseInt(gridContent.style.height.slice(startIndex, endIndex)) : 0;
            let height: number = !isNullOrUndefined(gridContent) && gridContent.style.height != "" ? getSiblingsHeight(gridContent) : 0;
            if(height != sibilingsHeight){
                _this.scrollModule.refresh();
            }
            _this.columnChooserModule.windowResized();

        },100);

    }
    private doubleClickHandler(e: MouseEventArgs): void {
        if ((e.target as HTMLElement).tagName == 'TD') {
            (e.target as HTMLElement).blur();
        }
        this.toolTipModule.close();
    }
    private tapEvent = function (e: MouseEventArgs): void {
        if (this.resizeModule.getUserAgent()) {
            if (!Global.timer) {
                Global.timer = setTimeout(function () {
                    Global.timer = null;
                }, 300);
            }
            else {
                clearTimeout(Global.timer as number);
                Global.timer = null;
                let clickEvent: Event = document.createEvent('MouseEvents');
                clickEvent.initEvent('dblclick', true, true);
                e.target.dispatchEvent(clickEvent);
            }
        }
    };
    public setOptions(newOptions: IGridOptions, options: IGridOptions) {
        let oldOptions: IGridOptions = <IGridOptions>extend(options, {});
        this.options = newOptions;
        if (!oldOptions.allowResizing && newOptions.allowResizing) {
            this.resizeModule.render();
        }
        if ((!oldOptions.allowGrouping && newOptions.allowGrouping)
            || (!oldOptions.allowReordering && newOptions.allowReordering) || newOptions.showDropArea) {
            this.headerDragDrop.initializeHeaderDrag();
            this.headerDragDrop.initializeHeaderDrop();
            this.groupModule.initializeGHeaderDrag();
            this.groupModule.initializeGHeaderDrop();
        }

        if (!oldOptions.allowGrouping && newOptions.allowGrouping) {
            this.contentDragDrop.initializeContentDrop();
        }

        if (!oldOptions.allowRowDragAndDrop && newOptions.allowRowDragAndDrop) {
            this.rowDragAndDropModule.initializeDrag();
        } else if (oldOptions.allowRowDragAndDrop && !newOptions.allowRowDragAndDrop){
            this.rowDragAndDropModule.destroy();
        }

        if (!this.isRendered) {
            this.isRendered = this.options.isPrerendered;
        }

        if (oldOptions.groupCount != newOptions.groupCount) {
            let cell: Element = this.getHeaderTable().querySelector('.e-emptycell');
            if (!cell) { return; }
            cell.removeAttribute('indentRefreshed');
        }
    }
    public documentClickHandler(e: MouseEventArgs): void { 
        let CCButton: Element = parentsUntil(<Element>e.target, 'e-cc-toolbar');
        let formElement: Element = parentsUntil(<Element>e.target, 'e-gridform');
        let toolbar: Element = parentsUntil(<Element>e.target, 'e-toolbar-item');
        let cellElement: Element = parentsUntil(<Element>e.target, 'e-rowcell');
        this.virtualContentModule.selectedCellNavigation = -1;
        if (parentsUntil(<Element>e.target, 'e-inline-edit'))
        {
            var cell = parentsUntil(<Element>e.target, 'e-rowcell');
            this.editedCellIndex = (cell as HTMLTableCellElement) == null ? null : (cell as HTMLTableCellElement).cellIndex;
        }
        else {
            if (isNullOrUndefined(parentsUntil(<Element>e.target, 'e-popup-open')))
            {
                this.editedCellIndex = null;
            }
        }
        if (!this.options.enableAdaptiveUI && !this.targetIsFilterDialog(e) && !((<Element>e.target).classList.contains('e-cc-cancel')) && !((<Element>e.target).classList.contains('e-choosercheck')) && !((<Element>e.target).classList.contains('e-icon-filter')) && !CCButton && (this.element.querySelectorAll('.e-filter-popup.e-popup-open').length || this.element.querySelectorAll('.e-ccdlg.e-popup-open').length)) {
            if (this.element.querySelector('.e-datetimepicker') != null) {
                (this.element.querySelector('.e-datetimepicker') as HTMLElement).blur();
            }
            this.dotNetRef.invokeMethodAsync('FilterPopupClose');
        }
        if (isNullOrUndefined(formElement) && !cellElement && !toolbar && !this.targetIsFilterDialog(e) && this.element.querySelector(".e-gridform")) {
            this.dotNetRef.invokeMethodAsync('UpdateChanges');
        }
        if (!Browser.isDevice) {
            this.toolTipModule.close();
        }
    }
    public targetIsFilterDialog(e: MouseEventArgs): boolean {
        let popupElement: Element = parentsUntil(parentsUntil(<Element>e.target, 'e-filter-popup'), 'e-popup-open');
        let filterDropdown: Element = parentsUntil(parentsUntil(<Element>e.target, 'e-ddl'), 'e-popup-open');
        let filterCheckbox: Element = parentsUntil(parentsUntil(<Element>e.target, 'e-selectall'), 'e-ftrchk');
        let searchClear: Element = parentsUntil(<Element>e.target, 'e-chkcancel-icon');
        let datetimePicker: Element = parentsUntil(<Element>e.target, 'e-datepicker');
        let timePicker: Element = parentsUntil(<Element>e.target, 'e-timepicker');
        let daterangePicker: Element = parentsUntil(<Element>e.target, 'e-daterangepicker') || parentsUntil(<Element>e.target, 'e-zoomin');
        let isBlankCheckbox: boolean = ((<Element>e.target).classList.contains('e-check')) || ((<Element>e.target).classList.contains('e-uncheck'));
        let ccPopupElement: Element = parentsUntil(parentsUntil(<Element>e.target, 'e-ccdlg'), 'e-popup-open');
        let dropDownTreeElement: Element = parentsUntil(parentsUntil(<Element>e.target, 'e-ddt'), 'e-popup-open');

        if (popupElement || filterDropdown || filterCheckbox || searchClear || datetimePicker || timePicker || daterangePicker || isBlankCheckbox || ccPopupElement || dropDownTreeElement)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    private documentKeyHandler(e: KeyboardEventArgs): void {
        //TODO: handle alt+w
        // 74 - J
        if (e.altKey && e.keyCode === 74 && !isNullOrUndefined(this.element))
        {
            this.element.focus();
            this.dotNetRef.invokeMethodAsync("GridFocus", e);
        }
        if (e.altKey && e.keyCode === 87 && !isNullOrUndefined(this.element)) {
            let isPagerFocused: boolean = !isNullOrUndefined(parentsUntil(<Element>e.target, 'e-pager'));
            let isSearchInput: boolean = false;
            this.dotNetRef.invokeMethodAsync("GridKeyDown", { 
                key: e.key,
                code: e.code,
                ctrlKey: e.ctrlKey,
                shiftKey: e.shiftKey,
                altKey: e.altKey
            }, isSearchInput, isPagerFocused, this.editedCellIndex, null, null, false, false);
        }
    }

    public iterateTemplateElementsForward(columnTemplateElements: HTMLCollection) {
          for (var i = 0; i < columnTemplateElements.length; i++) {
              var currentElement = columnTemplateElements[i];
              if ((currentElement as HTMLElement).tabIndex == 0) {
                  this.firstFocusableTemplateElement = currentElement;
                  break;
              } else if (!isNullOrUndefined(currentElement.children) && currentElement.children.length != 0) {
                this.iterateTemplateElementsForward(currentElement.children);
                break;
              }
          }
          return this.firstFocusableTemplateElement;
    }

    public iterateTemplateElementsBackward(columnTemplateElements: HTMLCollection) {
        for (var i = columnTemplateElements.length - 1; i >= 0; i--) {
            let currentElement = columnTemplateElements[i];
            if ((currentElement as HTMLElement).tabIndex == 0) {
                this.lastFocusableTemplateElement = currentElement;
                break;
            } else if (!isNullOrUndefined(currentElement.children) && currentElement.children.length != 0) {
                this.iterateTemplateElementsBackward(currentElement.children);
                break;
            }
        }
        return this.lastFocusableTemplateElement;
    }

    public keyDownHandler(e: KeyboardEventArgs): void {
        var gridElement = parentsUntil(<Element>e.target, 'e-grid');
        let elementTag: string = (e.target as HTMLElement).tagName;
	    let isPagerFocused: boolean = !isNullOrUndefined(parentsUntil(<Element>e.target, 'e-pager'));
        let isSearchInput: boolean = false;
        let focusTemplateCell: boolean = false;
        let cellIndex: number;
        var rowIndex: number;

        if ((gridElement && gridElement.id !== this.element.id) ||  
            (e.key == "Shift" || e.key == "Control" || e.key == "Meta" || e.key == "Alt")) {
            return;
        }
        
        if((elementTag == "INPUT" || elementTag == "TEXTAREA") && e.code == "Delete") {
            return;
        }        

        if (!isNullOrUndefined(gridElement) && !isNullOrUndefined(gridElement.querySelector('.e-templatecell')) && !isNullOrUndefined(parentsUntil(<Element>e.target, 'e-templatecell'))) {
            var templateCell = parentsUntil(<Element>e.target, 'e-rowcell');
            if (isNullOrUndefined(templateCell) || !(templateCell.firstElementChild)) { return; }
            cellIndex = (templateCell as HTMLTableCellElement).cellIndex;
            rowIndex = (Number)(parentsUntil(<Element>e.target, 'e-row').getAttribute('data-rowIndex'));
            let templateElements : HTMLCollection = templateCell.firstElementChild.children;
            var firstFocussableElement = this.iterateTemplateElementsForward(templateElements);
            var lastFocussableElement = this.iterateTemplateElementsBackward(templateElements);
            var isTabKey = !e.shiftKey && e.code == "Tab";
            var isShiftTabKey = e.shiftKey && e.code == "Tab";
            var isEscapeKey = e.code == "Escape";

            if ((e.target == firstFocussableElement && isShiftTabKey) || (e.target == lastFocussableElement && isTabKey) || isEscapeKey || 
                (firstFocussableElement == null && lastFocussableElement == null && !((e.target as HTMLElement).classList.contains('e-templatecell')) && (isTabKey || isShiftTabKey))) {
                focusTemplateCell = true;
            }
        }

        if((e.target as HTMLElement).classList.contains('e-searchinput') && e.key == "Enter"){
            isSearchInput = true;
        }

        let allow: boolean = this.isPopUpOpened(e);
        if(allow && (e.key == 'Escape' || e.key == 'Enter') && document.activeElement.tagName == 'BODY'){
            (e.target as HTMLElement).focus();
        }
		if (e.key == 'Escape' && (allow && (e.target as Element).getAttribute('aria-expanded') === 'true'))
		{
            return;
		}
        if (!isNullOrUndefined(parentsUntil(<Element>e.target, 'e-rowcell')))
        {
            this.editedCellIndex = (parentsUntil(<Element>e.target, 'e-rowcell') as HTMLTableCellElement).cellIndex == this.editedCellIndex ? this.editedCellIndex : null;
        }
        //Batch edit with multi select with Enter key and arrow keys scenario handled.
        let isMultiSelectPopupRendered : boolean = false;
        if (!isNullOrUndefined(parentsUntil((e.target as Element), 'e-batchrow')) && allow && e.key == 'Enter' && (e.target as Element).classList.contains('e-multiselect')) {
            let popupOpened : HTMLCollectionOf<Element>= document.getElementsByClassName('e-popup-open');
            if (popupOpened.length > 0) {
                for (var i = 0; i < popupOpened.length; i++) {
                    if (popupOpened[i].id === (e.target as Element).getAttribute('aria-owns')) {
                        isMultiSelectPopupRendered = true;
                    }
                    break;
                }
            }
        }
        this.dotNetRef.invokeMethodAsync("GridKeyDown", { 
            key: e.key,
            code: e.code,
            ctrlKey: e.ctrlKey,
            shiftKey: e.shiftKey,
            altKey: e.altKey,
	    metaKey: e.metaKey,		
        }, isSearchInput, isPagerFocused, this.editedCellIndex, rowIndex, cellIndex, focusTemplateCell, isMultiSelectPopupRendered);
    }

    private isPopUpOpened(e: KeyboardEventArgs): boolean {
        let datePicker: boolean = (e.target as Element).classList.contains('e-datepicker');
        let dateTimePicker: boolean = (e.target as Element).classList.contains('e-datetimepicker');
        let timePicker: boolean = (e.target as Element).classList.contains('e-timepicker');
        let daterangePicker: boolean = (e.target as Element).classList.contains('e-daterangepicker');
        let multiSelect: boolean = (e.target as Element).classList.contains('e-multiselect');
        let dropDownList: boolean = !isNullOrUndefined(parentsUntil(<Element>e.target, 'e-ddl'));
        let autoComplete: boolean = (e.target as Element).classList.contains('e-autocomplete');
	let comboBox: boolean = (e.target as Element).classList.contains('e-combobox');
        return (datePicker || dateTimePicker || timePicker || daterangePicker || multiSelect || dropDownList || autoComplete || comboBox);
    }

    public gridKeyDownHandler(e: KeyboardEventArgs): void {
        let popupElement: Element = parentsUntil(<Element>e.target, 'e-filter-popup');
        let elementTag: string = (e.target as HTMLElement).tagName;
        this.toolTipModule.close();
        if (!isNullOrUndefined(popupElement) && popupElement.classList.contains('e-popup-open') && e.key != 'Escape') {
            e.stopPropagation();
            if ((e.key == "Tab" || e.key == "shiftTab" || e.key == "Enter" || e.key == "shiftEnter") && 
                (elementTag == "INPUT" || elementTag == "TEXTAREA")) {
                let evt = document.createEvent('HTMLEvents');
                evt.initEvent('change', false, true);
                e.target.dispatchEvent(evt);
            }
        }

        // handling the focus for the template used inside edit settings.
        let shouldReturn = false;
        if (this.options.hasTemplateInEditSettings && parentsUntil(<Element>e.target, 'e-normaledit')) {
            const editFormInputElements = this.element.querySelector('.e-normaledit').querySelectorAll("input");
            const editFormTextareaElements = this.element.querySelector('.e-normaledit').querySelectorAll("textarea");
            const editForm: (HTMLInputElement | HTMLTextAreaElement)[] = [ ...Array.from(editFormInputElements), ...Array.from(editFormTextareaElements)];
            shouldReturn = true;
            if (!isNullOrUndefined(editForm))
            {
                const firstInput = editForm[0];
                const lastInput = editForm[editForm.length - 1];
                const isShiftTabKey = e.shiftKey && e.key === "Tab";
                const isTabKey = !e.shiftKey && e.key === "Tab";
                if ((document.activeElement === firstInput && isShiftTabKey) || (document.activeElement === lastInput && isTabKey)) {
                    shouldReturn = false;
                }
            }
        }

        // Handling the fix for the mouse click issue while using the EditTemplate in normal editing refer task: 876403
        if (e.key == "Tab") {
            let normalEditDiv: HTMLElement = this.element.querySelector('.e-normaledit');
            if (!isNullOrUndefined(normalEditDiv))
            {
                const targetElement = e.target as HTMLElement;
                let isAutoCompleteOrMultiSelectOrTimePicker: boolean = targetElement.classList.contains('e-autocomplete') || targetElement.classList.contains('e-multiselect') || targetElement.classList.contains('e-timepicker');
                let visibleTds: Element[] = (Array.from(normalEditDiv.querySelectorAll('.e-rowcell'))).filter(e=> !(e.classList.contains('e-hide') || e.querySelector('.e-disabled')));
                if (isAutoCompleteOrMultiSelectOrTimePicker && ((e.key == "Tab" && !e.shiftKey && visibleTds[visibleTds.length - 1] != parentsUntil(targetElement, "e-rowcell")) || (e.key == "Tab" && e.shiftKey && visibleTds[0] != parentsUntil(targetElement, "e-rowcell")))) {
                    return;
                }
            }
        }

        //TODO: datepicker in dialog editing
        if (((e.key == "Tab" || e.key == 'Escape' || e.key == "shiftTab" || e.key == "Enter" || e.key == "shiftEnter")
            && (elementTag == 'INPUT' || elementTag == "TEXTAREA" || (e.target as HTMLElement).classList.contains('e-datepicker') || (e.target as HTMLElement).classList.contains('e-datetimepicker'))) || ((e.target as HTMLElement).classList.contains('e-rowcell') && e.key == "F2")) {
		const targetElement = e.target as HTMLElement;
		if (!((e.key === "Tab" && (targetElement.classList.contains('e-datepicker') || targetElement.classList.contains('e-datetimepicker'))) ||
			(e.key === "Enter" && targetElement.classList.contains('e-autocomplete') || targetElement.classList.contains('e-multiselect')))) {
		      targetElement.blur();          
		  }
        }

        if (e.key == "Shift" || e.key == "Control" || e.key == "Alt") { 
            e.stopPropagation(); //dont let execute c# keydown handler for meta keys.
        }
        const isMacLike: boolean = /(Mac)/i.test(navigator.platform);
        if (e.keyCode === 67 && (e.ctrlKey || (isMacLike && e.metaKey))) {
            this.clipboardModule.copy();
        } else if (e.keyCode === 72 && (e.ctrlKey || (isMacLike && e.metaKey)) && e.shiftKey) {
            this.clipboardModule.copy(true);
        }
        if (e.keyCode === 86 && (e.ctrlKey || (isMacLike && e.metaKey)) && !this.options.isEdit) {
            const rowElement = parentsUntil(<Element>e.target, 'e-rowcell');
            if(!isNullOrUndefined(rowElement) && !rowElement.classList.contains('e-templatecell')) {
                e.stopPropagation();
            }
            this.clipboardModule.pasteHandler();
        }

        let normalEditDivs: NodeListOf<HTMLElement> = this.element.querySelectorAll('.e-normaledit');
        let normalEditDiv: HTMLElement;
        if (!isNullOrUndefined(normalEditDivs)) {
            normalEditDivs.forEach(function (element) {
                if (element.contains(<Element>e.target)) {
                    normalEditDiv = element;
                }
            });
        }
        if (parentsUntil(<Element>e.target, "e-showAddNewRow") && e.shiftKey) {
            return;
        }
        if (!isNullOrUndefined(normalEditDiv) && e.key == "Tab") {
            let visibleTds: Element[] = (Array.from(normalEditDiv.querySelectorAll('.e-rowcell'))).filter(e=> !(e.classList.contains('e-hide') || e.querySelector('.e-disabled')));
            
            if (shouldReturn) {
                return;
            }
            
            if ((!e.shiftKey && visibleTds[visibleTds.length - 1] == parentsUntil(e.target as Element, "e-rowcell"))
            || (e.shiftKey && visibleTds[0] == parentsUntil(e.target as Element, "e-rowcell"))) {
                this.dotNetRef.invokeMethodAsync("EndEdit", { 
                    key: e.key,
                    code: e.code,
                    ctrlKey: e.ctrlKey,
                    shiftKey: e.shiftKey,
                    altKey: e.altKey
                });
                e.preventDefault();
            }
        }

        if (this.element.querySelector('.e-batchrow')) {
            //new
            if (e.key == "Tab" || e.key == "shiftTab" || e.key == "Enter" || e.key == "shiftEnter") {
                e.preventDefault();
                if (elementTag == "INPUT" || elementTag == "TEXTAREA") {
                    let evt = document.createEvent('HTMLEvents');
                    evt.initEvent('change', false, true);
                    e.target.dispatchEvent(evt);
                }
            }

        }

        if(this.options.selectionMode == "Cell" && this.options.editMode == "Batch" && parentsUntil(e.target as Element, 'e-gridform')){
            let rows: HTMLElement = parentsUntil(parentsUntil(e.target as Element, 'e-gridform'), "e-row") as HTMLElement;
            let cells: NodeListOf<HTMLTableCellElement> = rows.querySelectorAll('.e-rowcell:not(.e-hide)') as NodeListOf<HTMLTableCellElement>;
            let currentCell: HTMLTableCellElement = parentsUntil(e.target as Element, "e-rowcell") as HTMLTableCellElement;
            if(!e.shiftKey && e.key == "Tab"){
                for (var i = 0; i < cells.length; i++) {
                    var cell = cells[i] as HTMLTableCellElement;
                    if (cell.cellIndex == currentCell.cellIndex) {
                        if (i < cells.length - 1) {
                            cells[i + 1].tabIndex = 0;
                        }
                        break; // This will exit the for loop once the condition is satisfied
                    }
                }
            }
            else if(e.shiftKey && e.key == "Tab"){
                for (var i = cells.length - 1; i >= 0; i--) {
                    var cell = cells[i];
                    if (cell.cellIndex == currentCell.cellIndex) {
                        if (i > 0) {
                            cells[i - 1].tabIndex = 0;
                        }
                        break; // This will exit the for loop once the condition is satisfied
                    }
                }
            }
        }
    }

    public mouseDownHandler(e: MouseEventArgs): void {
        let gridElement: Element = parentsUntil(<Element>e.target, 'e-grid');
        if (gridElement && gridElement.id !== this.element.id) {
            return;
        }
        if (!this.options.enableAdaptiveUI && !this.targetIsFilterDialog(e) && (<Element>e.target).classList.contains('e-content')  && (this.element.querySelectorAll('.e-filter-popup.e-popup-open').length || this.element.querySelectorAll('.e-ccdlg.e-popup-open').length)) {
            this.dotNetRef.invokeMethodAsync('FilterPopupClose');
        }
        if (e.shiftKey || e.ctrlKey) {
            e.preventDefault(); //prevent user select on shift pressing during selection
        }
        // e.button = 2 for right mouse button click
        if ((e.button !== -1 && e.button !== 2 && parentsUntil(<Element>e.target, 'e-headercell')) || (e.button !== 2 && parentsUntil(<Element>e.target, 'e-detailcell')) || parentsUntil(<Element>e.target, 'e-detailrowexpand') || parentsUntil(<Element>e.target, 'e-detailrowcollapse')
            || (<Element>e.target).classList.contains('e-content') || (<Element>e.target).classList.contains('e-headercontent') || closest(<Element>e.target, ".e-groupdroparea") || closest(<Element>e.target, ".e-gridpopup")
            || closest(<Element>e.target, ".e-summarycell") || closest(<Element>e.target, ".e-rhandler")
            || closest(<Element>e.target, ".e-filtermenudiv") || closest(<Element>e.target, ".e-filterbarcell")
            || closest(<Element>e.target, ".e-groupcaption")) {
                this.dotNetRef.invokeMethodAsync("MouseDownHandler", null, null);
        } else {
            let target: string = null;
            let cellUid: string = null;
            let editForm: Element = parentsUntil(parentsUntil(<Element>e.target, 'e-gridform'), 'e-grid');
            if (parentsUntil(<Element>e.target, 'e-editcell') || editForm && editForm.id == gridElement.id) {
                target = "Edit"
            } else if (parentsUntil(<Element>e.target, 'e-pager')) {
                target = "Pager"
            } else if (parentsUntil(<Element>e.target, 'e-headercontent')) {
                target = "Header";
                cellUid = parentsUntil(<Element>e.target, 'e-headercell') ? parentsUntil(<Element>e.target, 'e-headercell').getAttribute('data-uid') : null;
            } else if (parentsUntil(<Element>e.target, 'e-content')) {
                target = "Content";
                cellUid = parentsUntil(<Element>e.target, 'e-rowcell') ? parentsUntil(<Element>e.target, 'e-rowcell').getAttribute('data-uid') : null;
            }
            if (target == "Header" || target == "Content" || target == "Pager" || target == "Edit") {
                this.dotNetRef.invokeMethodAsync("MouseDownHandler", target, cellUid);
            }
        }
    }

    public gridFocus(e: FocusEvent) { //new
        if (!isNullOrUndefined(this.element.querySelector(".e-gridform")) && 
            this.element.querySelector(".e-gridform").classList.contains("e-editing")) { return; }
        this.dotNetRef.invokeMethodAsync("GridFocus", e);
    }

    public keyActionHandler(e: KeyboardEventArgs) {
        let elementTag: string = (e.target as HTMLElement).tagName;
        let isSelectTag: boolean = false;
        let isGridEditForm: boolean = false;
        isSelectTag = !isNullOrUndefined(this.element.querySelector(".e-gridform")) && this.element.querySelector(".e-gridform").classList.contains("e-editing") && elementTag == "SELECT";
        if (e.action === 'pageUp' || e.action === 'pageDown' || e.action === 'ctrlAltPageUp' 
        || e.action === 'ctrlAltPageDown' || e.action === 'altPageUp' || e.action === 'altPageDown' 
        || (e.action === 'altDownArrow' && !isSelectTag) || e.action === 'ctrlPlusP') { 
            e.preventDefault();
        }
        let allow: boolean = this.isPopUpOpened(e);
        let inputElement: Element = parentsUntil(<Element>e.target, 'e-autocomplete');
        if (!isNullOrUndefined(inputElement)) {
            let id: string = inputElement.id + '_popup';
            if (!isNullOrUndefined(document.getElementById(id))) {
                return;
            }
        }
        if (parentsUntil(<Element>e.target, 'e-unboundcelldiv') && e.action === 'enter' && (<Element>e.target).classList.contains('e-Savebutton')) {
            return;
        }
        if (!isNullOrUndefined(this.element.querySelector('tr.e-showAddNewRow')) && (parentsUntil(<Element>e.target, 'e-filterbarcell') || (<Element>e.target).classList.contains('e-searchinput')))
        {
            return;
        }
        let gridForms: NodeListOf<HTMLElement> = this.element.querySelectorAll(".e-gridform");

        if (!isNullOrUndefined(gridForms)) {
            gridForms.forEach(function (gridForm) {
                if (gridForm.classList.contains("e-editing") || (gridForm.classList.contains("e-adding") && parentsUntil(<Element>e.target, 'e-showAddNewRow'))) {
                    isGridEditForm = true;
                }
            });
        }
        if (e.action === 'enter' && isGridEditForm
            && this.options.editMode !== "Batch" &&
            ((allow && (e.target as Element).getAttribute('aria-expanded') === 'false') || !allow)) {
            setTimeout(() => 
                {
                    (e.target as HTMLElement).blur();
                    this.dotNetRef.invokeMethodAsync("EndEdit", { 
                        key: e.key,
                        code: e.code,
                        ctrlKey: e.ctrlKey,
                        shiftKey: e.shiftKey,
                        altKey: e.altKey
                    });
                }, 40);
        }
    }

    public destroy(isRerendered: boolean) {
        this.unWireEvents();
        this.frozenDragDropModule.unwireEvents();
        if(isRerendered){
            this.virtualContentModule.removeEventListener();
        }
        this.addScrollEvents(false);
        this.toolTipModule.destroy();
        this.keyModule.destroy();        
        this.columnChooserModule.removeMediaListener();
        this.selectionModule.removeEventListener();
        this.rowDragAndDropModule.destroy(); 
        this.headerDragDrop.destroy();       
        this.scrollModule.destroy();
	(window as any).sfBlazor.disposeWindowsInstance(this.dataId);
    }
/**
     * @private
     */
    public getColumnIndexesInView(): number[] {
        return this.inViewIndexes;
    }

    /**
     * @private
     */
    public setColumnIndexesInView(indexes: number[]): void {
        this.inViewIndexes = indexes;
    }

    public getRowHeight(): number {
        return this.options.rowHeight ? this.options.rowHeight : getRowHeight(this.element);
    }

    private clientActions(): void {
        if ((this.options.enableVirtualization || this.options.enableColumnVirtualization) && (this.options.pageSize === 12 || this.options.width === 'auto')) {
            this.virtualContentModule.ensurePageSize();
        }
        if (this.getColumns().some((col: Column) =>  col.hideAtMedia !== '')) {
            this.columnChooserModule.setMediaColumns();
        }
    }

    public print(): void {
        this.removeColGroup();
        let printWind: Window = window.open('', 'print', 'height=' + window.outerHeight + ',width=' + window.outerWidth + ',tabbar=no');
        printWind.moveTo(0, 0);
        printWind.resizeTo(screen.availWidth, screen.availHeight);
        print(this.element, printWind);
    }

    private removeColGroup() : void {
        let depth: number = this.options.groupCount;
        let element: HTMLElement = this.element;
        let id: string = '#' + this.element.id;
        if (!depth) {
            return;
        }
        let groupCaption: NodeList = element.querySelectorAll(`.e-groupcaption`);
        let colSpan: string = (<HTMLElement>groupCaption[depth - 1]).getAttribute('colspan');
        for (let i: number = 0; i < groupCaption.length; i++) {
            (<HTMLElement>groupCaption[i]).setAttribute('colspan', colSpan);
        }
        let colGroups: NodeList = element.querySelectorAll(`colgroup${id}colGroup`);
        let contentColGroups: NodeList = element.querySelector('.e-content').querySelectorAll('colgroup');
        this.hideColGroup(colGroups, depth);
        this.hideColGroup(contentColGroups, depth);
    }

    private hideColGroup(colGroups: NodeList, depth: number): void {
        for (let i: number = 0; i < colGroups.length; i++) {
            for (let j: number = 0; j < depth; j++) {
                (<HTMLElement>(<HTMLElement>colGroups[i]).children[j]).style.display = 'none';
            }
        }
    }

    /**
     * For internal use only - Get the module name.
     * @private
     */
    protected getModuleName(): string {
        return 'grid';
    }
}

const gridKeyConfigs: { [x: string]: string } = {
    pageUp: 'pageup',
    pageDown: 'pagedown',
    ctrlAltPageUp: 'ctrl+alt+pageup',
    ctrlAltPageDown: 'ctrl+alt+pagedown',
    altPageUp: 'alt+pageup',
    altPageDown: 'alt+pagedown',
    altDownArrow: 'alt+downarrow',
    altUpArrow: 'alt+uparrow',
    ctrlDownArrow: 'ctrl+downarrow',
    ctrlUpArrow: 'ctrl+uparrow',
    ctrlPlusA: 'ctrl+A',
    ctrlPlusP: 'ctrl+P',
    ctrlPlusC: 'ctrl+C',
    ctrlShiftPlusH: 'ctrl+shift+H',
    enter: 'enter',
};
