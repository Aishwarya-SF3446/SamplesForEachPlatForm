export let gridCellSpanData: { [key: string]: string }[] =
[
    { 
        EmployeeID: "10001",
        EmployeeName: "Davolio",
         "9-10": "Analysis",
         "10-11": "Team Meeting",
         "11-12": "Development",
         "12-1": "Development",
          "2-3": "Testing",
          "3-4": "Testing",
          "4-5": "Web Meeting",
          "5-6": "Web meeting"
     },
     {
        EmployeeID: "10002",
        EmployeeName: "Buchanan",
        "9-10": "Ticket Analysis",
        "10-11": "Ticket Clearance",
        "11-12": "Ticket Clearance",
        "12-1": "Ticket Clearance",
         "2-3": "Bug Fixing",
         "3-4": "Bix Fixing",
         "4-5": "Testing",
         "5-6": "Team meeting"
     },
     {
        EmployeeID: "10003",
        EmployeeName: "Fuller",
        "9-10": "Content Drafting",
        "10-11": "Content Drafting",
        "11-12":"Content Drafting",
        "12-1": "Content Drafting",
        "2-3": "Review & Testing",
        "3-4": "Publishing content",
        "4-5": "Meeting",
        "5-6": "Meeting"
     },
     {
         EmployeeID: "10004",
         EmployeeName: "Leverling",
         "9-10": "Analysis and spec preparation",
         "10-11": "Analysis and spec preparation",
         "11-12": "Design UI",
         "12-1": "Design UI",
         "2-3": "Design UI",
         "3-4": "Development team Meeting",
         "4-5": "Publishing Design",
         "5-6": "Publishing Design"
      },
      { 
        EmployeeID: "10005",
        EmployeeName: "Janet",
        "9-10": "Ticket Analysis",
        "10-11": "Ticket Clearance",
        "11-12": "Ticket Clearance",
        "12-1": "Ticket Clearance",
         "2-3": "Bug Fixing",
         "3-4": "Bix Fixing",
         "4-5": "Testing",
         "5-6": "Team meeting"
     },
     {
        EmployeeID: "10006",
        EmployeeName: "Andrew",
        "9-10": "Content Drafting",
        "10-11": "Content Drafting",
        "11-12":"Content Drafting",
        "12-1": "Content Drafting",
        "2-3": "Review & Testing",
        "3-4": "Publishing content",
        "4-5": "Meeting",
        "5-6": "Meeting"
     },
     {
        EmployeeID: "10007",
        EmployeeName: "Michael",
        "9-10": "Analysis",
        "10-11": "Team Meeting",
        "11-12": "Development",
        "12-1": "Development",
         "2-3": "Testing",
         "3-4": "Testing",
         "4-5": "Web Meeting",
         "5-6": "Web meeting"
     },
     {
         EmployeeID: "10008",
         EmployeeName: "Robert",
         "9-10": "Analysis and spec preparation",
         "10-11": "Analysis and spec preparation",
         "11-12": "Design UI",
         "12-1": "Design UI",
         "2-3": "Design UI",
         "3-4": "Development team Meeting",
         "4-5": "Publishing Design",
         "5-6": "Publishing Design"
      }
]