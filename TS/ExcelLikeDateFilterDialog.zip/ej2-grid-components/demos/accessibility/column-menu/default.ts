import { Resize, Sort, Group, Filter, ColumnMenu, Page, Selection, Edit } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import { data } from '../../../spec/grid/base/datasource.spec';
import '../../../node_modules/es6-promise/dist/es6-promise';

Grid.Inject(Page, Selection, Sort, ColumnMenu, Group, Resize, Filter, Edit);
let grid: Grid = new Grid({
    dataSource: data.slice(0,3),
    allowGrouping: true,
    allowSorting: true,
    allowFiltering: true,
    filterSettings: { type: 'CheckBox' },
    groupSettings: { showGroupedColumn: true },
    editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal', showConfirmDialog: false, showDeleteConfirmDialog: false },
    showColumnMenu: true,
    dataBound: function () {
        (grid as any).dblClickHandler({ target: grid.element.querySelectorAll('.e-row')[1].firstElementChild });
        (grid.element.querySelector('#' + grid.element.id + 'CustomerID') as any).value = 'updated';
        (grid.element.querySelectorAll('.e-row')[2] as any).cells[0].click();
    },
    columns: [
            { field: 'OrderID', type: 'number', isPrimaryKey: true, visible: true, validationRules: { required: true }, showInColumnChooser: false },
            { field: 'CustomerID', type: 'string' },
            { field: 'EmployeeID', type: 'number', allowEditing: false }
    ]
});
grid.appendTo('#Grid');
(grid.getHeaderContent().querySelector('.e-columnmenu') as HTMLElement).click();