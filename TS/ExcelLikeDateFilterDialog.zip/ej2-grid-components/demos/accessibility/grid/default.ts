import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate, Edit, RowDD, ColumnChooser, Reorder } from '../../../src/index';
import { GridActionEventArgs } from '../../../src/grid/base/interface';
import { Grid } from '../../../src/grid/base/grid';
import { createElement } from '.../../../node_modules/@syncfusion/ej2-base';
import { data } from '../../../spec/grid/base/datasource.spec';
import { orderData } from '../../grid/columnspanning/datasource';

Grid.Inject(Page, Selection, Filter, Group, Sort, Toolbar, Edit, Aggregate, RowDD, ColumnChooser, Reorder)

let grid: Grid = new Grid({
    dataSource: orderData,
    toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel', 'ColumnChooser'],
    allowPaging: true,
    allowReordering: true,
    allowRowDragAndDrop: true,
    showColumnChooser: true,
    pageSettings: { pageCount: 2, pageSize: 2 },
    allowGrouping: true,
    selectionSettings: { type:'Multiple', enableSimpleMultiRowSelection: true},
    allowSorting: true,
    sortSettings: { columns: [{ field: 'OrderID', direction: 'Ascending' }, { field: 'ShipCity', direction: 'Descending' }] },
    allowFiltering: true,
    filterSettings: { type: 'Excel', columns: [{ field: 'ShipCity', matchCase: false, operator: 'startswith', predicate: 'and', value: 'M' }]},
    editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' },
    groupSettings: { columns: ['ShipCity'] },
    dataBound: function(){
        grid.selectRow(1);
    },
    columns: [
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120 },
        { field: 'ShipCity', headerText: 'Ship City', width: 150 },
        { field: 'Freight', headerText: 'Freight($)', textAlign: 'Right', width: 120, format: 'C2' },
    ],
    aggregates: [{
        columns: [{
            type: 'Sum',
            field: 'Freight',
            format: 'C2',
            groupFooterTemplate: 'Sum: ${Sum}'
        }]
    },
    {
        columns: [{
            type: 'Sum',
            field: 'Freight',
            format: 'C2',
            footerTemplate: 'Sum: ${Sum}'
        }]
    },
    {
        columns: [{
            type: 'Max',
            field: 'Freight',
            groupCaptionTemplate: 'Max: ${Max}'
        }]
    }],

})
grid.appendTo('#Grid');