import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate, Edit, ExcelExport, PdfExport, } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';
import { data } from '../../../spec/grid/base/datasource.spec';
import '../../../node_modules/es6-promise/dist/es6-promise';

Grid.Inject(Page, Selection, Aggregate, Filter, Group, Sort, Toolbar, Edit, ExcelExport, PdfExport, );

let grid: Grid = new Grid({
    dataSource: data.slice(0,3),
    enableHover: false,
    frozenColumns: 2,
    allowExcelExport: true,
    allowPdfExport: true,
    allowFiltering: true,
    filterSettings: {showFilterBarOperator: true},
    toolbar: ['Add', 'Delete', 'Update', 'Cancel', 'ExcelExport', 'PdfExport', 'CsvExport'],
    editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' },
    selectionSettings: { cellSelectionMode: 'Box', type: 'Multiple', mode: 'Cell' },
    columns: [
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120 },
        { field: 'CustomerID', headerText: 'Customer ID', width: 150 },
        { field: 'ShipCity', headerText: 'Ship City', width: 150 },
    ],
    height: 315,
        dataBound: function(){
            grid.selectCell({ rowIndex: 0, cellIndex: 0 }, false);
    }
    });
    grid.appendTo('#Grid');
    grid.toolbarClick = (args: ClickEventArgs) => {
        if (args.item.id === 'Grid_pdfexport') {
            grid.pdfExport();
        }
        if (args.item.id === 'Grid_excelexport') {
            grid.excelExport();
        }
        if (args.item.id === 'Grid_csvexport') {
            grid.csvExport();
        }
    };
