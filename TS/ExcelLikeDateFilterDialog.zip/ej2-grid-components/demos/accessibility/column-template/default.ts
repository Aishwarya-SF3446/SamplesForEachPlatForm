import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate, ColumnChooser } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import { data, employeeData } from '../../../spec/grid/base/datasource.spec';
import '../../../node_modules/es6-promise/dist/es6-promise';
import { DataManager, Query } from '@syncfusion/ej2-data';

Grid.Inject(Page, Selection, Aggregate, Filter, Group, Sort, Toolbar, ColumnChooser)

let flag : boolean = true;
let grid: Grid = new Grid({
    dataSource: new DataManager(employeeData as JSON[]).executeLocal(new Query().take(3)),
    showColumnChooser: true,
    toolbar: ['ColumnChooser'],
    columns: [
        {
            headerText: 'Employee Image', textAlign: 'Center',
            template: '#template', width: 180
        },
        { field: 'EmployeeID', headerText: 'Employee ID', textAlign: 'Right', width: 125 },
        {
            field: 'HireDate', headerText: 'Hire Date', textAlign: 'Right',
            width: 135, format: { skeleton: 'yMd', type: 'date' }
        },
    ],
    width: 'auto',
    dataBound:(e:any)=> { 
        if(flag){
            setTimeout(() => {
                document.getElementById('Grid_columnchooser').click();
            }, 10);
        }
        flag = false;
    }
});
grid.appendTo('#Grid');