import { Page, Selection, Resize  } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import '../../../node_modules/es6-promise/dist/es6-promise';
import { orderData } from '../../grid/columnspanning/datasource';

Grid.Inject(Page, Selection, Resize)
let grid: Grid = new Grid(
    {
        dataSource: orderData.slice(0,3),
        allowResizing: true,
        columns: [
            { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120, minWidth: 10 },
            {
                headerText: 'Order Details', columns: [
                    { field: 'OrderDate', headerText: 'Order Date', textAlign: 'Right', width: 135, format: 'yMd', minWidth: 10 },
                    { field: 'Freight', headerText: 'Freight($)', textAlign: 'Right', width: 120, format: 'C2', minWidth: 10 },
                ]
            },
            {
                headerText: 'Ship Details', columns: [
                    { field: 'ShippedDate', headerText: 'Shipped Date', textAlign: 'Right', width: 145, format: 'yMd', minWidth: 10},
                    { field: 'ShipCountry', headerText: 'Ship Country', width: 140, minWidth: 10 },
                ]
            }
        ]
    });
grid.appendTo('#Grid');