import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import { data, employeeData } from '../../../spec/grid/base/datasource.spec';
import '../../../node_modules/es6-promise/dist/es6-promise';
import { Internationalization } from '@syncfusion/ej2-base';

Grid.Inject(Page, Selection, Aggregate, Filter, Group, Sort, Toolbar)

let instance: Internationalization = new Internationalization();
(window as DateFormat).format = (value: Date) => {
    return instance.formatDate(value, { skeleton: 'yMd', type: 'date' });
};

interface DateFormat extends Window {
    format?: Function;
}

let grid: Grid = new Grid({
    dataSource: employeeData.slice(0,3),
    rowTemplate: '#rowtemplate',
    columns: [
        { headerText: 'Employee Image', width: 150, textAlign: 'Center', field: 'OrderID' },
        { headerText: 'Employee Details', width: 300, field: 'EmployeeID' }
    ],
});
grid.appendTo('#Grid');
