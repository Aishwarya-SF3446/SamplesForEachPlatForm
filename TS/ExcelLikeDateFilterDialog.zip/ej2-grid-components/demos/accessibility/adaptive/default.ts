import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate, Edit } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import { Browser } from '@syncfusion/ej2-base';
import { orderData } from '../../grid/columnspanning/datasource';

Grid.Inject(Page, Filter, Sort, Edit, Toolbar, Aggregate, Selection, Group);

let grid: Grid = new Grid(
    {
        dataSource: orderData.slice(0, 12),
        rowRenderingMode: 'Vertical',
        enableAdaptiveUI: true,
        allowPaging: true,
        allowSorting: true,
        allowFiltering: true,
        filterSettings: { type: 'Excel' },
        pageSettings: { pageSize: 3 },
        height: '100%',
        load: () => {
            if (!Browser.isDevice) {
                grid.adaptiveDlgTarget = document.getElementsByClassName('e-mobile-content')[0] as HTMLElement;
            }
        },
        editSettings: { allowAdding: true, allowEditing: true, allowDeleting: true, mode: 'Dialog' },
        toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel', 'Search'],
        columns: [
            {
                field: 'OrderID', headerText: 'Order ID', width: 180, isPrimaryKey: true,
                validationRules: { required: true, number: true }
            },
            { field: 'Freight', width: 180, format: 'C2', editType: 'numericedit', validationRules: { required: true, number: true } },
            { field: 'CustomerName', headerText: 'Name', width: 180, validationRules: { required: true } },
        ],
        aggregates: [{
            columns: [{
                type: 'Sum',
                field: 'Freight',
                format: 'C2',
                footerTemplate: 'Sum: ${Sum}'
            }]
        }]
    });
if (Browser.isDevice) {
    grid.appendTo('#adaptivedevice');
    (document.getElementsByClassName('e-mobile-layout')[0] as HTMLElement).style.display = 'none';
} else {
    grid.appendTo('#adaptivebrowser');
}
