import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate } from '../../../src/index';
import { AggregateColumn } from '../../../src/grid/models/aggregate'
import { GridActionEventArgs } from '../../../src/grid/base/interface';
import { Grid } from '../../../src/grid/base/grid';
import { createElement } from '.../../../node_modules/@syncfusion/ej2-base';
import { data } from '../../../spec/grid/base/datasource.spec';

Grid.Inject(Page, Selection, Aggregate, Filter, Group, Sort, Toolbar)

let flag: boolean = true;
let grid: Grid = new Grid({
    dataSource: data.slice(0,3),
    enableRtl: true,
    allowFiltering: true,
    filterSettings: {type:'CheckBox'},
    toolbar: ['Search'],
    searchSettings: { fields: ['ShipCity'], operator: 'contains', key: 'a', ignoreCase: true },
    columns: [
        { type: 'checkbox', width: 50 },
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120 },
        { field: 'ShipCity', headerText: 'Ship City', width: 150 },
    ],
    dataBound: onDataBound
})
grid.appendTo('#Grid');
function onDataBound(): void {
    if(flag){
        (document.querySelectorAll(".e-filtermenudiv")[0] as HTMLElement).click(); 
    }
    flag = false;
}