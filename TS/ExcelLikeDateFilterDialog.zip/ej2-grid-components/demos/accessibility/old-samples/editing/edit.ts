import { Page, Selection, Filter, Toolbar, Sort, Group, Aggregate, Edit } from '../../../../src/index';
import { AggregateColumn } from '../../../../src/grid/models/aggregate'
import { GridActionEventArgs } from '../../../../src/grid/base/interface';
import { Grid } from '../../../../src/grid/base/grid';
import { createElement } from '.../../../node_modules/@syncfusion/ej2-base';
import { data } from '../../../../spec/grid/base/datasource.spec';
import '../../../node_modules/es6-promise/dist/es6-promise';

Grid.Inject(Page, Selection, Aggregate, Filter, Group, Sort, Toolbar, Edit)
let grid: Grid = new Grid({
    dataSource: data.slice(0,10),
     editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal', showConfirmDialog: false, showDeleteConfirmDialog: false },
                    toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
                    allowPaging: false,
                    columns: [
                        { field: 'OrderID', type: 'number', isPrimaryKey: true, visible: true, validationRules: { required: true } },
                        { field: 'CustomerID', type: 'string' },
                        { field: 'EmployeeID', type: 'number', allowEditing: false },
                        { field: 'Freight', format: 'C2', type: 'number', editType: 'numericedit' },
                        { field: 'ShipCity' },
                        { field: 'ShipAddress', allowFiltering: true, visible: false }
                    ],
                  dataBound:()=>{ 
                      (grid as any).dblClickHandler({ target: grid.element.querySelectorAll('.e-row')[1].firstElementChild });
                      (grid.element.querySelector('#' + grid.element.id + 'CustomerID') as any).value = 'updated';
                      (grid.element.querySelectorAll('.e-row')[2] as any).cells[0].click();
}
})
grid.appendTo('#Grid');
