import { Page, Selection, DetailRow, Sort, Filter } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import '../../../node_modules/es6-promise/dist/es6-promise';
import { employeeData, hierarchyOrderdata } from '../../../spec/grid/base/datasource.spec';
import { data, customerData, orderData } from '../../grid/foreignkey/datasource';
import { DataManager, ODataAdaptor, ODataV4Adaptor } from '@syncfusion/ej2-data';
import { ClickEventArgs } from '@syncfusion/ej2-navigations';



Grid.Inject(Page, Selection, DetailRow, Sort, Filter);

let flag = true;
let dataManger: Object = new DataManager({
    url: 'https://services.odata.org/V4/Northwind/Northwind.svc/Orders',
    adaptor: new ODataV4Adaptor,
    crossDomain: true
});
let dataManger2: Object = new DataManager({
    url: 'https://services.odata.org/V4/Northwind/Northwind.svc/Customers',
    adaptor: new ODataV4Adaptor,
    crossDomain: true
});

let grid: Grid = new Grid({
    dataSource: employeeData.slice(0,2),
    allowFiltering: true,
    filterSettings: { type: 'Menu' },
    columns: [
        { field: 'EmployeeID', headerText: 'Employee ID', textAlign: 'Right', width: 125 },
        { field: 'FirstName', headerText: 'Name', width: 125 },
    ],
    dataBound: onDataBound,
    childGrid: {
        dataSource: hierarchyOrderdata,
        queryString: 'EmployeeID',
        columns: [
            { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120 },
            { field: 'ShipCity', headerText: 'Ship City', width: 120 },
        ],
        childGrid: {
            dataSource: customerData,
            queryString: 'CustomerID',
            columns: [
                { field: 'CustomerID', headerText: 'Customer ID', textAlign: 'Right', width: 75 },
                { field: 'Phone', headerText: 'Phone', width: 100 },
            ]
        }
    }
});
grid.appendTo('#Grid');

function onDataBound(): void {
    this.detailRowModule.expand(1);
    if (flag) {
        (document.querySelectorAll(".e-filtermenudiv")[0] as HTMLElement).click();
    }
    flag = false;
}

