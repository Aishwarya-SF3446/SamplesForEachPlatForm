import { Page, QueryCellInfoEventArgs, Selection } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import '../../../node_modules/es6-promise/dist/es6-promise';
import { columnSpanData, ColumnSpanDataType } from '../../grid/columnspanning/datasource';

Grid.Inject(Page, Selection)
let grid: Grid = new Grid(
    {
        dataSource: columnSpanData.slice(0,5),
        queryCellInfo: QueryCellEvent,
        gridLines: 'Both',
        allowSelection: false,
        columns: [
            { field: 'EmployeeID', headerText: 'Employee ID', isPrimaryKey: true, textAlign: 'Right', width: 150 },
            { field: 'EmployeeName', headerText: 'Employee Name', width: 200 },
            { field: '9:00', headerText: '9.00 AM', width: 120 },
            { field: '9:30', headerText: '9.30 AM', width: 120 },
            { field: '10:00', headerText: '10.00 AM', width: 120 },
            { field: '10:30', headerText: '10.30 AM', width: 120 },
        ],
        allowTextWrap: true,
    });
grid.appendTo('#Grid');


function QueryCellEvent(args: QueryCellInfoEventArgs): void {
let data: ColumnSpanDataType = args.data as ColumnSpanDataType;
switch (data.EmployeeID) {
        case 10001:
            if (args.column.field === '9:00' || args.column.field === '2:30') {
                args.colSpan = 2;
            } else if (args.column.field === '11:00') {
                args.colSpan = 3;
            } else if (args.column.field === '1:00') {
                args.colSpan = 3;
                args.rowSpan = 10;
            } else if (args.column.field === '4:30') {
                args.colSpan = 2;
                args.rowSpan = 2;
            } else if (args.column.field === 'EmployeeName') {
                 args.rowSpan = 2;
             }
            break;
        case 10002:
            if (args.column.field === '9:30') {
                args.colSpan = 3;
            } else if (args.column.field === '11:00') {
                args.colSpan = 4;
            } else if (args.column.field === '2:30') {
                args.colSpan = 2;
                args.rowSpan = 5;
            } else if (args.column.field === '3:30') {
                args.colSpan = 2;
            }
            break;
        case 10003:
            if (args.column.field === '9:00') {
                args.colSpan = 3;
                args.rowSpan = 2;
            } else if (args.column.field === '10:30' || args.column.field === '3:30' || args.column.field === '4:30') {
                args.colSpan = 2;
            } else if (args.column.field === '11:30') {
                args.colSpan = 3;
            }
            break;
        case 10004:
            if (args.column.field === '11:00') {
                args.colSpan = 4;
            } else if (args.column.field === '4:00') {
                args.colSpan = 2;
            }
            break;
        case 10005:
            if (args.column.field === '9:00') {
                args.colSpan = 4;
            } else if (args.column.field === '11:30') {
                args.colSpan = 3;
            } else if (args.column.field === '3:30') {
                args.colSpan = 2;
                args.rowSpan = 2;
            } else if (args.column.field === '4:30') {
                args.colSpan = 2;
            }
            break;
    }
}
