import { Page, Selection, Sort, Freeze, Resize, Edit, Toolbar } from '../../../src/index';
import { Grid } from '../../../src/grid/base/grid';
import { data } from '../../../spec/grid/base/datasource.spec';
import '../../../node_modules/es6-promise/dist/es6-promise';

Grid.Inject(Page, Selection, Sort, Freeze, Resize, Edit, Toolbar);

var flag = true;
let grid: Grid = new Grid({
    dataSource: data.slice(0,3),
    toolbar: ['Add', 'Edit', 'Delete'],
    selectionSettings: { type: 'Multiple', mode: 'Both', persistSelection: true },
    editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Dialog' },
    columns: [
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 100, isPrimaryKey: true },
        { field: 'CustomerID', headerText: 'Customer ID', width: 120, },
        { field: 'Freight', headerText: 'Freight', textAlign: 'Right', editType: 'numericedit', width: 120, format: 'C2' },
    ],
    height: 265,
    dataBound:()=> { 
        if(flag){
            grid.selectRow(2);
            (<any>grid.toolbarModule).toolbarClickHandler({ item: { id: grid.element.id + '_edit' } });
        }
        flag = false;
    }
});
grid.appendTo('#Grid');