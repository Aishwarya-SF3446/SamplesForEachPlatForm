import { Page } from '../../../src/grid/actions/page';
import { Grid } from '../../../src/grid/base/grid';
import { orderData } from '../../grid/columnspanning/datasource';

Grid.Inject(Page);

let flag: boolean = true;
let grid: Grid = new Grid({
    dataSource: orderData,
    columns: [
        { field: 'OrderID', headerText: 'Order ID', width: 100, textAlign: 'Right' },
        { field: 'CustomerID', headerText: 'Customer Name', width: 120 },
    ],
    dataBound: (e: any) => {
        if (flag) {
            grid.goToPage(4);
        }
        flag = false;
    },
    width: 'auto',
    allowPaging: true,
    pageSettings: { pageCount: 3, pageSize: 2},
});
grid.appendTo('#Grid');