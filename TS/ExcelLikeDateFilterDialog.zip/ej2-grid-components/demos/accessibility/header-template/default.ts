import { Grid } from '../../../src/grid/base/grid';
import { employeeData } from '../../../spec/grid/base/datasource.spec';
import { Page, Selection, Filter, Toolbar, CommandColumn, Edit } from '../../../src/index';

Grid.Inject(Page, Selection, Filter, Toolbar, CommandColumn, Edit)

let grid: Grid = new Grid({
    dataSource: employeeData.slice(0, 3),
    editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
    columns: [
        { field: 'EmployeeID', headerText: 'Employee ID', width: 120, isPrimaryKey: true, textAlign: 'Right', headerTemplate: '#employeetemplate' },
        { field: 'FirstName', headerText: 'First Name', width: 140 },
        {
            field: 'BirthDate', headerText: 'Birth Date', width: 130, format: 'yMd',
            textAlign: 'Right', headerTemplate: '#datetemplate', editType: 'datetimepickeredit',
        },
        {
            headerText: 'Commands', width: 120, commands: [{ type: 'Edit', buttonOption: { cssClass: 'e-flat', iconCss: 'e-edit e-icons' } },
            { type: 'Delete', buttonOption: { cssClass: 'e-flat', iconCss: 'e-delete e-icons' } },
            { type: 'Save', buttonOption: { cssClass: 'e-flat', iconCss: 'e-update e-icons' } },
            { type: 'Cancel', buttonOption: { cssClass: 'e-flat', iconCss: 'e-cancel-icon e-icons' } }]
        }
    ],
});
grid.appendTo('#Grid');