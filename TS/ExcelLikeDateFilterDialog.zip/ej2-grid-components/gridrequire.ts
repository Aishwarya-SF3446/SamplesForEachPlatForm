import {
    enableRipple,
    closest,
    Browser,
    Internationalization,
    select,
    removeClass,
    detach,
  } from "@syncfusion/ej2-base";
  enableRipple(true);
  
  import { Grid , } from "./src/grid/base/grid";
  import {
    Aggregate,
    
    ColumnChooser,
    createCboxWithWrap,
    dataBound,
    DetailRow,
    DialogEditEventArgs,
    ExcelExport,
    ExcelExportProperties,
    ExcelFilterBase,
    ForeignKey,
    Freeze,
    getPredicates,
    getUid,
    InfiniteScroll,
    LazyLoadGroup,
    Pager,
    PdfExport,
    PdfExportProperties,
    PredicateModel,
    QueryCellInfoEventArgs,
    resetRowIndex,
    Resize,
    RowDD,
    rowDeselected,
    Search,
    Selection
  } from "./src/index";
  import { VirtualScroll } from "./src/grid/actions/virtual-scroll";
  import { Page } from "./src/grid/actions/page";
  import { Group } from "./src/grid/actions/group";
  import { Filter } from "./src/grid/filter";
  import { Sort } from "./src/grid/sort";
  import { Reorder } from "./src/grid/actions/reorder";
  import { Toolbar } from "./src/grid/actions/toolbar";
  import {
    Query,
    DataManager,
    ODataAdaptor,
    WebApiAdaptor,
    UrlAdaptor,
    ODataV4Adaptor,
    RemoteSaveAdaptor,
    DataUtil,
    JsonAdaptor,
    Predicate,
  } from "@syncfusion/ej2-data";
  import { Edit } from "./src/grid/actions/edit";
  import { ColumnMenu } from "./src/grid/actions/column-menu";
  import { CheckBox } from "@syncfusion/ej2-buttons";
  import { CommandColumn } from "./src/grid/command-column";
  import { Column } from "./src/grid/models/column";
  import { Button } from "@syncfusion/ej2-buttons";
  import { Dialog, Tooltip } from "@syncfusion/ej2-popups";
  import { DropDownTree, DropDownList, AutoComplete } from "@syncfusion/ej2-dropdowns";
  import { FormValidator, NumericTextBox } from "@syncfusion/ej2-inputs";
  import { orderData, productData } from "./demos/grid/columnspanning/datasource";
  //import {orderData, inventoryData, orderDetails, virtualData, dataSource, lazyLoadData, createLazyLoadData, categoryData, columnSpanData, ColumnSpanDataType, data, orderDataSource } from "./datasource";
  import { DatePicker } from "@syncfusion/ej2-calendars";
import { data } from "./datasource";
import { ContextMenu } from "./src/grid/context-menu";
import { NodeClickEventArgs, NodeKeyPressEventArgs, TreeView } from "@syncfusion/ej2-navigations";
//import { data } from "./datasource";
  
  Grid.Inject(
    Page,
    Group,
    Resize,
    Reorder,
    Freeze,
    LazyLoadGroup,
    Toolbar,
    ColumnChooser,
    Sort,
    Filter,
    ColumnMenu,
    ContextMenu,
    RowDD,
    DetailRow,
    Search,
    Aggregate,
    ExcelExport,
    PdfExport,
    Toolbar,
    Edit,
    VirtualScroll,
    InfiniteScroll,
    Selection,
    CommandColumn
  );

  let grid: Grid = new Grid(
    {
        dataSource: orderData.slice(0, 100),
        allowPaging: true,
        allowFiltering: true,
        allowSorting: true,
        filterSettings: { type: 'Excel' },
        columns: [
            { field: 'OrderID', headerText: 'Order ID', width: 120, textAlign: 'Right' },
            { field: 'CustomerID', headerText: 'Customer Name', width: 150, },
            { field: 'OrderDate', headerText: 'Order Date', width: 130, format: 'yMd', textAlign: 'Right' },
            { field: 'Freight', width: 120, format: 'C2', textAlign: 'Right' },
            { field: 'ShipCountry', headerText: 'Ship Country', width: 150 }
        ]

    });
grid.appendTo('#Grid');

// beforeCustomFilterOpen event gets trigger before the opening of filter menu which a internal event.

grid.on('beforeCheckboxfilterRenderer', filtercheckboxrender);

function filtercheckboxrender(args?: any) {
    if (args.column.type === 'date') {
        let checkedNodes: string[] = [];
        const allNodes: string[] = [];
        const idColl: { [key: string]: boolean } = {};
        let groupedYears: { [key: string]: Object }[] = [];
        let groupedMonths: { [key: string]: Object }[] = [];
        let groupedData: { [key: string]: Object }[] = [];
        let otherData: { [key: string]: Object }[] = [];
        let value: string; let month: string; let day: number; let date: Date; let mId: string; let dId: string; let monthNum: number;
        const months: string[] = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
            'November', 'December'];
        let grpObj: { [key: string]: Object };
        let indeterminate: boolean = false;
        args.element.innerHTML = '';
        args.isCheckboxFilterTemplate = true;
        const addNodes: (data: any) => void = (data: any): void => {
            idColl[`${dId}`] = true;
            let target = data[args.column.field];
            let filteredResults: any = grid.getFilteredRecords();
            let isPresent: any;
            if (filteredResults.length) {
                isPresent = filteredResults.some(function (obj: any) {
                    return obj[args.column.field] === target;
                });
            }
            if (filteredResults.length && !isPresent) {
                indeterminate = true;
            } else {
                checkedNodes.push(dId);
            }
            allNodes.push(dId);
        };
        args.dataSource.forEach((data: { [key: string]: Object }): void => {
            date = data[args.column.field] as Date;
            if (typeof date === 'object' && !!Date.parse(date.toString())) {
                value = date.getFullYear().toString();
                if (!idColl[`${value}`]) {
                    grpObj = { __rowIndex: value, hasChild: true };
                    grpObj[args.column.field] = value;
                    groupedYears.push(grpObj);
                    idColl[`${value}`] = true;
                }
                monthNum = date.getMonth();
                month = months[monthNum as number];
                mId = value + ' ' + month;
                if (!idColl[`${mId}`]) {
                    grpObj = { __rowIndex: mId, pId: value, hasChild: true, month: monthNum };
                    grpObj[args.column.field] = month;
                    groupedMonths.push(grpObj);
                    idColl[`${mId}`] = true;
                }
                day = date.getDate();
                dId = mId + ' ' + day.toString();
                if (!idColl[`${dId}`]) {
                    grpObj = { __rowIndex: dId, pId: mId };
                    grpObj[args.column.field] = day;
                    groupedData.push(grpObj);
                    addNodes(data);
                }
            } else {
                if (!data[args.column.field] && data[args.column.field] !== 0) {
                    dId = 'blanks';
                    value = 'Blanks';
                } else {
                    dId = 'text ' + data[args.column.field].toString().toLowerCase();
                    value = <string>data[args.column.field];
                }
                if (!idColl[`${dId}`]) {
                    grpObj = { __rowIndex: dId };
                    grpObj[args.column.field] = value;
                    otherData.push(grpObj);
                    addNodes(data);
                }
            }
        });
        groupedYears = new DataManager(
            groupedYears).executeLocal(new Query().sortBy(args.column.field, 'decending')) as { [key: string]: Object }[];
        groupedMonths = new DataManager(
            groupedMonths).executeLocal(new Query().sortBy('month', 'ascending')) as { [key: string]: Object }[];
        groupedData = new DataManager(
            groupedData).executeLocal(new Query().sortBy(args.column.field, 'ascending')) as { [key: string]: Object }[];
        groupedData = groupedYears.concat(groupedMonths.concat(groupedData));
        if (otherData.length) {
            otherData = new DataManager(
                otherData).executeLocal(new Query().sortBy(args.column.field, 'ascending')) as { [key: string]: Object }[];
            groupedData = groupedData.concat(otherData);
        }
        // Handling click event with the nodes of the TreeView component
        const nodeClick: Function = (args: NodeKeyPressEventArgs | NodeClickEventArgs): void => {
            const checkedNode: HTMLLIElement[] = [args.node];
            if ((args.event.target as Element).classList.contains('e-fullrow') || (args.event as any).key === 'Enter') {
                const getNodeDetails: { [key: string]: Object } = treeViewObj.getNode(args.node);
                if (getNodeDetails.isChecked === 'true') {
                    treeViewObj.uncheckAll(checkedNode);
                } else {
                    treeViewObj.checkAll(checkedNode);
                }
            }
        };
        // Triggers when the selectAll checkbox is clicked
        const selectAllClick: Function = (): void => {
            cBox.indeterminate = false;
            if (cBoxFrame.classList.contains('e-check')) {
                treeViewObj.uncheckAll();
                cBoxFrame.classList.add('e-uncheck');
                cBox.checked = false;
            } else {
                treeViewObj.checkAll();
                cBoxFrame.classList.add('e-check');
                cBox.checked = true;
            }
        };
        let excelFilter = grid.filterModule.filterModule.excelFilterBase;
        const selectAllObj: { [key: string]: Object } = {};
        selectAllObj[args.column.field] = 'SelectAll';
        const selectAll: Element = createCboxWithWrap(
            getUid('cbox'), (excelFilter as any).createCheckbox(selectAllObj[args.column.field], false, selectAllObj), 'e-ftrchk');
        selectAll.addEventListener('click', selectAllClick.bind(this));
        selectAll.classList.add('e-spreadsheet-ftrchk');
        const cBoxFrame: Element = selectAll.querySelector('.e-frame');
        cBoxFrame.classList.add('e-selectall');
        args.element.appendChild(selectAll);
        const cBox: HTMLInputElement = selectAll.querySelector('.e-chk-hidden') as HTMLInputElement;
        const treeViewEle: HTMLElement = grid.createElement('div');
        const treeViewObj: TreeView = new TreeView({
            fields: { dataSource: groupedData, id: '__rowIndex', parentID: 'pId', text: args.column.field, hasChildren: 'hasChild' },
            enableRtl: grid.enableRtl, showCheckBox: true, cssClass: 'e-checkboxtree', checkedNodes: checkedNodes,
            nodeClicked: nodeClick.bind(this),
            keyPress: nodeClick.bind(this),
            nodeChecked: (e: any): void => {
                if (e.action !== 'indeterminate') {
                    indeterminate = treeViewObj.checkedNodes.length !== (treeViewObj.fields.dataSource as Object[]).length;
                    updateState(args, cBoxFrame, cBox, indeterminate, treeViewObj.checkedNodes.length);
                }
            }
        });
        treeViewObj.createElement = grid.createElement;
        treeViewObj.appendTo(treeViewEle);
        args.element.appendChild(treeViewEle);
        checkedNodes = treeViewObj.checkedNodes;
        updateState(args, cBoxFrame, cBox, indeterminate, treeViewObj.checkedNodes.length);
        // To handle the button clicks of the filterDialog
        const applyBtnClickHandler: Function = (): void => {
            if (treeViewObj.checkedNodes.length === groupedData.length) {
                let options = grid.filterModule.filterModule.excelFilterBase.options;
                const isClearFilter: boolean = options.filteredColumns.some((value: PredicateModel) => {
                    return options.field === value.field;
                });
                if (isClearFilter) {
                    grid.filterModule.filterModule.excelFilterBase.clearFilter();
                }
            } else {
                generatePredicate(
                    treeViewObj.checkedNodes, otherData.length ? 'string' : args.type, args.column.field, excelFilter, allNodes,
                    treeViewObj.checkedNodes.length > groupedData.length / 2);
            }
        };
        this.treeViewObj = treeViewObj;
        this.treeViewEle = treeViewEle;
        this.cBox = cBox;
        wireFilterEvents(args, applyBtnClickHandler, refreshCheckbox.bind(this, groupedData, treeViewObj, checkedNodes));
    }
}
// Updates the state of checkboxes
function updateState(
    args: any, cBoxFrame: Element, cBox: HTMLInputElement, indeterminate: boolean, checkedCount: number): void {
    removeClass([cBoxFrame], ['e-check', 'e-stop', 'e-uncheck']);
    if ((args.btnObj.element as HTMLButtonElement).disabled) {
        (args.btnObj.element as HTMLButtonElement).disabled = false;
    }
    if (indeterminate) {
        if (checkedCount) {
            cBoxFrame.classList.add('e-stop');
        } else {
            cBoxFrame.classList.add('e-uncheck');
            const addCurCbox: Element = args.element.querySelector('.e-add-current');
            (args.btnObj.element as HTMLButtonElement).disabled = !addCurCbox || !addCurCbox.classList.contains('e-check');
        }
    } else {
        cBoxFrame.classList.add('e-check');
    }
    cBox.indeterminate = indeterminate;
    cBox.checked = !indeterminate;

}
// Creating predicates based on the selected value to perform filtering.
function generatePredicate(
    checkedNodes: string[], type: string, field: string, excelFilter: ExcelFilterBase, allNodes: string[], isNotEqual: boolean): void {
    const predicates: PredicateModel[] = [];
    let predicate: any;
    const months: { [key: string]: number } = {
        'January': 0, 'February': 1, 'March': 2, 'April': 3, 'May': 4, 'June': 5, 'July': 6,
        'August': 7, 'September': 8, 'October': 9, 'November': 10, 'December': 11
    };
    let valArr: string[]; let date: Date; let val: string | number; let otherType: string;
    const updateOtherPredicate: Function = (): void => {
        if (valArr[0] === 'blanks') {
            predicates.push(Object.assign({ value: '', type: type }, predicate));
        } else if (valArr[0] === 'text') {
            valArr.splice(0, 1);
            val = valArr.join(' ');
            if (isNaN(Number(val))) {
                otherType = 'string';
            } else {
                val = Number(val);
                otherType = 'number';
            }
            predicates.push(Object.assign({ value: val, type: otherType }, predicate));
        }
    };
    const setDate: () => void = (): void => {
        date = new Date(Number(valArr[0]), months[valArr[1]], Number(valArr[2]));
        if (date.getDate()) {
            predicates.push(Object.assign({ value: date, type: type }, predicate));
        } else {
            updateOtherPredicate();
        }
    };
    if (isNotEqual) {
        predicate = {
            field: field, ignoreAccent: false, matchCase: false, predicate: 'and', operator: 'notequal',
            isFilterByMenu: true
        };
        for (let i: number = 0, len: number = allNodes.length; i < len; i++) {
            if (checkedNodes.indexOf(allNodes[i as number]) === -1) {
                valArr = allNodes[i as number].split(' ');
                setDate();
            }
        }
    } else {
        predicate = { field: field, ignoreAccent: false, matchCase: false, predicate: 'or', operator: 'equal', isFilterByMenu: true };
        for (let i: number = 0, len: number = checkedNodes.length; i < len; i++) {
            valArr = checkedNodes[i as number].split(' ');
            if (valArr.length === 3) {
                setDate();
            } else {
                updateOtherPredicate();
            }
        }
    }
    excelFilter.initiateFilter(predicates);
}
// Handling of events in the TreeView component.
function wireFilterEvents(args: any, applyBtnClickHandler: Function, refreshCheckboxes: Function): void {
    args.btnObj.element.addEventListener('click', applyBtnClickHandler.bind(this));
    (args as { searchBox?: Element }).searchBox.addEventListener('keydown', (e: KeyboardEvent): void => {
        if (e.keyCode === 13) {
            applyBtnClickHandler();
        }
    });
    const filterDlgCloseHandler: Function = (): void => {
        grid.off('refreshCheckbox', refreshCheckboxes);
        grid.off('filterDialogClose', filterDlgCloseHandler);
        grid.element.focus();
    };
    grid.on('filterDialogClose', filterDlgCloseHandler, this);
    grid.on('refreshCheckbox', refreshCheckboxes, this);
}
// Updates the checkboxes based on the search value.
function refreshCheckbox(
    groupedData: { [key: string]: Object }[], treeViewObj: TreeView, checkedNodes: string[], args: { event: KeyboardEvent }): void {
    let searchValue: string;
    if (args.event.type === 'keyup') {
        searchValue = (args.event.target as HTMLInputElement).value;
    } else if ((args.event.target as Element).classList.contains('e-search-icon')) {
        return;
    }
    let filteredList: Object[];
    const changeData: Function = (): void => {
        if (filteredList.length && !(treeViewObj.fields.dataSource as Object[]).length) {
            const wrapper: Element = treeViewObj.element.parentElement;
            wrapper.getElementsByClassName('e-spreadsheet-ftrchk')[0].classList.remove('e-hide');
            detach(wrapper.getElementsByClassName('e-checkfltrnmdiv')[0]);
        }
        treeViewObj.fields.dataSource = <{ [key: string]: Object }[]>filteredList;
        treeViewObj.dataBind();
    };
    if (searchValue) {
        filteredList = new DataManager(groupedData).executeLocal(new Query().where(
            new Predicate(treeViewObj.fields.text, 'contains', searchValue, true)));
        const filterId: { [key: string]: boolean } = {}; const predicates: Predicate[] = []; let key: string; let initList: Object[];
        const strFilter: boolean = isNaN(Number(searchValue));
        let expandId: string[]; let level: number;
        if (strFilter) {
            for (let i: number = 0; i < filteredList.length; i++) {
                if (!filteredList[i as number]['hasChild']) {
                    continue;
                }
                predicates.push(new Predicate('pId', 'equal', filteredList[i as number]['__rowIndex'], false));
                key = filteredList[i as number]['pId'];
                if (!filterId[`${key}`]) {
                    predicates.push(new Predicate('__rowIndex', 'equal', key, false));
                    filterId[`${key}`] = true;
                }
            }
            initList = filteredList;
            level = 1;
        } else {
            let year: string; const filterParentId: { [key: string]: boolean } = {}; expandId = [];
            for (let i: number = 0; i < filteredList.length; i++) {
                key = filteredList[i as number]['pId'];
                if (key) {
                    year = key.split(' ')[0];
                    if (!filterId[`${key}`]) {
                        predicates.push(new Predicate('__rowIndex', 'equal', key, false));
                        filterId[`${key}`] = true;
                        expandId.push(year);
                        expandId.push(key);
                    }
                    if (!filterParentId[`${year}`]) {
                        if (!filterId[`${year}`]) {
                            predicates.push(new Predicate('__rowIndex', 'equal', year, false));
                            filterId[`${year}`] = true;
                        }
                        predicates.push(new Predicate('__rowIndex', 'equal', filteredList[i as number]['__rowIndex'], false));
                    }
                } else {
                    key = filteredList[i as number]['__rowIndex'];
                    if (!filterParentId[`${key}`]) {
                        predicates.push(new Predicate('__rowIndex', 'contains', key, false));
                        filterParentId[`${key}`] = true;
                    }
                }
            }
            initList = [];
        }
        if (filteredList.length) {
            if (predicates.length) {
                filteredList = initList.concat(new DataManager(groupedData).executeLocal(new Query().where(Predicate.or(predicates))));
            }
            changeData();
            treeViewObj.checkAll();
            const duration: number = treeViewObj.animation.expand.duration;
            treeViewObj.animation.expand.duration = 0;
            treeViewObj.expandAll(expandId, level);
            treeViewObj.animation.expand.duration = duration;
        } else if ((treeViewObj.fields.dataSource as Object[]).length) {
            changeData();
            const wrapper: Element = treeViewObj.element.parentElement;
            wrapper.getElementsByClassName('e-spreadsheet-ftrchk')[0].classList.add('e-hide');
            const noRecordEle: Element = grid.createElement('div', { className: 'e-checkfltrnmdiv' });
            const noRecordText: HTMLElement = grid.createElement('span');
            noRecordText.innerText = 'No matches found';
            noRecordEle.appendChild(noRecordText);
            wrapper.appendChild(noRecordEle);
        }
    } else {
        filteredList = groupedData;
        changeData();
        treeViewObj.checkedNodes = checkedNodes;
        treeViewObj.dataBind();
    }
}