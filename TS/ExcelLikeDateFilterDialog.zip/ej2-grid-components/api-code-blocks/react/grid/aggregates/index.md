```tsx
import { AggregateColumnDirective, ColumnDirective, ColumnsDirective, GridComponent, Inject,AggregateColumnsDirective, AggregateDirective, AggregatesDirective, Aggregate } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}>{
  public footerSum(props: any) : any {
    return(<span>Sum: {props.Sum}</span>)
  }
  public render(){
      return <GridComponent  dataSource={data}>
                <ColumnsDirective>
                  <ColumnDirective field='OrderID' headerText='Order ID' textAlign='Right'/>
                  <ColumnDirective field='Freight' headerText='Freight' textAlign='Right'/>
              </ColumnsDirective>
              <AggregatesDirective>
                <AggregateDirective>
                  <AggregateColumnsDirective>
                    <AggregateColumnDirective field='Freight' type='Sum' footerTemplate={this.footerSum} />
                  </AggregateColumnsDirective>
                </AggregateDirective>
              </AggregatesDirective>
              <Inject services={[Aggregate]}/>
          </GridComponent>
      } }
```