```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent, Inject, InfiniteScroll, InfiniteScrollSettingsModel } from '@syncfusion/ej2-react-grids';
import { data } from './data';

export default class App extends React.Component<{}, {}> {
    public infiniteOptions: InfiniteScrollSettingsModel = { enableCache: true, maxBlocks: 3, initialBlocks: 3 };
    public render() {
        return (
          <GridComponent dataSource={data} height="300" enableInfiniteScrolling={true} infiniteScrollSettings={ this.infiniteOptions } pageSettings={ { pageSize: 50 } }>
            <Inject services={[InfiniteScroll]}/>
          </GridComponent>);
    }
}
```