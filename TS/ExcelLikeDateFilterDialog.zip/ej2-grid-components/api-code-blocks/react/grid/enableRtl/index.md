```tsx
import { ColumnDirective, ColumnsDirective, GridComponent } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}>{
  public render(){
      return <GridComponent  dataSource={data} enableRtl={true}>
                <ColumnsDirective>
                  <ColumnDirective field='OrderID' headerText='Order ID' textAlign='Right'/>
                  <ColumnDirective field='CustomerID' headerText='CustomerID'/>
              </ColumnsDirective>
          </GridComponent>
} }
```