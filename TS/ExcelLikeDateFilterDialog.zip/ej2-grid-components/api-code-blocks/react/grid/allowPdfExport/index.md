```tsx
import { PdfExport, Grid, Inject, Toolbar, GridComponent, ToolbarItems } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}> {
  public toolbar: ToolbarItems[] = ['PdfExport'];
  public render() {
    return (
        <GridComponent dataSource={data} toolbar={this.toolbar} allowPdfExport={true} >
        <Inject services={[Toolbar, PdfExport]}/>
      </GridComponent>
    ); } }
```