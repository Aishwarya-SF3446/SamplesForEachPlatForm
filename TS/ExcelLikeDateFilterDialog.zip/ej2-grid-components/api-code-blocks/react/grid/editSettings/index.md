```tsx
import { Edit, EditSettingsModel, Inject, GridComponent,Toolbar,ToolbarItems} from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}> {
  public editOptions: EditSettingsModel = { allowEditing: true, allowAdding: true, allowDeleting: true };
   public toolbarOptions: ToolbarItems[] = ['Add', "Delete", "Edit"];
  public render() {
    return <GridComponent dataSource={data} editSettings={this.editOptions} toolbar={this.toolbarOptions} >
        <Inject services={[Edit,Toolbar]} />
    </GridComponent>
  } }
```