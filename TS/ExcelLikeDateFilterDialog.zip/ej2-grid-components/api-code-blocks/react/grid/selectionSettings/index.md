```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent, SelectionSettingsModel } from '@syncfusion/ej2-react-grids';
import { data } from './data';

export default class App extends React.Component<{}, {}> {
    public selectionOptions: SelectionSettingsModel = { mode: 'Cell', cellSelectionMode: 'Box', type: 'Multiple' };
    public render() {
        return (<GridComponent dataSource={data}  selectionSettings={this.selectionOptions} />);
    }
}
```