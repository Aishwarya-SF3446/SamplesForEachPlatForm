```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent, Inject, Toolbar } from '@syncfusion/ej2-react-grids';
import { data } from './data';

export default class App extends React.Component<{}, {}> {
    public render() {
        return (
          <GridComponent dataSource={data} toolbar={['Search','Print']}>
            <Inject services={[Toolbar]}/>
          </GridComponent>);
    }
}
```