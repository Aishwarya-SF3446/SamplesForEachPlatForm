```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent, ColumnsDirective, ColumnDirective, Group, Inject } from '@syncfusion/ej2-react-grids';
import { data } from './data';

export default class App extends React.Component<{}, {}> {
    public render() {
        return (
          <GridComponent dataSource={data} allowGrouping={true} groupSettings={{ columns: ['Freight'] }}>
            <ColumnsDirective>
              <ColumnDirective field='CustomerName' headerText='Customer Name' width='150'></ColumnDirective>
              <ColumnDirective field='Freight' headerText='Freight' width='120' format='C2' textAlign='Right'></ColumnDirective>
            </ColumnsDirective>
            <Inject services={[Group]}/>
          </GridComponent>);
    }
}
```