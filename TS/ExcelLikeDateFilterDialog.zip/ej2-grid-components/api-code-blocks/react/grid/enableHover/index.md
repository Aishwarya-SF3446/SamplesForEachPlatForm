```tsx
import {GridComponent } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}>{
  public render() {
    return <GridComponent dataSource={data} enableHover={true} />  
     } };
```