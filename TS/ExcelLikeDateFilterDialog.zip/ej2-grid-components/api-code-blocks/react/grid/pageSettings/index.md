```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent, Inject, Page, PageSettingsModel } from '@syncfusion/ej2-react-grids';
import { data } from './data';

export default class App extends React.Component<{}, {}> {
    public pageOptions: PageSettingsModel = { currentPage: 1, pageSize: 12, pageCount: 8, pageSizes: true };
    public render() {
        return (
          <GridComponent dataSource={data} allowPaging={true} pageSettings={this.pageOptions}>
            <Inject services={[Page]}/>
          </GridComponent>);
    }
}
```