```tsx
import { ColumnDirective, ColumnsDirective, GridComponent } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { inventoryData } from './datasource';

export default class App extends React.Component<{}, {}>{
  public render() {
    return (
    <GridComponent dataSource={inventoryData}>
        <ColumnsDirective>
            <ColumnDirective field='Inventor' headerText='Name of the Inventor' clipMode='Clip' />
            <ColumnDirective field='NumberofPatentFamilies' headerText='Number of Patent Families' clipMode='Ellipsis' />
        </ColumnsDirective>
    </GridComponent> 
    ) } };
```