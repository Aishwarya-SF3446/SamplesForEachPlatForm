```tsx
import { render, } from 'react-dom';
import React, { Component } from 'react';
import { GridComponent, Page, PageEventArgs, Inject } from '@syncfusion/ej2-react-grids';
import { data } from './dataSource';

export default class App extends React.Component<{}, {}>{
  // For Paging action 
  actionBegin(args: PageEventArgs) {
    alert(args.requestType);
  }
  public render() {
    return (<GridComponent dataSource={data} allowPaging={true} actionBegin={this.actionBegin}>
       <Inject services={[Page]} />
    </GridComponent>
    )
  }
};
```