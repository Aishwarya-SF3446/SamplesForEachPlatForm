```tsx
import { render, } from 'react-dom';
import React, { Component } from 'react';
import { GridComponent, ColumnsDirective, ColumnDirective, Grid, Edit, EditSettingsModel, Inject } from '@syncfusion/ej2-react-grids';
import { data } from './dataSource';

export default class App extends React.Component<{}, {}>{
  public grid: Grid | null;
  public editOptions: EditSettingsModel = { allowEditing: true, allowAdding: true, mode: 'Batch' };

  click() {
    // Update a specified row by given options
    this.grid.updateRow(1, { OrderID: 10248, CustomerID: 'HANAR', ShipCountry: 'Germany' });
  }

  public render() {
    return (
      <div>
        <button onClick={this.click.bind(this)}>Click</button>
        <GridComponent dataSource={data} editSettings={this.editOptions} ref={g => this.grid = g}>
          <ColumnsDirective>
            <ColumnDirective field='OrderID' isPrimaryKey={true} width='100' textAlign="Right" />
            <ColumnDirective field='CustomerID' width='100' />
            <ColumnDirective field='ShipCountry' width='100' />
          </ColumnsDirective>
          <Inject services={[Edit]} />
        </GridComponent>
      </div>
    )
  }
};
```