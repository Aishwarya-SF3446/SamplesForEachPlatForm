```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent } from '@syncfusion/ej2-react-grids';
import { DataManager, ODataAdaptor, Query } from '@syncfusion/ej2-data';

export default class App extends React.Component<{}, {}> {
    public data = new DataManager({
        adaptor: new ODataAdaptor,
        url: 'https://js.syncfusion.com/demos/ejServices/Wcf/Northwind.svc/Orders/'
    });
    public query = new Query().addParams('ej2grid', 'true');
    public render() {
        return (<GridComponent dataSource={data} query={this.query} />);
    }
}
```