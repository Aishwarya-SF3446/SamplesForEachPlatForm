```tsx
import { Freeze, FilterSettingsModel, GridComponent, Inject } from '@syncfusion/ej2-react-grids'
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}>{
  public render() {
      return <GridComponent dataSource={data} frozenColumns={1} >
          <Inject services={[Freeze]} />
      </GridComponent>
  } };
```