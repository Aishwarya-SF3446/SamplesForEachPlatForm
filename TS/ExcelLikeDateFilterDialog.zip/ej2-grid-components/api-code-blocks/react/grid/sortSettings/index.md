```tsx
import { render } from 'react-dom';
import * as React from 'react';
import { GridComponent, ColumnsDirective, ColumnDirective, Inject, Sort, SortSettingsModel } from '@syncfusion/ej2-react-grids';
import { data } from './data';

export default class App extends React.Component<{}, {}> {
    public sortingOptions: SortSettingsModel = { columns: [{ field: 'CustomerName', direction: 'Ascending' }] };
    public render() {
        return (
          <GridComponent dataSource={data} allowSorting={true} sortSettings={this.sortingOptions}>
            <ColumnsDirective>
              <ColumnDirective field='CustomerName' headerText='Customer Name' width='150'></ColumnDirective>
              <ColumnDirective field='Freight' headerText='Freight' width='120' format='C2' textAlign='Right'></ColumnDirective>
            </ColumnsDirective>
            <Inject services={[Sort]} />
          </GridComponent>);
    }
}
```