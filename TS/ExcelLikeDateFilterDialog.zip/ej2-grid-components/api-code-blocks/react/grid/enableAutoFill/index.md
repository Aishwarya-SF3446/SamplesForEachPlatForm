```tsx
import {GridComponent, SelectionSettingsModel } from '@syncfusion/ej2-react-grids';
import * as React from 'react';
import { data } from './datasource';
export default class App extends React.Component<{}, {}>{
  public settings: SelectionSettingsModel = { cellSelectionMode: 'Box', mode: 'Cell'};
  public render() {
    return <GridComponent dataSource={data} enableAutoFill={true} selectionSettings={this.settings} />  
     } };
```