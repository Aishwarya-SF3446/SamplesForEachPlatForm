```tsx
import { render, } from 'react-dom';
import React, { Component } from 'react';
import { GridComponent, ColumnDirective, ColumnsDirective, Grid, Group, GroupSettingsModel, Inject } from '@syncfusion/ej2-react-grids';
import { data } from './dataSource';

export default class App extends React.Component<{}, {}>{
  public grid: Grid | null;
  public groupOptions: GroupSettingsModel = { columns: ["CustomerID"] };

  click() {
    // Ungroup a column by field name.
    this.grid.ungroupColumn('CustomerID');
  }

  public render() {
    return (
      <div>
        <button onClick={this.click.bind(this)}>Click</button>
        <GridComponent dataSource={data} allowGrouping={true} groupSettings={this.groupOptions} ref={g => this.grid = g}>
          <ColumnsDirective>
            <ColumnDirective field='OrderID' headerText='Order ID' width='100' textAlign="Right" />
            <ColumnDirective field='CustomerID' headerText='Customer ID' width='100' />
            <ColumnDirective field='ShipCountry' headerText='Ship Country' width='100' />
          </ColumnsDirective>
          <Inject services={[Group]} />
        </GridComponent>
      </div>
    )
  }
};
```