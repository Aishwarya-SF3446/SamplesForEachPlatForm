```html
<template>
    <ejs-grid :dataSource='data' :toolbar='toolbarOptions'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Toolbar } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      toolbarOptions: ['Search','Print']
    };
  },
  provide: { grid: [Toolbar] }
}
</script>
```