```html
<template>
    <ejs-grid :dataSource='data' :allowSorting='true' :sortSettings='sortOptions' >
        <e-columns>
            <e-column field='OrderID' headerText='Order ID' textAlign='right' width=120></e-column>
            <e-column field='Freight' format='C2' width=150 textAlign='right'></e-column>
        </e-columns>
    </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Sort } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      sortOptions: { columns: [{ field: 'OrderID', direction: 'Ascending' }] }
    };
  },
  provide: { grid: [Sort] }
}
</script>
```