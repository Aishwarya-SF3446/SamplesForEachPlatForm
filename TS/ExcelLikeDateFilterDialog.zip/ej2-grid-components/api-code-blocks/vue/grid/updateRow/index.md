```html
<template>
  <div id="app">
    <button v-on:click="click">Click</button>
    <ejs-grid ref="grid" :dataSource='data' :editSettings='editSettings' height='270'>
            <e-columns>
                <e-column field='OrderID' headerText='Order ID' textAlign='Right' :isPrimaryKey='true' width=100></e-column>
                <e-column field='CustomerID' headerText='Customer ID' width=120></e-column>
                <e-column field='ShipCountry' headerText='Ship Country' width=150></e-column>
            </e-columns>
        </ejs-grid>
  </div>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Edit  } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";

Vue.use(GridPlugin);

export default {
  data() {
    return {
      data: data,
      editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: "Batch" },
    };
  },
  methods: {
    click: function(args) {
    // Update a specified row by given options
    this.$refs.grid.ej2Instances.updateRow(1, { OrderID: 10248, CustomerID: 'HANAR', ShipCountry: 'Germany' });
    }
  },
  provide: {
    grid: [Edit ]
  }
};
</script>
```