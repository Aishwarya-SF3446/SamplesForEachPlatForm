```html
<template>
    <ejs-grid :dataSource='data' :showColumnChooser='true' :toolbar='toolbarOptions'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, ColumnChooser, Toolbar } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      toolbarOptions: ['ColumnChooser']
    };
  },
  provide: { grid: [ColumnChooser, Toolbar] }
}
</script>
```