```html
<template>
    <ejs-grid :dataSource='data' :query='query'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin } from "@syncfusion/ej2-vue-grids";
import { DataManager, ODataAdaptor, Query } from "@syncfusion/ej2-data";

Vue.use(GridPlugin);
export default {
  data() {
    let SERVICE_URI = "https://js.syncfusion.com/demos/ejServices/Wcf/Northwind.svc/Orders?$top=7";
    return {
      data: new DataManager({
        url: SERVICE_URI,
        adaptor: new ODataAdaptor()
      }),
      query: new Query().addParams('ej2grid', 'true');
    };
  },
}
</script>
```