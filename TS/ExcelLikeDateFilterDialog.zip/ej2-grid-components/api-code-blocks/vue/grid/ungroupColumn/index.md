```html
<template>
  <div id="app">
    <button v-on:click="click">Click</button>
    <ejs-grid ref="grid" :dataSource="data" allowGrouping="true" :groupSettings='groupOptions' height="270">
      <e-columns>
        <e-column field="OrderID" headerText="Order ID" textAlign="Right" width="100"></e-column>
        <e-column field="CustomerID" headerText="Customer ID" width="120"></e-column>
        <e-column field="ShipCountry" headerText="Ship Country" width="150"></e-column>
      </e-columns>
    </ejs-grid>
  </div>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Group } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";

Vue.use(GridPlugin);

export default {
  data() {
    return {
      data: data,
      groupOptions: {columns: ['CustomerID']}
    };
  },
  methods: {
    click: function(args) {
      // Ungroup a column by field name.
      this.$refs.grid.ej2Instances.ungroupColumn("CustomerID");
    }
  },
  provide: {
    grid: [Group]
  }
};
</script>
```