```html
<template>
    <ejs-grid :dataSource='data' :selectionSettings='selectionOptions'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      selectionOptions: { mode: 'Cell', cellSelectionMode: 'Box', type: 'Multiple' }
    };
  },
}
</script>
```