```html
<template>
  <ejs-grid :dataSource="data" :frozenColumns=2 ></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Freeze } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data,
    }; },
  provide: { grid: [Freeze] }
};
</script>
```