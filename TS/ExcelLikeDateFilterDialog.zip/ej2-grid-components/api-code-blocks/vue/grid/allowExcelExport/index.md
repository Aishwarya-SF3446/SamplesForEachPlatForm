```html
<template>
  <div id="app">
    <ejs-grid ref="grid" id="Grid" :dataSource="data" :toolbar="toolbarOptions" :allowExcelExport="true">
    </ejs-grid>
  </div>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Toolbar, ExcelExport } from "@syncfusion/ej2-vue-grids";
import { orderData } from "./dataSource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: orderData,
      toolbarOptions: ["ExcelExport"]
    };
  },
  provide: { grid: [Toolbar, ExcelExport] }
};
</script>
```