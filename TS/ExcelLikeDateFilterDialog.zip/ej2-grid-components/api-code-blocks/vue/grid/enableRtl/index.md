```html
<template>
  <ejs-grid :dataSource="data" :enableRtl="true">
   <e-columns>
     <e-column field='OrderID' headerText='Order ID' textAlign='right'></e-column>
     <e-column field='CustomerID' headerText='CustomerID'></e-column>
   </e-columns></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data
    }; }
};
</script>
```