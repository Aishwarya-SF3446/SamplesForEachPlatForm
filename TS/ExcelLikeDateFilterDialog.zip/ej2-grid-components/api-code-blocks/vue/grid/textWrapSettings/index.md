```html
<template>
    <ejs-grid :dataSource='data' :allowTextWrap='true' :textWrapSettings='textOption'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      textOption:  { wrapMode: 'Both' },
    };
  },
}
</script>
```