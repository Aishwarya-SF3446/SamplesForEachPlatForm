```html
<template>
  <ejs-grid :dataSource="data" :editSettings="editSettings" :toolbar="toolbar"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Edit, Toolbar } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data,
      editSettings: {allowEditing: true, allowAdding: true, allowDeleting: true },
      toolbar: ["Add", "Edit", "Delete", "Update", "Cancel"]
    }; },
  provide: { grid: [Edit, Toolbar] }
};
</script>
```