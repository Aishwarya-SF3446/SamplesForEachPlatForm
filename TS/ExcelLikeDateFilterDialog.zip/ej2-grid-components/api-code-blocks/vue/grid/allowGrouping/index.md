```html
<template>
  <ejs-grid :dataSource="data" :allowGrouping="true"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Group  } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data
    };
  },
  provide: { grid: [Group ] }
};
</script>
```