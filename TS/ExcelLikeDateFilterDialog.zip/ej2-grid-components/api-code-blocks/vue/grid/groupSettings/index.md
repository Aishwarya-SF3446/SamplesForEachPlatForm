```html
<template>
    <ejs-grid :dataSource='data' :allowGrouping='true' :groupSettings='groupOptions'>
        <e-columns>
            <e-column field='OrderID' headerText='Order ID' textAlign='right' width=120></e-column>
            <e-column field='Freight' format='C2' width=150 textAlign='right'></e-column>
        </e-columns>
    </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Group } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      groupOptions: { columns: ['Freight'] }
    };
  },
  provide: { grid: [Group] }
}
</script>
```