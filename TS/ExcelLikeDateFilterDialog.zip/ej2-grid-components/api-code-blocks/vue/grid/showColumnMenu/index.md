```html
<template>
    <ejs-grid :dataSource='data' :showColumnMenu='true'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, ColumnMenu } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
    };
  },
  provide: { grid: [ColumnMenu] }
}
</script>
```