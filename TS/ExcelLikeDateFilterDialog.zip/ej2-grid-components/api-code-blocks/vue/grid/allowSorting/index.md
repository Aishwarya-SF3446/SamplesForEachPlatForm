```html
<template>
  <ejs-grid :dataSource="data" :allowSorting="true"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Sort } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data
    }; },
  provide: { grid: [Sort] }
};
</script>
```