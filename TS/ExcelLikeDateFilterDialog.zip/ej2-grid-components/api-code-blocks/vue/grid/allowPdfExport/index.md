```html
<template>
<ejs-grid :dataSource="data" :toolbar="toolbarOptions" :allowPdfExport="true"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Toolbar, PdfExport } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data,
      toolbarOptions: ["PdfExport"]
    }; },
  provide: { grid: [Toolbar, PdfExport] }
};
</script>
```