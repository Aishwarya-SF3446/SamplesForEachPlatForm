```html
<template>
        <ejs-grid :dataSource='data'>
            <e-columns>
                <e-column field='OrderID' headerText='Order ID' textAlign='right' width=120></e-column>
                <e-column field='Freight' format='C2' width=150 textAlign='right'></e-column>
            </e-columns>
            <e-aggregates>
                <e-aggregate>
                    <e-columns>
                        <e-column format='C2' type="Sum" field="Freight" :footerTemplate='footerSum'></e-column>
                    </e-columns>
                </e-aggregate>
          </e-aggregates>
        </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Aggregate } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      footerSum: function () {
        return  { template : Vue.component('sumTemplate', {template: `<span>Sum: {{data.Sum}}</span>`, data () {return { data: {}}; }})
          }}};
  },
  provide: { grid: [Aggregate] }
}
</script>
```