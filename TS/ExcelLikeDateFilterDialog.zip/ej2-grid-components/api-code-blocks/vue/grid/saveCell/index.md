```html
<template>
  <div id="app">
    <button v-on:click="edit">EditCell</button>
    <button v-on:click="save">SaveCell</button>
    <ejs-grid ref="grid" id='Grid' :dataSource='data' :editSettings='editSettings' height='270'>
            <e-columns>
                <e-column field='OrderID' textAlign='Right' :isPrimaryKey='true' width=100></e-column>
                <e-column field='CustomerID' width=120></e-column>
            </e-columns>
        </ejs-grid>
  </div>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Edit  } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";

Vue.use(GridPlugin);

export default {
  data() {
    return {
      data: data,
      editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: "Batch" },
    };
  },
  methods: {
    save: function(args) {
    // Save the cell that is currently edited
   this.$refs.grid.ej2Instances.saveCell();
    },
    edit: function(args) {
    // Edit a cell with row index and field name
    this.$refs.grid.ej2Instances.editCell(2, 'CustomerID');
    // Here "Grid" is id
   this.$refs.grid.ej2Instances.element.querySelector('#GridCustomerID').value = 'HANAR';
    },
  },
  provide: {
    grid: [Edit ]
  }
};
</script>
```