```html
<template>
  <div id="app">
    <ejs-grid :dataSource="data" allowPaging="true" :actionBegin="actionBegin"></ejs-grid>
  </div>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Page } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";

Vue.use(GridPlugin);

export default {
  data() {
    return {
      data: data
    };
  },
  methods: {
    actionBegin: args => {
      console.log(args.requestType);
    }
  },
  provide: {
    grid: [Page]
  }
};
</script>
```