```html
<template>
  <ejs-grid :dataSource="data" :allowFiltering="true" :filterSettings="filterOptions"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Filter } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data,
      filterOptions: { type: "Menu" }
    }; },
  provide: { grid: [Filter] }
};
</script>
<style>
@import "../node_modules/@syncfusion/ej2-vue-grids/styles/material.css";
</style>
```