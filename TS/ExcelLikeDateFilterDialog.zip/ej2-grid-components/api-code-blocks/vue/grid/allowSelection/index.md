```html
<template>
  <ejs-grid :dataSource="data" :allowSelection="true"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data
    }; },
};
</script>
</script>
```