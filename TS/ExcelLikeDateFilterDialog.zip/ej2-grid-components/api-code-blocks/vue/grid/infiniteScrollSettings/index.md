```html
<template>
   <ejs-grid :dataSource='data' height=300 :enableInfiniteScrolling='true' :pageSettings='pageOptions' :infiniteScrollSettings='infiniteOptions'>
   </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, InfiniteScroll } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      pageOptions: { pageSize: 50 },
      infiniteScrollSettings: { enableCache: true, maxBlocks: 3, initialBlocks: 3 }
    };
  },
  provide: { grid: [InfiniteScroll] }
}
</script>
```