```html
<template>
    <ejs-grid :dataSource='data' printMode='CurrentPage' :allowPaging="true" :toolbar='toolbarOptions'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Page, Toolbar } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      toolbarOptions: ['Print'],
    };
  },
  provide: { grid: [Page, Toolbar] }
}
</script>
```