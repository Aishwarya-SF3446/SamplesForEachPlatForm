```html
<template>
  <ejs-grid :dataSource="data" :allowRowDragAndDrop="true"></ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, RowDD  } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";
Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: data
    };  },
  provide: { grid: [RowDD ] }
};
</script>
<style>
@import "../node_modules/@syncfusion/ej2-vue-grids/styles/material.css";
</style>
</script>
```