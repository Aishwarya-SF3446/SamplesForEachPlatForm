```html
<template>
  <div id="app">
    <button v-on:click="click">Click</button>
    <ejs-grid ref="grid" :dataSource='data' :editSettings='editSettings' height='270'>
            <e-columns>
                <e-column field='OrderID' textAlign='Right' :isPrimaryKey='true' width=100></e-column>
                <e-column field='CustomerID' headerText='Customer ID' width=120></e-column>
                <e-column field='ShipCountry' headerText='Ship Country' width=150></e-column>
            </e-columns>
        </ejs-grid>
  </div>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Edit  } from "@syncfusion/ej2-vue-grids";
import { data } from "./datasource";

Vue.use(GridPlugin);

export default {
  data() {
    return {
      data: data,
      editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true },
    };
  },
  methods: {
    click: function(args) {
    // Select Row in given index
    this.$refs.grid.ej2Instances.selectRow(1)
    // Edit the seleted row
    this.$refs.grid.ej2Instances.startEdit();
    }
  },
  provide: {
    grid: [Edit ]
  }
};
</script>
```