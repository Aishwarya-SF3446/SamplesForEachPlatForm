```html
<template>
    <ejs-grid :dataSource='data' :allowPaging="true" :pageSettings='pageOptions'> </ejs-grid>
</template>
<script>
import Vue from "vue";
import { GridPlugin, Page } from "@syncfusion/ej2-vue-grids";
import { gridData } from './data';

Vue.use(GridPlugin);
export default {
  data() {
    return {
      data: gridData,
      pageOptions: { currentPage: 1, pageSize: 12, pageCount: 8, pageSizes: true },
    };
  },
  provide: { grid: [Page] }
}
</script>
```