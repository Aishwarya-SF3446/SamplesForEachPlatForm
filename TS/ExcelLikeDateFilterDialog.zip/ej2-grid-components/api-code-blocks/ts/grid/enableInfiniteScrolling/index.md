```html
<div id='Grid'></grid>
```
```ts
import { Grid, InfiniteScroll} from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(InfiniteScroll);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    enableInfiniteScrolling: true,
    height: 300,   
  });
grid.appendTo('#Grid');
```