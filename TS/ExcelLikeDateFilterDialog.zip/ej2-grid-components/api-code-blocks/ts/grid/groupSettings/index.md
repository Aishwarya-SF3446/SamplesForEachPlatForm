```html
<div id='Grid'></grid>
```
```ts
import { Grid, Group } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Group);
let grid: Grid = new Grid({
    dataSource: data,
    allowGrouping: true,
    groupSettings: { columns: ['Freight'] },
    columns: [
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120 },
        { field: 'Freight', headerText: 'Freight', width: 150, textAlign: 'Right', format:'C2' },
    ],
});
grid.appendTo('#Grid');
```