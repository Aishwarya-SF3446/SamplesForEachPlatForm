```html
<div id='Grid'></grid>
```
```ts
import { Grid } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
let grid: Grid = new Grid({
    dataSource: data,
    allowTextWrap: true,
    textWrapSettings: { wrapMode: 'Both' },
});
grid.appendTo('#Grid');
```