```html
<div id='Grid'></grid>
```
```ts
import { Grid, Toolbar, ExcelExport } from '@syncfusion/ej2-grids';
import { orderDetails } from './data-source';
Grid.Inject(Toolbar, ExcelExport);
let grid: Grid = new Grid(
  {
    dataSource: orderDetails,
    allowExcelExport: true,
    toolbar: ['ExcelExport'],
  });
grid.appendTo('#Grid');
```