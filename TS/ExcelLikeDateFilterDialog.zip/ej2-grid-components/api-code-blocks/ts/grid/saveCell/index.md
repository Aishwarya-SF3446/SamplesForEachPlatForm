```html
<button id="edit"> Update Cell</button>
<button id="save"> Save Cell</button>
<div id="Grid"></div>
```

```ts
import { Grid, Edit } from '@syncfusion/ej2-grids';
import { Button } from "@syncfusion/ej2-buttons";
import { data } from './data-source';

Grid.Inject(Edit);

let grid: Grid = new Grid({
  dataSource: data,
  editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' },
  columns: [
    { field: 'OrderID', textAlign: 'Right', width: 100, isPrimaryKey: true },
    { field: 'CustomerID', width: 120, }
  ]
});
grid.appendTo("#Grid");

let save: Button = new Button();
save.appendTo("#save");

save.element.onclick = (): void => {
  // Save the cell that is currently edited
  grid.saveCell();
};

let update: Button = new Button();
update.appendTo("#edit");

update.element.onclick = (): void => {
  // Edit the specified cell
  grid.editCell(1, 'CustomerID');
  (grid.element.querySelector('#GridCustomerID') as HTMLInputElement).value = 'HANAR';
};
```