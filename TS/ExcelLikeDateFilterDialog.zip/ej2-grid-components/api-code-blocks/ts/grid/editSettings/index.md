```html
<div id='Grid'></grid>
```
```ts
import { Grid, Toolbar, Edit } from '@syncfusion/ej2-grids';
import { data } from './data-source';
Grid.Inject(Toolbar,Edit);
let grid: Grid = new Grid({
    dataSource: data,
    toolbar: ['Add', 'Edit', 'Delete', 'Update', 'Cancel'],
    editSettings: { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Normal' },
});
grid.appendTo('#Grid');
```