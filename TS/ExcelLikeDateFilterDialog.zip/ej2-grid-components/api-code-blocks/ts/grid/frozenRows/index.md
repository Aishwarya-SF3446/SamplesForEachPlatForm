```html
<div id='Grid'></grid>
```
```ts
import { Grid, Freeze } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Freeze);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    frozenRows: 2,
  });
grid.appendTo('#Grid');
```