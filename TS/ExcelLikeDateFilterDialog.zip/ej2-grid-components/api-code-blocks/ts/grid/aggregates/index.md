```html
<div id='Grid'></grid>
```
```ts
import { Grid, Aggregate } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Aggregate);
let grid: Grid = new Grid({
    dataSource: data,
    columns: [
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right', width: 120 },
        { field: 'Freight', headerText: 'Freight', width: 150, textAlign: 'Right', format:'C2' },
    ],
    aggregates: [{
        columns: [{type: 'Sum',field: 'Freight',format: 'C2',footerTemplate: 'Sum: ${Sum}'}]
    }]
});
grid.appendTo('#Grid');
```