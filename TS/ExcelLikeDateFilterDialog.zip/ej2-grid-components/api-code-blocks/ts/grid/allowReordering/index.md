```html
<div id='Grid'></grid>
```
```ts
import { Grid, Reorder } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Reorder);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowReordering: true,
  });
grid.appendTo('#Grid');
```