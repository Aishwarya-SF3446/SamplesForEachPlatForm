```html
<div id='Grid'></grid>
```
```ts
import { Grid } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
let grid: Grid = new Grid({
    dataSource: data,
    selectedRowIndex: 5,
});
grid.appendTo('#Grid');
```