```html
<div id='Grid'></grid>
```
```ts
import { Grid, Group } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Group);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowGrouping: true,
  });
grid.appendTo('#Grid');
```
