```html
<div id='Grid'></grid>
```
```ts
import { Grid, Page, Toolbar } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Page,Toolbar);
let grid: Grid = new Grid({
    dataSource: data,
    toolbar: ['Print'],
    printMode: 'CurrentPage',
    allowPaging: true,
});
grid.appendTo('#Grid');
```