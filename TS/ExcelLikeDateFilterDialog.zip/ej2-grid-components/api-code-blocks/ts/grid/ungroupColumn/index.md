```html
<button id="btn"> UnGroup</button>
<div id="Grid"></div>
```

```ts
import { Grid, Group } from '@syncfusion/ej2-grids';
import { Button } from "@syncfusion/ej2-buttons";
import { data } from './data-source';

Grid.Inject(Group);

let grid: Grid = new Grid({
  dataSource: data,
  allowGrouping: true,
  groupSettings: { columns: ['CustomerID'] },
  columns: [{ field: 'OrderID', textAlign: 'Right' }, { field: 'CustomerID' }]
});
grid.appendTo("#Grid");

let button: Button = new Button();
button.appendTo("#btn");

button.element.onclick = (): void => {
  // Ungroup a column by field name.
  grid.ungroupColumn('CustomerID');
};
```