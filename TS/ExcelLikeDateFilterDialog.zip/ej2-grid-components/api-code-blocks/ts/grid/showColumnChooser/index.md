```html
<div id='Grid'></grid>
```
```ts
import { Grid, ColumnChooser, Toolbar } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(ColumnChooser, Toolbar);
let grid: Grid = new Grid({
    dataSource: data,
    toolbar: ['ColumnChooser'],
    showColumnChooser: true,
});
grid.appendTo('#Grid');
```