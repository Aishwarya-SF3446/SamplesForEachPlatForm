```html
<div id='Grid'></grid>
```
```ts
import { Grid, Sort } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Sort);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowSorting: true,
  });
grid.appendTo('#Grid');
```