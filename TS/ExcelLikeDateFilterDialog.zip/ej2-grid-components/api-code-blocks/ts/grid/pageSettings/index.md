```html
<div id='Grid'></grid>
```
```ts
import { Grid, Page } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Page);
let grid: Grid = new Grid({
    dataSource: data,
    allowPaging:true,
    pageSettings: { currentPage: 1, pageSize: 12, pageCount: 8, pageSizes: true },
});
grid.appendTo('#Grid');
```