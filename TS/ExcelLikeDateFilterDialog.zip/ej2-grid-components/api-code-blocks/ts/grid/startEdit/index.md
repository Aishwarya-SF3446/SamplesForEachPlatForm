```html
<button id="btn"> Start Edit </button>
<div id="Grid"></div>
```

```ts
import { Grid, Edit } from '@syncfusion/ej2-grids';
import { Button } from "@syncfusion/ej2-buttons";
import { data } from './data-source';

Grid.Inject(Edit);

let grid: Grid = new Grid({
  dataSource: data,
  editSettings: { allowEditing: true },
  columns: [{ field: 'OrderID', isPrimaryKey: true, textAlign: 'Right' }, { field: 'CustomerID' }]
});
grid.appendTo("#Grid");

let button: Button = new Button();
button.appendTo("#btn");

button.element.onclick = (): void => {
  // Select the row with 1 index
  grid.selectRow(1);
  // Edit the seleted row
  grid.startEdit();
};
```