```ts
import { Grid, Page, PageEventArgs } from '@syncfusion/ej2-grids';
import { orderDataSource } from './data-source';

Grid.Inject(Page);

let grid: Grid = new Grid({
  dataSource: orderDataSource,
  allowPaging: true,
  // For Paging action
  actionBegin: (args: PageEventArgs) => {
    console.log(args.requestType);
  }
});
grid.appendTo("#Grid");
```