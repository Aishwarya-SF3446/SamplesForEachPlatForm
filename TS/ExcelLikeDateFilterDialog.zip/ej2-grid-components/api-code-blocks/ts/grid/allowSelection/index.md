```html
<div id='Grid'></grid>
```
```ts
import { Grid, Selection  } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Selection );
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowSelection: true,
  });
grid.appendTo('#Grid');
```