```html
<div id='Grid'></grid>
```
```ts
import { Grid, Resize } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Resize );
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowResizing: true,
  });
grid.appendTo('#Grid');
```