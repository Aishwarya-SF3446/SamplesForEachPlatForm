```html
<div id='Grid'></grid>
```
```ts
import { Grid, InfiniteScroll } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(InfiniteScroll);
let grid: Grid = new Grid({
    dataSource: data,
    height: 300,
    pageSettings: { pageSize: 50 },
    enableInfiniteScrolling: true,
    infiniteScrollSettings: { enableCache: true, maxBlocks: 3, initialBlocks: 3 },
});
grid.appendTo('#Grid');
```