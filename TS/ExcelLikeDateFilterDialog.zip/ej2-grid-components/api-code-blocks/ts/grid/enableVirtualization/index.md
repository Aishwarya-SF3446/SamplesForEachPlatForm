```html
<div id='Grid'></grid>
```
```ts
import { Grid, VirtualScroll } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(VirtualScroll);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    enableVirtualization: true,
    height: 300  
  });
grid.appendTo('#Grid');
```