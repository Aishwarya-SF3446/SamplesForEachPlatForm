```html
<div id='Grid'></grid>
```
```ts
import { Grid, Search, Toolbar } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Search,Toolbar);
let grid: Grid = new Grid({
    dataSource: data,
    toolbar: ['Search'],
    searchSettings: { fields: ['CustomerID'], key: 'ha' },
    columns: [ 
        { field: 'CustomerID', headerText: 'Customer ID', width: 150 },
        { field: 'Freight', headerText: 'Freight', width: 150, textAlign: 'Right', format:'C2' },
    ]
});
grid.appendTo('#Grid');
```