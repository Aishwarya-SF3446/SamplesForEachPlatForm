```html
<div id='Grid'></grid>
```
```ts
import { Grid, RowDD  } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(RowDD );
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowRowDragAndDrop: true, 
  });
grid.appendTo('#Grid');
```