```html
<div id='Grid'></grid>
```
```ts
import { Grid, Toolbar, PdfExport } from '@syncfusion/ej2-grids';
import { orderDetails } from './data-source';
Grid.Inject(Toolbar, PdfExport);
let grid: Grid = new Grid(
  {
    dataSource: orderDetails,
    allowPdfExport: true,
    toolbar: ['PdfExport'],
  });
grid.appendTo('#Grid');
```