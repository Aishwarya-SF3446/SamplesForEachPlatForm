```html
<div id='Grid'></grid>
```
```ts
import { Grid, ColumnMenu } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(ColumnMenu);
let grid: Grid = new Grid({
    dataSource: data,
    showColumnMenu: true,
});
grid.appendTo('#Grid');
```