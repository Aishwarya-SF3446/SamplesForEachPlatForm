```html
<div id='Grid'></grid>
```
```ts
import { Grid } from '@syncfusion/ej2-grids';
import { data } from './data-source';
let grid: Grid = new Grid(
  {
    dataSource: data,
    columns: [
        { field: 'OrderID', headerText: 'Order ID', textAlign: 'Right'},
        { field: 'CustomerID', headerText: 'CustomerID', width: 150 },
    ],
    enableRtl: true,   
  });
grid.appendTo('#Grid');
```