```html
<div id='Grid'></grid>
```
```ts
import { Grid, Page } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
Grid.Inject(Page);
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    allowPaging: true,
  });
grid.appendTo('#Grid');
```