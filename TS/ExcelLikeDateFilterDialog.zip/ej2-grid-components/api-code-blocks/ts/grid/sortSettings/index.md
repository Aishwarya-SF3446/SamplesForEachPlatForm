```html
<div id='Grid'></grid>
```
```ts
import { Grid, Sort } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Sort);
let grid: Grid = new Grid({
    dataSource: data,
    allowSorting: true,
    sortSettings: { columns: [{ field: 'OrderID', direction: 'Ascending' }] },
    columns: [
        { field: 'CustomerID', headerText: 'Customer ID', width: 150 },
        { field: 'Freight', headerText: 'Freight', width: 150, textAlign: 'Right', format:'C2' },
    ]
});
grid.appendTo('#Grid');
```