```html
<button id="btn"> Update Row</button>
<div id="Grid"></div>
```

```ts
import { Grid, Edit } from '@syncfusion/ej2-grids';
import { Button } from "@syncfusion/ej2-buttons";
import { data } from './data-source';

Grid.Inject(Edit);

let grid: Grid = new Grid({
  dataSource: data,
  editSettings: { allowEditing: true, mode: 'Batch' },
  columns: [{ field: 'OrderID', isPrimaryKey: true, textAlign: 'Right' }, { field: 'CustomerID' }, { field: 'ShipCountry' }]
});
grid.appendTo("#Grid");

let button: Button = new Button();
button.appendTo("#btn");

button.element.onclick = (): void => {
  // Update a specified row by given options
  grid.updateRow(1, { OrderID: 10248, CustomerID: 'HANAR', ShipCountry: 'France' });
};
```