```html
<div id='Grid'></grid>
```
```ts
import { Grid } from '@syncfusion/ej2-grids';
import { categoryData } from './data-source';
let grid: Grid = new Grid(
  {
    dataSource: categoryData,
    clipMode: 'Ellipsis',
  });
grid.appendTo('#Grid');
```