```html
<div id='Grid'></grid>
```
```ts
import { Grid, Toolbar } from '@syncfusion/ej2-grids';
import { data } from './datasource.ts';
Grid.Inject(Toolbar);
let grid: Grid = new Grid({
    dataSource: data,
    toolbar: ['Search','Print'],
});
grid.appendTo('#Grid');
```