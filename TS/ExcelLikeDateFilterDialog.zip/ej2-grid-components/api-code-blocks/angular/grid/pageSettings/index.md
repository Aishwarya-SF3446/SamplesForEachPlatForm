```html
    <ejs-grid [dataSource]='data' [allowPaging]='true' [pageSettings]='pageOptions'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { PageService, PageSettingsModel } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
     providers: [PageService]
})
export class AppComponent {
    public data: Object[];
    public optiopageOptionsns: PageSettingsModel;
    public ngOnInit(): void {
        this.data = orderData;
        this.pageOptions = { currentPage: 1, pageSize: 12, pageCount: 8, pageSizes: true };
    }
}
```