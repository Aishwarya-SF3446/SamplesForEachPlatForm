```html
    <ejs-grid [dataSource]='data' [allowSorting]='true' [sortSettings]='sortOptions'>
        <e-columns>
            <e-column field='CustomerName' headerText='Customer Name' width='150'></e-column>
            <e-column field='Freight' headerText='Freight' width='150' format='C2' textAlign='Right'></e-column>
        </e-columns>
    </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { SortService } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers: [SortService]
})
export class AppComponent {
    public data: Object[];
    public sortOptions: object;
    public ngOnInit(): void {
        this.data = orderData;
        this.sortOptions = { columns: [{ field: 'CustomerName', direction: 'Ascending' }] };
    }
}
```