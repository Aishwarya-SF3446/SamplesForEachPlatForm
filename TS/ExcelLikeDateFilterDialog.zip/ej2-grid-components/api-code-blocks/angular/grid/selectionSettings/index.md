```html
    <ejs-grid [dataSource]='data' [selectionSettings]='selectionOptions'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { SelectionSettingsModel } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})
export class AppComponent {
    public data: Object[];
    public selectionOptions: SelectionSettingsModel;
    public ngOnInit(): void {
        this.data = orderData;
        this.selectionOptions = { mode: 'Cell', cellSelectionMode: 'Box', type: 'Multiple' };
    }
}
```