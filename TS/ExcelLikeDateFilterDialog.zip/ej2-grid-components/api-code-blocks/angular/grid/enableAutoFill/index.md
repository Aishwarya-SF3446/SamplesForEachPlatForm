```html
<ejs-grid [dataSource]="data" [enableAutoFill]="true" [selectionSettings]="selectionOptions" > </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { GridComponent,SelectionSettingsModel } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
})
export class AppComponent implements OnInit{
    public data: Object[];
    public selectionOptions: SelectionSettingsModel;
    public ngOnInit(): void {
        this.data = orderData;
        this.selectionOptions = { cellSelectionMode: 'Box', mode: 'Cell' };
    }
}
```