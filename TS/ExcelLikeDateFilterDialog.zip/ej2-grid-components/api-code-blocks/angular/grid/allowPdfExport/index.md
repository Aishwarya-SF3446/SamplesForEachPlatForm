```html
<ejs-grid [dataSource]='data' [toolbar]='toolbar' [allowPdfExport]='true'>
</ejs-grid>
```
```ts
import { Component, OnInit, ViewChild } from '@angular/core';
import { orderDetails } from './data';
import { GridComponent, ToolbarService, PdfExportService } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers: [ToolbarService, PdfExportService ]
})
export class AppComponent implements OnInit {
    public data: Object[];
    public toolbar: string[];
    public ngOnInit(): void { 
        this.data = orderDetails;
        this.toolbar = ['PdfExport'];
    }
}
```