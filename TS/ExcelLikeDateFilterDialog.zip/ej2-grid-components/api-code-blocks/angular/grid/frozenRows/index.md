```html
<ejs-grid [dataSource]="data" [frozenRows]='2' > </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { GridComponent,FreezeService } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers:[FreezeService]
})
export class AppComponent implements OnInit {
    public data: Object[];
    public ngOnInit(): void {
        this.data = orderData;
    }
}
```