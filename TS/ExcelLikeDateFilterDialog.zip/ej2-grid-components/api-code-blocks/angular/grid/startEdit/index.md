```html
    <button #addBtnObj cssClass='e-info' (click)='click()'> Click </button>
	<ejs-grid #grid [dataSource]='data' [editSettings]='editSettings'>
		<e-columns>
			<e-column field='OrderID' isPrimaryKey='true' textAlign='Right'>
			</e-column>
			<e-column field='CustomerID'></e-column>
		</e-columns>
	</ejs-grid>
```
```ts
import { Component, ViewChild, OnInit } from '@angular/core';
import { orderDetails } from './data';
import { GridComponent, EditService } from '@syncfusion/ej2-angular-grids'

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [EditService]
})
export class AppComponent {
  public data: Object[] = orderDetails;
  public editSettings: Object ={ allowEditing: true, allowAdding: true, allowDeleting: true };

  @ViewChild('grid')
  public grid: GridComponent;

  public click() {
    // Select the Row in 1 index
    this.grid.selectRow(1);
    // Edit the seleted row
    this.grid.startEdit();
  }
}
```