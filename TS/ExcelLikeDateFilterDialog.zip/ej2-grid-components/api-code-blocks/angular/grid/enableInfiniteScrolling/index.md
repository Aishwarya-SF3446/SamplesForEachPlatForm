```html
<ejs-grid [dataSource]="data" height='300' enableInfiniteScrolling='true' > </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { GridComponent,InfiniteScrollService  } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers: [InfiniteScrollService]
})
export class AppComponent implements OnInit{
    public data: Object[];
    public ngOnInit(): void {
        this.data = orderData;
    }
}
```