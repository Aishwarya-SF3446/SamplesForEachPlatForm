```html
<ejs-grid [dataSource]='data' [toolbar]='toolbar' [allowExcelExport]='true'>
</ejs-grid>
```
```ts
import { Component, OnInit} from '@angular/core';
import { orderDetails } from './data';
import { GridComponent, ToolbarService, ExcelExportService} from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers: [ToolbarService, ExcelExportService]
})
export class AppComponent implements OnInit {
    public data: Object[];
    public toolbar: string[];
    public ngOnInit(): void { 
        this.data = orderDetails;
        this.toolbar = ['ExcelExport'];
    }
}
```