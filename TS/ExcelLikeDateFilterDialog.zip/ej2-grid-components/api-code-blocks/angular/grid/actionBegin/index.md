```html
    <ejs-grid [dataSource]='data' allowPaging='true' (actionBegin)='actionBegin($event)'>
    </ejs-grid>
```
```ts
import { Component } from '@angular/core';
import { orderDetails } from './data';
import { PageEventArgs, PageService } from '@syncfusion/ej2-angular-grids'

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [PageService]
})
export class AppComponent {
  public data: Object[] = orderDetails;

  // For Paging action
  public actionBegin(args: PageEventArgs) {
    console.log(args.requestType);
  }
}
```