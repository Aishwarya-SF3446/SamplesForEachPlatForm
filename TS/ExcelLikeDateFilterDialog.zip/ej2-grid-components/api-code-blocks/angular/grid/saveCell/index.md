```html
<button #btn1 cssClass='e-info' (click)='editCell()'> editCell </button>
<button #btn2 cssClass='e-info' (click)='saveCell()'> saveCell </button>
<ejs-grid #grid id='Grid' [dataSource]='data' [editSettings]='editSettings'>
	<e-columns>
		<e-column field='OrderID' isPrimaryKey='true' textAlign='Right'></e-column>
		<e-column field='CustomerID'></e-column>
	</e-columns>
</ejs-grid>
```
```ts
import { Component, ViewChild } from '@angular/core';
import { orderDetails } from './data';
import { GridComponent, EditService } from '@syncfusion/ej2-angular-grids'

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [EditService]
})
export class AppComponent {
  public data: Object[] = orderDetails;
  public editSettings: Object = { allowEditing: true, allowAdding: true, allowDeleting: true, mode: 'Batch' };

  @ViewChild('grid')
  public grid: GridComponent;

  public saveCell() {
    // Save the cell that is currently edited
    this.grid.saveCell();
  }
  public editCell() {
    // Edit the specified cell
    this.grid.editCell(1, 'CustomerID');
    (this.grid.element.querySelector('#GridCustomerID') as HTMLInputElement).value = 'HANAR';
  };
}
```