```html
    <ejs-grid [dataSource]='data' allowTextWrap='true' [textWrapSettings]='wrapOption'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})
export class AppComponent {
    public data: Object[];
    public wrapOption: Object;
    public ngOnInit(): void {
        this.data = orderData;
        this.wrapOption = { wrapMode: 'Both' };
    }
}
```