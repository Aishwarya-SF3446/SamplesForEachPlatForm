```html
<ejs-grid [dataSource]='data' [allowTextWrap]='true'>
</ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderDetails } from './data';
import { GridComponent} from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
})
export class AppComponent implements OnInit{
    public data: Object[];
    public ngOnInit(): void {
        this.data = orderDetails;
    }
}
```