```html
<ejs-grid [dataSource]="data" [editSettings]='editSettings' [toolbar]='toolbar'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { GridComponent, EditService, ToolbarService, EditSettingsModel,ToolbarItems} from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers: [EditService, ToolbarService]
})
export class AppComponent implements OnInit{
    public data: Object[];
    public editSettings: EditSettingsModel;
    public toolbar: ToolbarItems[];
    public ngOnInit(): void {
        this.data = orderData;
        this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true };
        this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
    }
}
```