```html
    <ejs-grid [dataSource]='data' [enableInfiniteScrolling]='true' [infiniteScrollSettings]='infiniteOptions' [pageSettings]='pageOptions' height:'400'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { InfiniteScrollService, InfiniteScrollSettingsModel, PageSettingsModel } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers: [InfiniteScrollService]
})
export class AppComponent {
    public data: Object[];
    public pageOptions: PageSettingsModel;
    public infiniteOptions: InfiniteScrollSettingsModel;
    public ngOnInit(): void {
        this.data = orderData;
        this.pageOptions = { pageSize: 50 };
        this.infiniteOptions = { enableCache: true, maxBlocks: 3, initialBlocks: 3 };
    }
}
```