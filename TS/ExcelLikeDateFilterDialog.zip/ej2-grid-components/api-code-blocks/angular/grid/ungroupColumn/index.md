```html
    <button #addBtnObj cssClass='e-info' (click)='click()'> Click </button>
	<ejs-grid #grid [dataSource]='data' allowGrouping='true' [groupSettings]="groupOptions">
		<e-columns>
			<e-column field='OrderID' textAlign='Right'></e-column>
			<e-column field='CustomerID'></e-column>
		</e-columns>
	</ejs-grid>
```
```ts
import { Component, ViewChild } from '@angular/core';
import { orderDetails } from './data';
import { GridComponent, GroupService, GroupSettingsModel } from '@syncfusion/ej2-angular-grids'

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  providers: [GroupService]
})
export class AppComponent {
  public data: Object[] = orderDetails;
  public groupOptions: GroupSettingsModel = { columns: ["CustomerID"] };

  @ViewChild('grid')
  public grid: GridComponent;

  public click() {
    // Ungroup a column by field name.
    this.grid.ungroupColumn('CustomerID');
  }
}
```