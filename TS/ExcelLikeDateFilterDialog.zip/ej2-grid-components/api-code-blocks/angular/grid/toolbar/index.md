```html
    <ejs-grid [dataSource]='data' [toolbar]='toolbarOptions'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { ToolbarService } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
     providers: [ToolbarService]
})
export class AppComponent {
    public data: Object[];
    public toolbarOptions: string[];
    public ngOnInit(): void {
        this.data = orderData;
        this.toolbarOptions = ['Search','Print'];
    }
}
```