```html
<ejs-grid [dataSource]='data' [allowReordering]="true">
</ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderDetails } from './data';
import { GridComponent, ReorderService} from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    providers:[ReorderService]
})
export class AppComponent implements OnInit{
    public data: Object[];
    public ngOnInit(): void {
        this.data = orderDetails;
    }
}
```