```html
    <ejs-grid [dataSource]='data' [toolbar]='toolbarOptions' [showColumnChooser]='true'> </ejs-grid>
```
```ts
import { Component, OnInit } from '@angular/core';
import { orderData } from './data';
import { ColumnChooserService , ToolbarService } from '@syncfusion/ej2-angular-grids';
@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
     providers: [ColumnChooserService, ToolbarService]
})
export class AppComponent {
    public data: Object[];
    public toolbarOptions: string[];
    public ngOnInit(): void {
        this.data = orderData;
        this.toolbarOptions = ['ColumnChooser'];
    }
}
```