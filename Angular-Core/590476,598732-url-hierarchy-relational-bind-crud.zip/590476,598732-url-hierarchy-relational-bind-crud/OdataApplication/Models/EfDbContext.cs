﻿using Microsoft.EntityFrameworkCore;
using OdataApplication.Models;

namespace OdataApplication
{
    public class EfDbContext : DbContext
    {
        ////protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        ////{
        ////    string directory = Directory.GetCurrentDirectory();
        ////    string dir = "Data Source=localhost;Initial Catalog=Northwind;Integrated Security=True";
        ////    optionsBuilder.UseNpgsql(dir);
        ////}
        public EfDbContext(DbContextOptions options) : base(options)
        {
        }

        //public DbSet<Test> Test { get; set; }

        public virtual DbSet<OrdersDetails> Orders { get; set; }
    }
}
