﻿using Microsoft.AspNetCore.Mvc;

namespace OdataApplication.Controllers
{
    public class StatementController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
