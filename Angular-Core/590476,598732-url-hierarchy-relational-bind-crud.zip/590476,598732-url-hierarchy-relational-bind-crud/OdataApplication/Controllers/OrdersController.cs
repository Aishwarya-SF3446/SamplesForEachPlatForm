﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using OdataApplication.Models;

namespace OdataApplication.Controllers
{
    [Route("odata/[controller]")]
    [ApiController]
    public class OrdersController : ODataController
    {
        [EnableQueryWithMetadata]
        public IActionResult Get()
        {
            return Ok(OrdersDetails.GetAllRecords().AsQueryable());
        }
    }
}
