﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using OdataApplication.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Security.Cryptography.X509Certificates;

namespace OdataApplication.Controllers
{
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = OrdersDetails.GetAllRecords();
        public static List<EmployeeView> empdata = EmployeeView.GetAllRecords();
        public static List<Customer> customerdata = Customer.GetAllRecords();
        public IActionResult Index()
        {
            ViewBag.dataSource = OrdersDetails.GetAllRecords();
            ViewBag.empData = EmployeeView.GetAllRecords();
            return View();
        }

        public IActionResult GridParentDataOperationHandler([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = empdata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            int count = DataSource.Cast<EmployeeView>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);    //Paging
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult GridChildDataOperationHandler([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = orddata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);    //Paging
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult GridSecondChildDataOperationHandler([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = customerdata.ToList();
            DataOperations operation = new DataOperations();

            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            int count = DataSource.Cast<Customer>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);    //Paging
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }

        public IActionResult GridInsertPostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            HomeController.orddata.Insert(0, value.Value);
            return Json(value);
        }
        public IActionResult GridUpdatePostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            var data = HomeController.orddata.Where(or => or.OrderID == value.Value.OrderID).FirstOrDefault();
            if (data != null)
            {
                data.OrderID = value.Value.OrderID;
                data.CustomerID = value.Value.CustomerID;
                data.Freight = value.Value.Freight;
                data.EmployeeID = value.Value.EmployeeID;
                data.ShipCity = value.Value.ShipCity;
                data.Verified = value.Value.Verified;
                data.OrderDate = value.Value.OrderDate;
                data.ShipName = value.Value.ShipName;
                data.ShipCountry = value.Value.ShipCountry;
                data.ShippedDate = value.Value.ShippedDate;
                data.ShipAddress = value.Value.ShipAddress;
            }
            return Json(value);
        }
        public IActionResult GridRemovePostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            HomeController.orddata.Remove(HomeController.orddata.Where(or => or.OrderID == int.Parse(value.Key.ToString())).FirstOrDefault());
            return Json(value);
        }

        public IActionResult GridCrudPostHandler([FromBody] CRUDModel<OrdersDetails> value)
        {
            if (value.Action == "update")
            {
                var data = HomeController.orddata.Where(or => or.OrderID == value.Value.OrderID).FirstOrDefault();
                if (data != null)
                {
                    data.OrderID = value.Value.OrderID;
                    data.CustomerID = value.Value.CustomerID;
                    data.Freight = value.Value.Freight;
                    data.EmployeeID = value.Value.EmployeeID;
                    data.ShipCity = value.Value.ShipCity;
                    data.Verified = value.Value.Verified;
                    data.OrderDate = value.Value.OrderDate;
                    data.ShipName = value.Value.ShipName;
                    data.ShipCountry = value.Value.ShipCountry;
                    data.ShippedDate = value.Value.ShippedDate;
                    data.ShipAddress = value.Value.ShipAddress;
                }
            }
            else if (value.Action == "insert")
            {
                HomeController.orddata.Insert(0, value.Value);
            }
            else if (value.Action == "remove")
            {

                HomeController.orddata.Remove(HomeController.orddata.Where(or => or.OrderID == (Int64)value.Key).FirstOrDefault());
            }
            return Json(value);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult TestFetch()
        {
            return View();
        }

    }
}