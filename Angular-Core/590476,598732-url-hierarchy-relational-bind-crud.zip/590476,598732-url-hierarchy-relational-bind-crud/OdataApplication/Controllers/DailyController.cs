﻿using Microsoft.AspNetCore.Mvc;

namespace OdataApplication.Controllers
{
    public class DailyController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
