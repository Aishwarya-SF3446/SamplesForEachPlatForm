

// ej.base.loadCldr(cagregorian, numbers, timeZoneNames);
var hostUrl = 'https://members.dreamtoucher.space/datasource.php';
var data = new ej.data.DataManager({
  url: hostUrl,
  adaptor: new ej.data.UrlAdaptor(),
  offline: true
});
var grid = new ej.grids.Grid({
  dataSource: data,
  allowPaging: true,
  toolbar: ['Edit'],
  editSettings: {
    allowEditing: true,
    mode: 'Dialog',
    template: '#dialog_template',
  },
  rowSelecting: function(args) {
    console.log('rowselecting');
  },
  rowDeselecting: function(args) {
    console.log('rowdeselecting');
  },
  actionBegin: function(args) {
    debugger;
  },
  columns: [
    {
      field: 'MemberNbr',
      headerText: 'Member Number',
      width: 120,
      isPrimaryKey: true,
    },
    { field: 'MemberName', headerText: 'Member Name', width: 150 },
  ],
  actionComplete: actionComplete,
});
grid.appendTo('#Grid');
let checkboxGrid;
let selectedRecords
function actionComplete(args) {
  if (args.requestType === 'beginEdit') {
    debugger;
    const form = args.form;
    form.autocomplete = 'off';
    form.autocapitalize = 'off';

    const dialog = args.dialog;
    dialog.beforeClose = function() {
      debugger;
    }
    dialog.close = function() {
      debugger;
    }
    dialog.destroyed = function() {
      debugger;
      
    }
    dialog.btnObj[0].click = function () {
      debugger
      selectedRecords = checkboxGrid.getSelectedRecords();
      console.log('click',selectedRecords)
    }
    dialog.height = window.innerHeight - 90 + 'px';
    dialog.element.style.maxHeight = '450px';

    const data = args.rowData;
    dialog.header = 'Edit ' + data.MemberName;
    if (checkboxGrid) {
      checkboxGrid.destroy();
      document.querySelector('#CheckboxGrid').innerHTML = '';
    }
  
    checkboxGrid = new ej.grids.Grid({
      dataSource: new ej.data.DataManager({
        url: 'https://members.dreamtoucher.space/datasource.php',
        adaptor: new ej.data.UrlAdaptor(),
        offline: true
      }),
      query: new ej.data.Query().addParams('member_nbr', 'test'),
      //allowPaging: true,
      allowSelection: true,
      selectionSettings: {
        type: 'Multiple',
        checkboxMode: 'ResetOnRowClick',
        checkboxOnly: true,
      },
      destroyed: function() {
        debugger;
        // selectedRecords = checkboxGrid.getSelectedRecords();
        // console.log(`selectedRecords${selectedRecords}`)
      },
      columns: [
        { field: 'pkey', isPrimaryKey: true, visible: false },

        {field: 'checked', type: 'checkbox', width: 10,
        headerTemplate: '#header_template'
       },

       {field: 'name', headerText: 'Function', width: 90},
      ],
      rowSelecting: function(args) {
        debugger;
      },
      rowDeselecting: function(args) {
        debugger;
      }
    });

    checkboxGrid.appendTo('#CheckboxGrid');
  }
  if (args.requestType === 'save') {
    console.log('selected', checkboxGrid.getSelectedRecords());
  }
}



// var data = new ej.data.DataManager({
//   url: 'https://services.syncfusion.com/js/production/api/UrlDataSource',
//   adaptor: new ej.data.UrlAdaptor()
// });
// let checkboxGrid;
// var grid = new ej.grids.Grid({
//   dataSource: data,
//   toolbar: ['Edit'],
//   editSettings: {
//     allowEditing: true,
//     mode: 'Dialog',
//     template: '#dialog_template',
//   },
//   allowPaging: true,
//   columns: [

//       { field: 'EmployeeID', headerText: 'Employee ID', width: 130,  textAlign: 'Right' },
//       { field: 'Employees', headerText: 'Employee Name', width: 150 },
//   ],
//   actionComplete: function(args) {
//       if (args.requestType === 'beginEdit') {
//           debugger;
//           const form = args.form;
//           form.autocomplete = 'off';
//           form.autocapitalize = 'off';
      
//           const dialog = args.dialog;
//           dialog.height = window.innerHeight - 90 + 'px';
//           dialog.element.style.maxHeight = '450px'; 
//           args.dialog.btnObj[0].click = function () {
              
//           }
//           const data = args.rowData;
//           dialog.header = 'Edit ' + data.MemberName;
//           if (checkboxGrid) {
//             checkboxGrid.destroy();
//           }
//          document.querySelector('#CheckboxGrid').innerHTML = '';
//       var query = new ej.data.Query().take(5);
//           checkboxGrid = new ej.grids.Grid({
//             dataSource: new ej.data.DataManager({
//               url: 'https://services.syncfusion.com/js/production/api/UrlDataSource',
//               adaptor: new ej.data.UrlAdaptor(),
//               crossDomain: true,
//             }),
//             query: query,
//             //allowPaging: true,
//             allowSelection: true,
//             selectionSettings: {
//               type: 'Multiple',
//               checkboxMode: 'ResetOnRowClick',
//               checkboxOnly: true, 
//             },
//             columns: [
//               { field: 'Check', type: 'checkbox', width: 50, headerTemplate: '#header_template' },
          
//           { field: 'EmployeeID', isPrimaryKey: true, headerText: 'Employee ID', width: 130,  textAlign: 'Right' },
//           { field: 'Employees', headerText: 'Employee Name', width: 150 },
//             ],

//                   rowSelecting: function(args) {
//         debugger;
//       },
//       rowDeselecting: function(args) {
//         debugger;
//       }
//           });            
//           checkboxGrid.appendTo('#CheckboxGrid');
//         }
//         if (args.requestType === 'save') {
//             debugger
//           console.log('selected', checkboxGrid.getSelectedRecords());
//         }
//   }
// });
// grid.appendTo('#Grid'); 

