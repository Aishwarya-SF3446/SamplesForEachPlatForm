﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace mvc_ej2.Models
{
    public class DialogTemplateModel
    {
        public int OrderID { get; set; }
        public int CustomerID { get; set; }

        public int EmployeeID { get; set; }

        public string CustomerName { get; set; }
        public string City { get; set; }
        public DateTime? OrderDate { get; set; }

        public int Id { get; set; }

        public string Gender { get; set; }
        public bool Language1 { get; set; }

        public bool Language2 { get; set; }

        public bool Language3 { get; set; }
    }
}