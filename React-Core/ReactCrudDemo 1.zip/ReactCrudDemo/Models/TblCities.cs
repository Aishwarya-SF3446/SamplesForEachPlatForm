﻿using System;
using System.Collections.Generic;

namespace ReactCrudDemo.Models
{
    public partial class TblCities
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
    }
}
