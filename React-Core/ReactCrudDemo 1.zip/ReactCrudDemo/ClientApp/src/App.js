import * as React from 'react';
// import { RouteComponentProps } from 'react-router';
// import { Link, NavLink } from 'react-router-dom';
import { GridComponent, ColumnDirective, ColumnsDirective, Grid, Group, Inject, Page, Edit, Toolbar } from '@syncfusion/ej2-react-grids';
import { DataManager, UrlAdaptor } from '@syncfusion/ej2-data';



export default class App extends React.Component  {

  dm = new DataManager({
            url: "/Home/UrlDatasource",
            adaptor: new UrlAdaptor(),
            insertUrl: "/Home/Insert",
            updateUrl: "/Home/Update",
            removeUrl:"/Home/Delete"
        });
         selectionSettings = { type: 'Multiple' };
     toolbarOptions = ['Add', 'Delete', 'Update', 'Cancel'];
  editSettings = {
    allowEditing: true,
    allowAdding: true,
    allowDeleting: true,
    mode: 'Normal',
  };

  pageSettings = { pageCount: 5 };
  render() {
    return (
      <div className="control-pane">
        <div className="control-section">
          <div className="col-md-9">
            <GridComponent
              dataSource={this.dm}
              pageSettings={this.pageSettings}
              toolbar={this.toolbarOptions}
              allowPaging={true}
              editSettings={this.editSettings}
            >
              <ColumnsDirective>
                <ColumnDirective type="checkbox" width={60}></ColumnDirective>
                <ColumnDirective
                  field="OrderID"
                  headerText="Order ID"
                  width="120"
                  textAlign="Right"
      
                  isPrimaryKey={true}
                ></ColumnDirective>
                <ColumnDirective
                  field="CustomerID"
                  headerText="Customer Name"
                  width="150"
             
                ></ColumnDirective>
                <ColumnDirective
                  field="Freight"
                  headerText="Freight"
                  width="120"
                  format="C2"
                  textAlign="Right"
                  editType="numericedit"
                ></ColumnDirective>
                <ColumnDirective
                  field="OrderDate"
                  headerText="Order Date"
                  editType="datepickeredit"
                  format="yMd"
                  width="170"
                ></ColumnDirective>
                <ColumnDirective
                  field="ShipCountry"
                  headerText="Ship Country"
                  width="150"
                  editType="dropdownedit"
              
                ></ColumnDirective>
              </ColumnsDirective>
              <Inject services={[Page, Toolbar, Edit]} />
            </GridComponent>
          </div>
        </div>
      </div>
    );
  }
}
